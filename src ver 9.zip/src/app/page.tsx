import { KitchenDesigner } from "@/features/kitchen-editor/components/KitchenDesigner";

export default function Page() {
  return <KitchenDesigner />;
}
