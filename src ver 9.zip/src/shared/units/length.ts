export type MeasurementUnit = "feet" | "inches";

export const PIXELS_PER_FOOT = 28;
export const INCHES_PER_FOOT = 12;
export const BASE_FLOOR_PLAN_PIXELS_PER_INCH = PIXELS_PER_FOOT / INCHES_PER_FOOT;

export function pixelsToInches(lengthPixels: number, pixelsPerInch: number) {
  return lengthPixels / pixelsPerInch;
}

export function inchesToPixels(lengthInches: number, pixelsPerInch: number) {
  return lengthInches * pixelsPerInch;
}

function roundToNearestInch(inches: number) {
  return Math.max(0, Math.round(inches));
}

export function formatLengthFromInches(lengthInches: number, unit: MeasurementUnit) {
  const totalInches = roundToNearestInch(lengthInches);

  if (unit === "inches") {
    return `${totalInches}\"`;
  }

  const feet = Math.floor(totalInches / INCHES_PER_FOOT);
  const inches = totalInches % INCHES_PER_FOOT;

  if (feet === 0) {
    return `${inches}\"`;
  }

  if (inches === 0) {
    return `${feet}'`;
  }

  return `${feet}' ${inches}\"`;
}
