import type { Point2DInches, Point2DPixels } from "@/shared/types/geometryTypes";

export const RIGHT_ANGLE_DEGREES = 90;
export const STRAIGHT_ANGLE_DEGREES = 180;
export const FULL_CIRCLE_DEGREES = 360;
const ZERO_LENGTH_TOLERANCE = 0.000001;

export type SegmentProjection = Readonly<{
  pointInches: Point2DInches;
  clampedDistanceAlongSegmentInches: number;
  unclampedDistanceAlongSegmentInches: number;
  segmentLengthInches: number;
}>;

export function toDegrees(radians: number) {
  return (radians * STRAIGHT_ANGLE_DEGREES) / Math.PI;
}

export function normalizeDegrees(degrees: number) {
  return ((degrees % FULL_CIRCLE_DEGREES) + FULL_CIRCLE_DEGREES) % FULL_CIRCLE_DEGREES;
}

export function addPoints(firstPointInches: Point2DInches, secondPointInches: Point2DInches): Point2DInches {
  return {
    xInches: firstPointInches.xInches + secondPointInches.xInches,
    yInches: firstPointInches.yInches + secondPointInches.yInches,
  };
}

export function subtractPoints(firstPointInches: Point2DInches, secondPointInches: Point2DInches): Point2DInches {
  return {
    xInches: firstPointInches.xInches - secondPointInches.xInches,
    yInches: firstPointInches.yInches - secondPointInches.yInches,
  };
}

export function scalePoint(pointInches: Point2DInches, scale: number): Point2DInches {
  return {
    xInches: pointInches.xInches * scale,
    yInches: pointInches.yInches * scale,
  };
}

export function dotPoints(firstPointInches: Point2DInches, secondPointInches: Point2DInches) {
  return firstPointInches.xInches * secondPointInches.xInches + firstPointInches.yInches * secondPointInches.yInches;
}

export function distanceBetweenPoints(firstPointInches: Point2DInches, secondPointInches: Point2DInches) {
  return Math.hypot(
    secondPointInches.xInches - firstPointInches.xInches,
    secondPointInches.yInches - firstPointInches.yInches,
  );
}

export function getUnitVector(startPointInches: Point2DInches, endPointInches: Point2DInches): Point2DInches {
  const lengthInches = distanceBetweenPoints(startPointInches, endPointInches);

  if (lengthInches <= ZERO_LENGTH_TOLERANCE) {
    return { xInches: 0, yInches: 0 };
  }

  return {
    xInches: (endPointInches.xInches - startPointInches.xInches) / lengthInches,
    yInches: (endPointInches.yInches - startPointInches.yInches) / lengthInches,
  };
}

export function distanceBetweenPixelPoints(firstPointPixels: Point2DPixels, secondPointPixels: Point2DPixels) {
  return Math.hypot(
    secondPointPixels.xPixels - firstPointPixels.xPixels,
    secondPointPixels.yPixels - firstPointPixels.yPixels,
  );
}

export function getSegmentMidpoint(startPointInches: Point2DInches, endPointInches: Point2DInches): Point2DInches {
  return {
    xInches: (startPointInches.xInches + endPointInches.xInches) / 2,
    yInches: (startPointInches.yInches + endPointInches.yInches) / 2,
  };
}

export function getAngleDegrees(startPointInches: Point2DInches, endPointInches: Point2DInches) {
  return toDegrees(
    Math.atan2(
      endPointInches.yInches - startPointInches.yInches,
      endPointInches.xInches - startPointInches.xInches,
    ),
  );
}

export function getReadableTextAngleDegrees(angleDegrees: number) {
  const normalizedAngle = normalizeDegrees(angleDegrees);

  if (normalizedAngle > RIGHT_ANGLE_DEGREES && normalizedAngle < 270) {
    return angleDegrees + STRAIGHT_ANGLE_DEGREES;
  }

  return angleDegrees;
}

export function projectPointOntoSegment(
  pointInches: Point2DInches,
  segmentStartPointInches: Point2DInches,
  segmentEndPointInches: Point2DInches,
): SegmentProjection {
  const segmentInches = subtractPoints(segmentEndPointInches, segmentStartPointInches);
  const segmentLengthSquared = dotPoints(segmentInches, segmentInches);
  const segmentLengthInches = Math.sqrt(segmentLengthSquared);

  if (segmentLengthInches <= ZERO_LENGTH_TOLERANCE) {
    return {
      pointInches: segmentStartPointInches,
      clampedDistanceAlongSegmentInches: 0,
      unclampedDistanceAlongSegmentInches: 0,
      segmentLengthInches: 0,
    };
  }

  const unclampedRatio =
    dotPoints(subtractPoints(pointInches, segmentStartPointInches), segmentInches) /
    segmentLengthSquared;
  const clampedRatio = Math.min(Math.max(unclampedRatio, 0), 1);

  return {
    pointInches: addPoints(segmentStartPointInches, scalePoint(segmentInches, clampedRatio)),
    clampedDistanceAlongSegmentInches: clampedRatio * segmentLengthInches,
    unclampedDistanceAlongSegmentInches: unclampedRatio * segmentLengthInches,
    segmentLengthInches,
  };
}

export function getPointToSegmentDistance(
  pointInches: Point2DInches,
  segmentStartPointInches: Point2DInches,
  segmentEndPointInches: Point2DInches,
) {
  const projection = projectPointOntoSegment(pointInches, segmentStartPointInches, segmentEndPointInches);

  return distanceBetweenPoints(pointInches, projection.pointInches);
}
