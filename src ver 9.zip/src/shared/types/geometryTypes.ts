export type Point2DInches = Readonly<{
  xInches: number;
  yInches: number;
}>;

export type Point3DInches = Readonly<{
  xInches: number;
  yInches: number;
  zInches: number;
}>;

export type Point2DPixels = Readonly<{
  xPixels: number;
  yPixels: number;
}>;

export type Size2DInches = Readonly<{
  widthInches: number;
  heightInches: number;
}>;

export type Size2DPixels = Readonly<{
  widthPixels: number;
  heightPixels: number;
}>;
