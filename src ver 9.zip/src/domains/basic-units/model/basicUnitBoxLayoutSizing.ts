import type {
  BasicUnitBoxLayout,
  BasicUnitBoxLayoutItem,
} from "./basicUnitTypes";

export type BasicUnitBoxLayoutItemRegion = Readonly<{
  itemId: string;
  frontFaceLeftInches: number;
  frontFaceBottomInches: number;
  frontFaceWidthInches: number;
  frontFaceHeightInches: number;
}>;

export type BasicUnitBoxLayoutItemSizingBounds = Readonly<{
  minSizeInches: number;
  maxSizeInches: number;
}>;

type BasicUnitBoxLayoutResolvedAxisSize = Readonly<{
  item: BasicUnitBoxLayoutItem;
  sizeInches: number;
}>;

function getNonNegativeNumber(value: number) {
  return Number.isFinite(value) ? Math.max(value, 0) : 0;
}

function getLayoutAxisSizeInches(
  layout: BasicUnitBoxLayout,
  availableWidthInches: number,
  availableHeightInches: number,
) {
  return layout.direction === "horizontal"
    ? getNonNegativeNumber(availableWidthInches)
    : getNonNegativeNumber(availableHeightInches);
}

function getFixedSizeInches(item: BasicUnitBoxLayoutItem) {
  return item.sizing === "fixed" ? getNonNegativeNumber(item.sizeInches) : 0;
}

function getFillWeight(item: BasicUnitBoxLayoutItem) {
  return item.sizing === "fill" ? getNonNegativeNumber(item.fillWeight) : 0;
}

function getBasicUnitBoxLayoutResolvedAxisSizes(
  items: readonly BasicUnitBoxLayoutItem[],
  axisSizeInches: number,
): readonly BasicUnitBoxLayoutResolvedAxisSize[] {
  let remainingFixedAxisSizeInches = getNonNegativeNumber(axisSizeInches);

  const fixedAxisSizes = items.map((item) => {
    if (item.sizing !== "fixed") {
      return null;
    }

    const sizeInches = Math.min(
      getFixedSizeInches(item),
      remainingFixedAxisSizeInches,
    );
    remainingFixedAxisSizeInches -= sizeInches;

    return {
      item,
      sizeInches,
    } satisfies BasicUnitBoxLayoutResolvedAxisSize;
  });

  const remainingFillAxisSizeInches = remainingFixedAxisSizeInches;
  const totalFillWeight = items.reduce(
    (totalWeight, item) => totalWeight + getFillWeight(item),
    0,
  );

  return items.map((item, itemIndex) => {
    const fixedAxisSize = fixedAxisSizes[itemIndex];

    if (fixedAxisSize) {
      return fixedAxisSize;
    }

    return {
      item,
      sizeInches:
        totalFillWeight > 0
          ? (remainingFillAxisSizeInches * getFillWeight(item)) /
            totalFillWeight
          : 0,
    };
  });
}

function getBasicUnitBoxLayoutRegionForAxisSize(
  layout: BasicUnitBoxLayout,
  itemId: string,
  sizeInches: number,
  currentOffsetInches: number,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayoutItemRegion {
  if (layout.direction === "horizontal") {
    return {
      itemId,
      frontFaceLeftInches: currentOffsetInches,
      frontFaceBottomInches: 0,
      frontFaceWidthInches: sizeInches,
      frontFaceHeightInches: getNonNegativeNumber(availableHeightInches),
    };
  }

  return {
    itemId,
    frontFaceLeftInches: 0,
    frontFaceBottomInches:
      getNonNegativeNumber(availableHeightInches) -
      currentOffsetInches -
      sizeInches,
    frontFaceWidthInches: getNonNegativeNumber(availableWidthInches),
    frontFaceHeightInches: sizeInches,
  };
}

export function getBasicUnitBoxLayoutItemRegions(
  layout: BasicUnitBoxLayout,
  availableWidthInches: number,
  availableHeightInches: number,
): readonly BasicUnitBoxLayoutItemRegion[] {
  const axisSizeInches = getLayoutAxisSizeInches(
    layout,
    availableWidthInches,
    availableHeightInches,
  );
  const axisSizes = getBasicUnitBoxLayoutResolvedAxisSizes(
    layout.items,
    axisSizeInches,
  );
  let currentOffsetInches = 0;

  return axisSizes.map(({ item, sizeInches }) => {
    const itemRegion = getBasicUnitBoxLayoutRegionForAxisSize(
      layout,
      item.id,
      sizeInches,
      currentOffsetInches,
      availableWidthInches,
      availableHeightInches,
    );

    currentOffsetInches += sizeInches;

    return itemRegion;
  });
}

export function getBasicUnitBoxLayoutItemRegion(
  layout: BasicUnitBoxLayout,
  itemId: string,
  availableWidthInches: number,
  availableHeightInches: number,
) {
  return getBasicUnitBoxLayoutItemRegions(
    layout,
    availableWidthInches,
    availableHeightInches,
  ).find((region) => region.itemId === itemId) ?? null;
}

export function getBasicUnitBoxLayoutItemSizingBounds(
  layout: BasicUnitBoxLayout,
  itemId: string,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayoutItemSizingBounds | null {
  const item = layout.items.find((candidateItem) => candidateItem.id === itemId);

  if (!item) {
    return null;
  }

  const axisSizeInches = getLayoutAxisSizeInches(
    layout,
    availableWidthInches,
    availableHeightInches,
  );
  const fixedSiblingSizeInches = layout.items.reduce(
    (totalSizeInches, siblingItem) =>
      siblingItem.id === itemId
        ? totalSizeInches
        : totalSizeInches + getFixedSizeInches(siblingItem),
    0,
  );

  return {
    minSizeInches: 0,
    maxSizeInches: Math.max(axisSizeInches - fixedSiblingSizeInches, 0),
  };
}

export function normalizeBasicUnitBoxLayoutSizing(
  layout: BasicUnitBoxLayout,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayout {
  const itemRegions = getBasicUnitBoxLayoutItemRegions(
    layout,
    availableWidthInches,
    availableHeightInches,
  );

  return {
    ...layout,
    items: layout.items.map((item) => {
      const itemRegion = itemRegions.find((region) => region.itemId === item.id);

      const normalizedSizing =
        item.sizing === "fixed"
          ? {
              sizing: "fixed" as const,
              sizeInches: itemRegion
                ? layout.direction === "horizontal"
                  ? itemRegion.frontFaceWidthInches
                  : itemRegion.frontFaceHeightInches
                : 0,
            }
          : {
              sizing: "fill" as const,
              fillWeight: getFillWeight(item),
            };

      if (item.itemType === "leaf") {
        return {
          id: item.id,
          itemType: "leaf" as const,
          frontFace: item.frontFace,
          ...normalizedSizing,
        };
      }

      return {
        id: item.id,
        itemType: "container" as const,
        childLayout: itemRegion
          ? normalizeBasicUnitBoxLayoutSizing(
              item.childLayout,
              itemRegion.frontFaceWidthInches,
              itemRegion.frontFaceHeightInches,
            )
          : item.childLayout,
        ...normalizedSizing,
      };
    }),
  };
}
