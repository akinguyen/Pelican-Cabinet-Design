import type {
  BasicUnitBoxLayout,
  BasicUnitBoxLayoutItemFrontFace,
} from "./basicUnitTypes";
import { getBasicUnitBoxLayoutItemRegions } from "./basicUnitBoxLayoutSizing";

export type BasicUnitBoxLayoutFrontFaceItem = Readonly<{
  itemId: string;
  frontFace: BasicUnitBoxLayoutItemFrontFace;
  frontFaceLeftInches: number;
  frontFaceBottomInches: number;
  frontFaceWidthInches: number;
  frontFaceHeightInches: number;
}>;

type BasicUnitBoxLayoutRegion = Readonly<{
  frontFaceLeftInches: number;
  frontFaceBottomInches: number;
  frontFaceWidthInches: number;
  frontFaceHeightInches: number;
}>;

function getBasicUnitBoxLayoutFrontFaceItemsForRegion(
  layout: BasicUnitBoxLayout,
  region: BasicUnitBoxLayoutRegion,
): readonly BasicUnitBoxLayoutFrontFaceItem[] {
  const itemRegions = getBasicUnitBoxLayoutItemRegions(
    layout,
    region.frontFaceWidthInches,
    region.frontFaceHeightInches,
  );

  return layout.items.flatMap((item) => {
    const itemLocalRegion = itemRegions.find(
      (candidateRegion) => candidateRegion.itemId === item.id,
    );

    if (!itemLocalRegion) {
      return [];
    }

    const itemRegion = {
      frontFaceLeftInches:
        region.frontFaceLeftInches + itemLocalRegion.frontFaceLeftInches,
      frontFaceBottomInches:
        region.frontFaceBottomInches + itemLocalRegion.frontFaceBottomInches,
      frontFaceWidthInches: itemLocalRegion.frontFaceWidthInches,
      frontFaceHeightInches: itemLocalRegion.frontFaceHeightInches,
    };

    if (item.itemType === "container") {
      return getBasicUnitBoxLayoutFrontFaceItemsForRegion(
        item.childLayout,
        itemRegion,
      );
    }

    return [
      {
        itemId: item.id,
        frontFace: item.frontFace,
        ...itemRegion,
      },
    ];
  });
}

export function getBasicUnitBoxLayoutFrontFaceItems(
  layout: BasicUnitBoxLayout,
  boxWidthInches: number,
  boxHeightInches: number,
): readonly BasicUnitBoxLayoutFrontFaceItem[] {
  return getBasicUnitBoxLayoutFrontFaceItemsForRegion(layout, {
    frontFaceLeftInches: 0,
    frontFaceBottomInches: 0,
    frontFaceWidthInches: boxWidthInches,
    frontFaceHeightInches: boxHeightInches,
  });
}
