import type { Point3DInches } from "@/shared/types/geometryTypes";

export type BasicUnitKind =
  | "box"
  | "countertop"
  | "shelf-panel"
  | "panel"
  | "filler"
  | "toekick"
  | "door"
  | "drawer"
  | "handle";

export type BasicUnitSide = "front" | "back" | "left-side" | "right-side";

export type BasicUnitHandleOrientation = "vertical" | "horizontal";

export type BasicUnitBoxLayoutDirection = "horizontal" | "vertical";

export type BasicUnitBoxLayoutItemType = "leaf" | "container";

export type BasicUnitDoorBarPullPosition =
  | "left-center"
  | "right-center"
  | "top-left"
  | "top-right"
  | "bottom-left"
  | "bottom-right";

export type BasicUnitDrawerBarPullPosition =
  | "center"
  | "top-center"
  | "bottom-center";

export type BasicUnitDoorEdgePullPosition =
  | "left-center"
  | "right-center"
  | "top-left"
  | "top-center"
  | "top-right"
  | "bottom-left"
  | "bottom-center"
  | "bottom-right";

export type BasicUnitDrawerEdgePullPosition =
  | "top-left"
  | "top-center"
  | "top-right"
  | "bottom-left"
  | "bottom-center"
  | "bottom-right";

export type BasicUnitDoorKnobPullPosition =
  | "left-center"
  | "right-center"
  | "top-left"
  | "top-right"
  | "bottom-left"
  | "bottom-right";

export type BasicUnitDrawerKnobPullPosition =
  | "center"
  | "top-center"
  | "bottom-center"
  | "left-center"
  | "right-center";

export type BasicUnitDoorFrontHandle =
  | Readonly<{
      type: "bar-pull";
      position: BasicUnitDoorBarPullPosition;
    }>
  | Readonly<{
      type: "edge-pull";
      position: BasicUnitDoorEdgePullPosition;
    }>
  | Readonly<{
      type: "knob-pull";
      position: BasicUnitDoorKnobPullPosition;
    }>;

export type BasicUnitDrawerFrontHandle =
  | Readonly<{
      type: "bar-pull";
      position: BasicUnitDrawerBarPullPosition;
    }>
  | Readonly<{
      type: "edge-pull";
      position: BasicUnitDrawerEdgePullPosition;
    }>
  | Readonly<{
      type: "knob-pull";
      position: BasicUnitDrawerKnobPullPosition;
    }>;

export type BasicUnitBoxLayoutItemFrontHandle =
  | BasicUnitDoorFrontHandle
  | BasicUnitDrawerFrontHandle;

export type BasicUnitBoxLayoutItemFrontFace =
  | Readonly<{
      kind: "open";
    }>
  | Readonly<{
      kind: "door";
      handle: BasicUnitDoorFrontHandle | null;
    }>
  | Readonly<{
      kind: "drawer";
      handle: BasicUnitDrawerFrontHandle | null;
    }>;

export type BasicUnitBoxLayout = Readonly<{
  direction: BasicUnitBoxLayoutDirection;
  items: readonly BasicUnitBoxLayoutItem[];
}>;

export type BasicUnitBoxLayoutItemSizing =
  | Readonly<{
      sizing: "fixed";
      sizeInches: number;
    }>
  | Readonly<{
      sizing: "fill";
      fillWeight: number;
    }>;

export type BasicUnitBoxLayoutLeafItem = BasicUnitBoxLayoutItemSizing &
  Readonly<{
    id: string;
    itemType: "leaf";
    frontFace: BasicUnitBoxLayoutItemFrontFace;
  }>;

export type BasicUnitBoxLayoutContainerItem = BasicUnitBoxLayoutItemSizing &
  Readonly<{
    id: string;
    itemType: "container";
    childLayout: BasicUnitBoxLayout;
  }>;

export type BasicUnitBoxLayoutItem =
  | BasicUnitBoxLayoutLeafItem
  | BasicUnitBoxLayoutContainerItem;

/**
 * BasicUnit local side convention:
 * - local +Y is the front side.
 * - local -Y is the back side.
 * - local -X is the left side.
 * - local +X is the right side.
 * - local +Z is up.
 *
 * widthInches = local X size.
 * depthInches = local Y size.
 * heightInches = local Z size.
 *
 * floorPlan.rotationDegrees rotates this local coordinate system in floor-plan space.
 */
type BasicUnitBase<Kind extends BasicUnitKind> = Readonly<{
  id: string;
  kind: Kind;
  widthInches: number;
  heightInches: number;
  depthInches: number;
  floorPlan: Readonly<{
    positionInches: Point3DInches;
    rotationDegrees: number;
  }>;
}>;

export type PlacedBoxUnit = BasicUnitBase<"box"> &
  Readonly<{
    frameThicknessInches: number;
    layout: BasicUnitBoxLayout;
  }>;

export type PlacedCountertopUnit = BasicUnitBase<"countertop">;
export type PlacedShelfPanelUnit = BasicUnitBase<"shelf-panel">;
export type PlacedPanelUnit = BasicUnitBase<"panel">;
export type PlacedFillerUnit = BasicUnitBase<"filler">;
export type PlacedToekickUnit = BasicUnitBase<"toekick">;
export type PlacedDoorUnit = BasicUnitBase<"door">;
export type PlacedDrawerUnit = BasicUnitBase<"drawer">;
export type PlacedHandleUnit = BasicUnitBase<"handle">;

export type PlacedBasicUnit =
  | PlacedBoxUnit
  | PlacedCountertopUnit
  | PlacedShelfPanelUnit
  | PlacedPanelUnit
  | PlacedFillerUnit
  | PlacedToekickUnit
  | PlacedDoorUnit
  | PlacedDrawerUnit
  | PlacedHandleUnit;

export type BasicUnitFloorPlanCandidateMode = "create" | "move" | "rotate";

export type BasicUnitFloorPlanCandidatePlacementState =
  | "waiting-for-pointer"
  | "positioned";

export type BasicUnitFloorPlanCandidate = Readonly<{
  mode: BasicUnitFloorPlanCandidateMode;
  placementState: BasicUnitFloorPlanCandidatePlacementState;
  basicUnit: PlacedBasicUnit;
}>;

export type BasicUnitPatch = Readonly<{
  widthInches?: number;
  heightInches?: number;
  depthInches?: number;
  floorPlan?: Readonly<{
    positionInches?: Point3DInches;
    rotationDegrees?: number;
  }>;
  frameThicknessInches?: number;
  layout?: BasicUnitBoxLayout;
}>;
