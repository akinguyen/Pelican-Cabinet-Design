import type {
  BasicUnitBoxLayout,
  BasicUnitBoxLayoutDirection,
  BasicUnitBoxLayoutItem,
  BasicUnitBoxLayoutItemFrontFace,
  BasicUnitBoxLayoutItemSizing,
  BasicUnitBoxLayoutItemType,
} from "./basicUnitTypes";
import { normalizeBasicUnitBoxLayoutSizing } from "./basicUnitBoxLayoutSizing";

export type BasicUnitBoxLayoutItemPatch = Readonly<{
  sizing?: "fixed" | "fill";
  sizeInches?: number;
  fillWeight?: number;
  frontFace?: BasicUnitBoxLayoutItemFrontFace;
}>;

function createDefaultBasicUnitBoxLayoutItemFrontFace(): BasicUnitBoxLayoutItemFrontFace {
  return {
    kind: "open",
  };
}

export function createDefaultBasicUnitBoxLayoutItem(
  id: string,
): BasicUnitBoxLayoutItem {
  return {
    id,
    itemType: "leaf",
    sizing: "fill",
    fillWeight: 1,
    frontFace: createDefaultBasicUnitBoxLayoutItemFrontFace(),
  };
}

export function createDefaultBasicUnitBoxLayout(
  direction: BasicUnitBoxLayoutDirection = "vertical",
  itemId: string,
): BasicUnitBoxLayout {
  return {
    direction,
    items: [createDefaultBasicUnitBoxLayoutItem(itemId)],
  };
}

function getNonNegativeNumber(value: number) {
  return Number.isFinite(value) ? Math.max(value, 0) : 0;
}

function normalizeLayoutAfterEdit(
  layout: BasicUnitBoxLayout,
  availableWidthInches: number,
  availableHeightInches: number,
) {
  return normalizeBasicUnitBoxLayoutSizing(
    layout,
    availableWidthInches,
    availableHeightInches,
  );
}

function getUpdatedBasicUnitBoxLayoutItemSizing(
  item: BasicUnitBoxLayoutItem,
  patch: BasicUnitBoxLayoutItemPatch,
): BasicUnitBoxLayoutItemSizing {
  const sizing = patch.sizing ?? item.sizing;

  if (sizing === "fixed") {
    return {
      sizing,
      sizeInches: getNonNegativeNumber(
        patch.sizeInches ?? (item.sizing === "fixed" ? item.sizeInches : 12),
      ),
    };
  }

  return {
    sizing,
    fillWeight: getNonNegativeNumber(
      patch.fillWeight ?? (item.sizing === "fill" ? item.fillWeight : 1),
    ),
  };
}

function applyBasicUnitBoxLayoutItemPatch(
  item: BasicUnitBoxLayoutItem,
  patch: BasicUnitBoxLayoutItemPatch,
): BasicUnitBoxLayoutItem {
  const sizingFields = getUpdatedBasicUnitBoxLayoutItemSizing(item, patch);

  if (item.itemType === "container") {
    return {
      id: item.id,
      itemType: "container",
      childLayout: item.childLayout,
      ...sizingFields,
    };
  }

  return {
    id: item.id,
    itemType: "leaf",
    frontFace: patch.frontFace ?? item.frontFace,
    ...sizingFields,
  };
}

function updateBasicUnitBoxLayoutItems(
  items: readonly BasicUnitBoxLayoutItem[],
  updateItem: (item: BasicUnitBoxLayoutItem) => BasicUnitBoxLayoutItem,
): readonly BasicUnitBoxLayoutItem[] {
  return items.map((item) => {
    if (item.itemType !== "container") {
      return updateItem(item);
    }

    return updateItem({
      ...item,
      childLayout: {
        ...item.childLayout,
        items: updateBasicUnitBoxLayoutItems(item.childLayout.items, updateItem),
      },
    });
  });
}

export function updateBasicUnitBoxLayoutDirection(
  layout: BasicUnitBoxLayout,
  direction: BasicUnitBoxLayoutDirection,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayout {
  return normalizeLayoutAfterEdit(
    {
      ...layout,
      direction,
    },
    availableWidthInches,
    availableHeightInches,
  );
}

export function updateBasicUnitBoxLayoutItem(
  layout: BasicUnitBoxLayout,
  itemId: string,
  patch: BasicUnitBoxLayoutItemPatch,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayout {
  return normalizeLayoutAfterEdit(
    {
      ...layout,
      items: updateBasicUnitBoxLayoutItems(layout.items, (item) =>
        item.id === itemId ? applyBasicUnitBoxLayoutItemPatch(item, patch) : item,
      ),
    },
    availableWidthInches,
    availableHeightInches,
  );
}

export function addBasicUnitBoxLayoutItem(
  layout: BasicUnitBoxLayout,
  itemId: string,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayout {
  return normalizeLayoutAfterEdit(
    {
      ...layout,
      items: [...layout.items, createDefaultBasicUnitBoxLayoutItem(itemId)],
    },
    availableWidthInches,
    availableHeightInches,
  );
}

export function removeBasicUnitBoxLayoutItem(
  layout: BasicUnitBoxLayout,
  itemId: string,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayout {
  return normalizeLayoutAfterEdit(
    {
      ...layout,
      items: layout.items.flatMap((item): readonly BasicUnitBoxLayoutItem[] => {
        if (item.id === itemId) {
          return [];
        }

        if (item.itemType !== "container") {
          return [item];
        }

        return [
          {
            ...item,
            childLayout: removeBasicUnitBoxLayoutItem(
              item.childLayout,
              itemId,
              availableWidthInches,
              availableHeightInches,
            ),
          },
        ];
      }),
    },
    availableWidthInches,
    availableHeightInches,
  );
}

export function setBasicUnitBoxLayoutItemType(
  layout: BasicUnitBoxLayout,
  itemId: string,
  itemType: BasicUnitBoxLayoutItemType,
  childLayoutItemId: string,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayout {
  return normalizeLayoutAfterEdit(
    {
      ...layout,
      items: updateBasicUnitBoxLayoutItems(layout.items, (item) => {
        if (item.id !== itemId || item.itemType === itemType) {
          return item;
        }

        if (itemType === "container") {
          return {
            id: item.id,
            itemType,
            childLayout: createDefaultBasicUnitBoxLayout(
              "vertical",
              childLayoutItemId,
            ),
            ...getUpdatedBasicUnitBoxLayoutItemSizing(item, {}),
          };
        }

        return {
          id: item.id,
          itemType,
          frontFace: createDefaultBasicUnitBoxLayoutItemFrontFace(),
          ...getUpdatedBasicUnitBoxLayoutItemSizing(item, {}),
        };
      }),
    },
    availableWidthInches,
    availableHeightInches,
  );
}

export function updateBasicUnitBoxLayoutContainerChildLayout(
  layout: BasicUnitBoxLayout,
  itemId: string,
  childLayout: BasicUnitBoxLayout,
  availableWidthInches: number,
  availableHeightInches: number,
): BasicUnitBoxLayout {
  return normalizeLayoutAfterEdit(
    {
      ...layout,
      items: updateBasicUnitBoxLayoutItems(layout.items, (item) => {
        if (item.id !== itemId || item.itemType !== "container") {
          return item;
        }

        return {
          ...item,
          childLayout,
        };
      }),
    },
    availableWidthInches,
    availableHeightInches,
  );
}
