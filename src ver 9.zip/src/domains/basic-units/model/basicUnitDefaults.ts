import type {
  BasicUnitHandleOrientation,
  BasicUnitKind,
  PlacedBasicUnit,
} from "./basicUnitTypes";

export type BasicUnitCatalogItem = Readonly<{
  kind: BasicUnitKind;
  label: string;
  description: string;
}>;

export type BasicUnitDefaultDimensions = Readonly<{
  widthInches: number;
  heightInches: number;
  depthInches: number;
}>;

export const BASIC_UNIT_CATALOG_ITEMS: readonly BasicUnitCatalogItem[] = [
  {
    kind: "box",
    label: "Box",
    description: "Framed cabinet-like box body.",
  },
  {
    kind: "countertop",
    label: "Countertop",
    description: "Thin slab piece for top surfaces.",
  },
  {
    kind: "shelf-panel",
    label: "Shelf Panel",
    description: "Flat horizontal shelf or divider panel.",
  },
  {
    kind: "panel",
    label: "Panel",
    description: "Flat vertical panel piece.",
  },
  {
    kind: "filler",
    label: "Filler",
    description: "Narrow filler strip.",
  },
  {
    kind: "toekick",
    label: "Toekick",
    description: "Short horizontal base strip.",
  },
  {
    kind: "door",
    label: "Door",
    description: "Door front piece with direction in floor plan.",
  },
  {
    kind: "drawer",
    label: "Drawer",
    description: "Drawer front piece with direction in floor plan.",
  },
  {
    kind: "handle",
    label: "Handle",
    description: "Physical handle or pull piece.",
  },
];

type BasicUnitCreationIds = Readonly<{
  basicUnitId: string;
  boxLayoutItemId: string;
}>;

const DEFAULT_FLOOR_PLAN = {
  positionInches: {
    xInches: 0,
    yInches: 0,
    zInches: 0,
  },
  rotationDegrees: 0,
};

export function getDefaultBasicUnitDimensions(
  kind: BasicUnitKind,
): BasicUnitDefaultDimensions {
  switch (kind) {
    case "box":
      return {
        widthInches: 24,
        heightInches: 34.5,
        depthInches: 24,
      };
    case "countertop":
      return {
        widthInches: 24,
        heightInches: 1.5,
        depthInches: 25.5,
      };
    case "shelf-panel":
      return {
        widthInches: 24,
        heightInches: 0.75,
        depthInches: 12,
      };
    case "panel":
      return {
        widthInches: 24,
        heightInches: 34.5,
        depthInches: 0.75,
      };
    case "filler":
      return {
        widthInches: 3,
        heightInches: 34.5,
        depthInches: 0.75,
      };
    case "toekick":
      return {
        widthInches: 24,
        heightInches: 4.5,
        depthInches: 3,
      };
    case "door":
      return {
        widthInches: 18,
        heightInches: 30,
        depthInches: 0.75,
      };
    case "drawer":
      return {
        widthInches: 18,
        heightInches: 8,
        depthInches: 0.75,
      };
    case "handle":
      return {
        widthInches: 0.75,
        heightInches: 5,
        depthInches: 0.75,
      };
  }
}

export function getDefaultBasicUnitHandleDimensions(
  orientation: BasicUnitHandleOrientation,
): BasicUnitDefaultDimensions {
  if (orientation === "horizontal") {
    return {
      widthInches: 5,
      heightInches: 0.75,
      depthInches: 0.75,
    };
  }

  return {
    widthInches: 0.75,
    heightInches: 5,
    depthInches: 0.75,
  };
}

export function createDefaultPlacedBasicUnit(
  kind: BasicUnitKind,
  ids: BasicUnitCreationIds,
): PlacedBasicUnit {
  const dimensions = getDefaultBasicUnitDimensions(kind);

  if (kind === "box") {
    return {
      id: ids.basicUnitId,
      kind,
      ...dimensions,
      floorPlan: DEFAULT_FLOOR_PLAN,
      frameThicknessInches: 0.75,
      layout: {
        direction: "vertical",
        items: [
          {
            id: ids.boxLayoutItemId,
            itemType: "leaf",
            sizing: "fill",
            fillWeight: 1,
            frontFace: {
              kind: "open",
            },
          },
        ],
      },
    };
  }

  return {
    id: ids.basicUnitId,
    kind,
    ...dimensions,
    floorPlan: DEFAULT_FLOOR_PLAN,
  };
}
