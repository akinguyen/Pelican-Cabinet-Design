import type { Point2DInches } from "@/shared/types/geometryTypes";

export type WallKind = "thin-wall" | "thick-wall";

export type ThickWallPlacementSide = "none" | "interior" | "exterior";
export type ThickWallElevationPlanSide = "interior" | "exterior";

export type PlacedThinWallChain = Readonly<{
  id: string;
  kind: "thin-wall";
  floorPlan: Readonly<{
    centerlinePointsInches: readonly Point2DInches[];
  }>;
  heightInches: number;
}>;

export type PlacedThickWallChain = Readonly<{
  id: string;
  kind: "thick-wall";
  floorPlan: Readonly<{
    centerlinePointsInches: readonly Point2DInches[];
  }>;
  thicknessInches: number;
  heightInches: number;
  segmentPlacementSides: Readonly<Record<number, ThickWallPlacementSide>>;
}>;

export type WallFloorPlanCandidateMode = "create-chain" | "extend-chain";

export type CandidateThinWallSegment = Readonly<{
  id: string;
  kind: "thin-wall";
  mode: WallFloorPlanCandidateMode;
  chainId: string | null;
  floorPlan: Readonly<{
    startPointInches: Point2DInches;
    endPointInches: Point2DInches;
  }>;
  heightInches: number;
}>;

export type CandidateThickWallSegment = Readonly<{
  id: string;
  kind: "thick-wall";
  mode: WallFloorPlanCandidateMode;
  chainId: string | null;
  floorPlan: Readonly<{
    startPointInches: Point2DInches;
    endPointInches: Point2DInches;
  }>;
  thicknessInches: number;
  heightInches: number;
  placementSide: ThickWallPlacementSide;
}>;

export type WallCatalogItem = Readonly<{
  id: WallKind;
  label: string;
}>;

export const WALL_CATALOG_ITEMS: readonly WallCatalogItem[] = [
  {
    id: "thick-wall",
    label: "Thick Wall",
  },
  {
    id: "thin-wall",
    label: "Thin Wall",
  },
];
