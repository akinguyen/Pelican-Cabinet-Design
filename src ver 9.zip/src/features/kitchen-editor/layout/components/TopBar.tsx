"use client";

import type { ReactNode } from "react";
import { Redo2, Ruler, Undo2 } from "lucide-react";
import { useUiStore } from "@/features/kitchen-editor/state/useUIStore";
import type { EditorView } from "@/features/kitchen-editor/state/designStoreTypes";

type TopBarProps = Readonly<{
  activeView: EditorView;
  onViewChange: (view: EditorView) => void;
}>;

function TopBarButton({
  children,
  disabled = false,
  label,
  onClick,
}: Readonly<{
  children: ReactNode;
  disabled?: boolean;
  label: string;
  onClick?: () => void;
}>) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={[
        "inline-flex h-9 items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 text-sm font-semibold shadow-sm transition",
        disabled
          ? "cursor-not-allowed text-slate-400 opacity-70"
          : "text-slate-800 hover:bg-slate-50",
      ].join(" ")}
    >
      {children}
      <span>{label}</span>
    </button>
  );
}

function ViewButton({
  active,
  children,
  onClick,
}: Readonly<{
  active: boolean;
  children: ReactNode;
  onClick: () => void;
}>) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "rounded-full px-5 py-2 text-sm font-semibold transition",
        active
          ? "bg-white text-slate-950 shadow-sm ring-1 ring-slate-200"
          : "text-slate-500 hover:text-slate-800",
      ].join(" ")}
    >
      {children}
    </button>
  );
}

export function TopBar({ activeView, onViewChange }: TopBarProps) {
  const measurementUnit = useUiStore((state) => state.measurementUnit);
  const toggleMeasurementUnit = useUiStore((state) => state.toggleMeasurementUnit);
  const conversionLabel = measurementUnit === "feet" ? "Convert to inches" : "Convert to feet";

  return (
    <header className="relative flex h-14 items-center justify-between border-b border-slate-200 bg-white px-5 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-500 text-sm font-black italic text-white shadow-sm">
          pe
        </div>

        <span className="text-base font-bold tracking-tight text-slate-900">Pelican Editor</span>
      </div>

      <div className="absolute left-1/2 flex -translate-x-1/2 rounded-full bg-slate-100 p-1">
        <ViewButton active={activeView === "floor"} onClick={() => onViewChange("floor")}>
          Floor plan
        </ViewButton>

        <ViewButton active={activeView === "elevation"} onClick={() => onViewChange("elevation")}>
          Elevation plan
        </ViewButton>
      </div>

      <div className="flex items-center gap-3">
        <TopBarButton label={conversionLabel} onClick={toggleMeasurementUnit}>
          <Ruler className="h-4 w-4" strokeWidth={2} />
        </TopBarButton>

        <TopBarButton disabled label="Undo">
          <Undo2 className="h-4 w-4" strokeWidth={2} />
        </TopBarButton>

        <TopBarButton disabled label="Redo">
          <Redo2 className="h-4 w-4" strokeWidth={2} />
        </TopBarButton>
      </div>
    </header>
  );
}
