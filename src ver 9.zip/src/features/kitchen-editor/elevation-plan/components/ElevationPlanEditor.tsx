"use client";

import { useEffect, useMemo } from "react";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";
import { useUiStore } from "@/features/kitchen-editor/state/useUIStore";
import { useElevationPlanKeyboardShortcuts } from "@/features/kitchen-editor/elevation-plan/hooks/useElevationPlanKeyboardShortcuts";
import { getThickWallElevationPlanSegments } from "@/features/kitchen-editor/elevation-plan/walls/thick-wall/logic/thickWallElevationPlanSegments";
import { ElevationPlanControls } from "./ElevationPlanControls";
import { ElevationPlanNavigation } from "./ElevationPlanNavigation";
import { ElevationPlanCanvasArea } from "./ElevationPlanCanvasArea";

export function ElevationPlanEditor() {
  const placedThickWallChains = useDesignStore((state) => state.placedThickWallChains);
  const measurementUnit = useUiStore((state) => state.measurementUnit);
  const activeMode = useUiStore((state) => state.elevationMode);
  const selectedElevationSegmentIndex = useUiStore(
    (state) => state.selectedElevationWallIndex,
  );
  const selectedSide = useUiStore(
    (state) => state.selectedThickWallElevationPlanSide,
  );
  const setActiveMode = useUiStore((state) => state.setElevationMode);
  const setSelectedElevationSegmentIndex = useUiStore(
    (state) => state.setSelectedElevationWallIndex,
  );
  const setSelectedSide = useUiStore(
    (state) => state.setSelectedThickWallElevationPlanSide,
  );
  const thickWallElevationPlanSegments = useMemo(
    () => getThickWallElevationPlanSegments(placedThickWallChains),
    [placedThickWallChains],
  );
  const selectedSegment = thickWallElevationPlanSegments[selectedElevationSegmentIndex] ?? null;

  useElevationPlanKeyboardShortcuts();

  useEffect(() => {
    if (thickWallElevationPlanSegments.length === 0) {
      if (selectedElevationSegmentIndex !== 0) {
        setSelectedElevationSegmentIndex(0);
      }
      return;
    }

    if (selectedElevationSegmentIndex > thickWallElevationPlanSegments.length - 1) {
      setSelectedElevationSegmentIndex(thickWallElevationPlanSegments.length - 1);
    }
  }, [selectedElevationSegmentIndex, setSelectedElevationSegmentIndex, thickWallElevationPlanSegments.length]);

  return (
    <section className="relative flex h-full min-w-0 flex-1 flex-col bg-slate-50">
      <ElevationPlanControls activeMode={activeMode} onModeChange={setActiveMode} />

      {activeMode === "camera" ? (
        <div className="flex min-h-0 flex-1 items-center justify-center p-6">
          <div className="flex h-full w-full items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white text-sm font-semibold text-slate-500">
            Camera elevation tools are coming soon.
          </div>
        </div>
      ) : (
        <>
          <ElevationPlanNavigation
            currentWallIndex={selectedElevationSegmentIndex}
            wallCount={thickWallElevationPlanSegments.length}
            side={selectedSide}
            onPreviousWall={() =>
              setSelectedElevationSegmentIndex(
                thickWallElevationPlanSegments.length === 0
                  ? 0
                  : (selectedElevationSegmentIndex - 1 + thickWallElevationPlanSegments.length) %
                      thickWallElevationPlanSegments.length,
              )
            }
            onNextWall={() =>
              setSelectedElevationSegmentIndex(
                thickWallElevationPlanSegments.length === 0
                  ? 0
                  : (selectedElevationSegmentIndex + 1) % thickWallElevationPlanSegments.length,
              )
            }
            onSideChange={setSelectedSide}
          />

          <ElevationPlanCanvasArea
            selectedSegment={selectedSegment}
            wallNumber={selectedElevationSegmentIndex + 1}
            side={selectedSide}
            measurementUnit={measurementUnit}
            placedThickWallChains={placedThickWallChains}
          />
        </>
      )}
    </section>
  );
}
