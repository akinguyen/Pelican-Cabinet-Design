"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import type { ThickWallElevationPlanSide } from "@/domains/walls/model/wallTypes";

type ElevationPlanNavigationProps = Readonly<{
  currentWallIndex: number;
  wallCount: number;
  side: ThickWallElevationPlanSide;
  onPreviousWall: () => void;
  onNextWall: () => void;
  onSideChange: (side: ThickWallElevationPlanSide) => void;
}>;

export function ElevationPlanNavigation({
  currentWallIndex,
  wallCount,
  side,
  onPreviousWall,
  onNextWall,
  onSideChange,
}: ElevationPlanNavigationProps) {
  return (
    <div className="grid h-16 shrink-0 grid-cols-[1fr_auto_1fr] items-center border-b border-slate-200 bg-white px-5">
      <p className="text-sm font-bold text-slate-950">
        {wallCount > 0 ? `Wall ${currentWallIndex + 1} of ${wallCount}` : "No walls"}
      </p>

      <label className="flex items-center justify-center gap-3 text-xs font-bold uppercase tracking-wide text-slate-950">
        <span>Elevation Plan</span>
        <select
          value={side}
          onChange={(event) => onSideChange(event.target.value as ThickWallElevationPlanSide)}
          disabled={wallCount === 0}
          className="h-10 min-w-36 rounded-lg border border-slate-300 bg-white px-3 text-sm font-medium normal-case tracking-normal text-slate-700 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-400"
        >
          <option value="interior">Interior side</option>
          <option value="exterior">Exterior side</option>
        </select>
      </label>

      <div className="flex justify-end gap-3">
        <button
          type="button"
          onClick={onPreviousWall}
          disabled={wallCount < 2}
          aria-label="Previous wall"
          className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:text-slate-300 disabled:shadow-none"
        >
          <ChevronLeft className="h-5 w-5" strokeWidth={2.25} />
        </button>

        <button
          type="button"
          onClick={onNextWall}
          disabled={wallCount < 2}
          aria-label="Next wall"
          className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:text-slate-300 disabled:shadow-none"
        >
          <ChevronRight className="h-5 w-5" strokeWidth={2.25} />
        </button>
      </div>
    </div>
  );
}
