"use client";

import { type CSSProperties } from "react";
import type {
  PlacedThickWallChain,
  ThickWallElevationPlanSide,
} from "@/domains/walls/model/wallTypes";
import type { MeasurementUnit } from "@/shared/units/length";
import type { Size2DInches } from "@/shared/types/geometryTypes";
import { ThickWallElevationPlanSideRenderer } from "@/features/kitchen-editor/elevation-plan/walls/thick-wall/components/ThickWallElevationPlanSideRenderer";
import type { ThickWallElevationPlanSegment } from "@/features/kitchen-editor/elevation-plan/walls/thick-wall/logic/thickWallElevationPlanSegments";
import { getThickWallElevationPlanSideRenderItem } from "@/features/kitchen-editor/elevation-plan/walls/thick-wall/logic/thickWallElevationPlanRenderItems";

type ElevationPlanCanvasAreaProps = Readonly<{
  selectedSegment: ThickWallElevationPlanSegment | null;
  wallNumber: number;
  side: ThickWallElevationPlanSide;
  measurementUnit: MeasurementUnit;
  placedThickWallChains: readonly PlacedThickWallChain[];
}>;

type ElevationPlanCanvasAreaContentProps = ElevationPlanCanvasAreaProps &
  Readonly<{
    selectedSegment: ThickWallElevationPlanSegment;
  }>;

const MAX_ELEVATION_PLAN_EDITABLE_AREA_WIDTH_PIXELS = 720;
const MAX_ELEVATION_PLAN_EDITABLE_AREA_HEIGHT_PIXELS = 300;

function EmptyElevationPlanCanvasArea() {
  return (
    <div className="flex min-h-0 flex-1 items-center justify-center bg-slate-50 p-6">
      <div className="flex h-full w-full items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white text-sm font-semibold text-slate-500">
        Create a thick wall in the floor plan to see its elevation plan.
      </div>
    </div>
  );
}

function getElevationPlanEditableAreaSizePixels(
  elevationPlanSizeInches: Size2DInches,
) {
  const elevationPlanPixelsPerInch = Math.min(
    MAX_ELEVATION_PLAN_EDITABLE_AREA_WIDTH_PIXELS /
      Math.max(elevationPlanSizeInches.widthInches, 1),
    MAX_ELEVATION_PLAN_EDITABLE_AREA_HEIGHT_PIXELS /
      Math.max(elevationPlanSizeInches.heightInches, 1),
  );

  return {
    elevationPlanPixelsPerInch,
    widthPixels:
      elevationPlanSizeInches.widthInches * elevationPlanPixelsPerInch,
    heightPixels:
      elevationPlanSizeInches.heightInches * elevationPlanPixelsPerInch,
  };
}

function ElevationPlanCanvasAreaContent({
  selectedSegment,
  wallNumber,
  side,
  measurementUnit,
  placedThickWallChains,
}: ElevationPlanCanvasAreaContentProps) {
  const thickWallElevationPlanSideRenderItem =
    getThickWallElevationPlanSideRenderItem({
      allChains: placedThickWallChains,
      chain: selectedSegment.chain,
      geometry: selectedSegment.geometry,
      segmentIndex: selectedSegment.segmentIndex,
      side,
    });
  const elevationPlanSizeInches =
    thickWallElevationPlanSideRenderItem.elevationPlan.sizeInches;
  const {
    elevationPlanPixelsPerInch,
    widthPixels: elevationPlanEditableAreaWidthPixels,
    heightPixels: elevationPlanEditableAreaHeightPixels,
  } = getElevationPlanEditableAreaSizePixels(elevationPlanSizeInches);
  const elevationPlanEditableAreaSvgStylePixels: CSSProperties = {
    width: elevationPlanEditableAreaWidthPixels,
    height: elevationPlanEditableAreaHeightPixels,
  };

  return (
    <div
      className="relative min-h-0 flex-1 overflow-hidden bg-slate-50 touch-none select-none"
      aria-label={`Wall ${wallNumber} ${side} elevation plan`}
    >
      <svg
        className="absolute left-1/2 top-1/2 overflow-visible -translate-x-1/2 -translate-y-1/2"
        style={elevationPlanEditableAreaSvgStylePixels}
        viewBox={`0 0 ${elevationPlanSizeInches.widthInches} ${elevationPlanSizeInches.heightInches}`}
      >
        <ThickWallElevationPlanSideRenderer
          renderItem={thickWallElevationPlanSideRenderItem}
          elevationPlanPixelsPerInch={elevationPlanPixelsPerInch}
          measurementUnit={measurementUnit}
        />
      </svg>
    </div>
  );
}

export function ElevationPlanCanvasArea({
  selectedSegment,
  ...props
}: ElevationPlanCanvasAreaProps) {
  if (!selectedSegment) {
    return <EmptyElevationPlanCanvasArea />;
  }

  return <ElevationPlanCanvasAreaContent selectedSegment={selectedSegment} {...props} />;
}
