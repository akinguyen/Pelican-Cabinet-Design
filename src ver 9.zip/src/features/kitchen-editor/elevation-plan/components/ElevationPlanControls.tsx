"use client";

import type { ReactNode } from "react";
import { Camera, Grid2X2 } from "lucide-react";

export type ElevationPlanEditorMode = "wall-elevation" | "camera";

type ElevationPlanControlsProps = Readonly<{
  activeMode: ElevationPlanEditorMode;
  onModeChange: (mode: ElevationPlanEditorMode) => void;
}>;

type ElevationPlanControlButtonProps = Readonly<{
  active: boolean;
  children: ReactNode;
  label: string;
  onClick: () => void;
}>;

function ElevationPlanControlButton({
  active,
  children,
  label,
  onClick,
}: ElevationPlanControlButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "inline-flex h-10 items-center gap-2 rounded-lg border px-4 text-sm font-bold transition",
        active
          ? "border-cyan-200 bg-cyan-50 text-cyan-700 shadow-sm"
          : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
      ].join(" ")}
    >
      {children}
      <span>{label}</span>
    </button>
  );
}

export function ElevationPlanControls({ activeMode, onModeChange }: ElevationPlanControlsProps) {
  return (
    <div className="flex h-14 shrink-0 items-center justify-center gap-3 border-b border-slate-200 bg-white px-4">
      <ElevationPlanControlButton
        active={activeMode === "wall-elevation"}
        label="Walls"
        onClick={() => onModeChange("wall-elevation")}
      >
        <Grid2X2 className="h-4 w-4" strokeWidth={2.25} />
      </ElevationPlanControlButton>

      <ElevationPlanControlButton
        active={activeMode === "camera"}
        label="Camera"
        onClick={() => onModeChange("camera")}
      >
        <Camera className="h-4 w-4" strokeWidth={2.25} />
      </ElevationPlanControlButton>
    </div>
  );
}
