import type {
  PlacedThickWallChain,
  ThickWallElevationPlanSide,
} from "@/domains/walls/model/wallTypes";
import type { Point2DInches, Size2DInches } from "@/shared/types/geometryTypes";
import { getThickWallPlacementSideEdge } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallPlacementSideGeometry";
import type { ThickWallSegmentGeometry } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";

export type ThickWallElevationPlanSideRenderItem = Readonly<{
  wallChainId: string;
  wallSegmentIndex: number;
  wallSide: ThickWallElevationPlanSide;
  elevationPlan: Readonly<{
    sizeInches: Size2DInches;
  }>;
  floorPlan: Readonly<{
    sideStartPointInches: Point2DInches;
    sideEndPointInches: Point2DInches;
  }>;
}>;

export function getThickWallElevationPlanSideRenderItem({
  allChains,
  chain,
  geometry,
  segmentIndex,
  side,
}: Readonly<{
  allChains: readonly PlacedThickWallChain[];
  chain: PlacedThickWallChain;
  geometry: ThickWallSegmentGeometry;
  segmentIndex: number;
  side: ThickWallElevationPlanSide;
}>): ThickWallElevationPlanSideRenderItem {
  const sideEdge = getThickWallPlacementSideEdge(
    chain,
    geometry,
    side,
    allChains,
  );

  return {
    wallChainId: chain.id,
    wallSegmentIndex: segmentIndex,
    wallSide: side,
    elevationPlan: {
      sizeInches: {
        widthInches: sideEdge.sideLengthInches,
        heightInches: chain.heightInches,
      },
    },
    floorPlan: {
      sideStartPointInches: sideEdge.floorPlan.sideStartPointInches,
      sideEndPointInches: sideEdge.floorPlan.sideEndPointInches,
    },
  };
}
