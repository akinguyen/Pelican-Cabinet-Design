import type { PlacedThickWallChain } from "@/domains/walls/model/wallTypes";
import {
  getPlacedThickWallChainSegmentGeometries,
  type ThickWallSegmentGeometry,
} from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";

export type ThickWallElevationPlanSegment = Readonly<{
  chain: PlacedThickWallChain;
  chainId: string;
  segmentIndex: number;
  geometry: ThickWallSegmentGeometry;
}>;

export function getThickWallElevationPlanSegments(
  placedThickWallChains: readonly PlacedThickWallChain[],
): readonly ThickWallElevationPlanSegment[] {
  return placedThickWallChains.flatMap((chain) =>
    getPlacedThickWallChainSegmentGeometries(chain, placedThickWallChains).map(
      (geometry, segmentIndex): ThickWallElevationPlanSegment => ({
        chain,
        chainId: chain.id,
        segmentIndex,
        geometry,
      }),
    ),
  );
}
