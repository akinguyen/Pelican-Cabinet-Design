import type { MeasurementUnit } from "@/shared/units/length";
import type { ThickWallElevationPlanSideRenderItem } from "../logic/thickWallElevationPlanRenderItems";
import { ThickWallElevationPlanMeasurementGuides } from "./ThickWallElevationPlanMeasurementGuides";

const THICK_WALL_ELEVATION_PLAN_FILL = "#d1d5db";
const THICK_WALL_ELEVATION_PLAN_STROKE = "#94a3b8";
const THICK_WALL_ELEVATION_PLAN_STROKE_WIDTH_PIXELS = 1.5;

type ThickWallElevationPlanSideRendererProps = Readonly<{
  renderItem: ThickWallElevationPlanSideRenderItem;
  elevationPlanPixelsPerInch: number;
  measurementUnit: MeasurementUnit;
}>;

export function ThickWallElevationPlanSideRenderer({
  elevationPlanPixelsPerInch,
  measurementUnit,
  renderItem,
}: ThickWallElevationPlanSideRendererProps) {
  const sizeInches = renderItem.elevationPlan.sizeInches;

  return (
    <g>
      <ThickWallElevationPlanMeasurementGuides
        renderItem={renderItem}
        elevationPlanPixelsPerInch={elevationPlanPixelsPerInch}
        measurementUnit={measurementUnit}
      />

      <g transform={`translate(0 ${sizeInches.heightInches}) scale(1 -1)`}>
        <rect
          x={0}
          y={0}
          width={sizeInches.widthInches}
          height={sizeInches.heightInches}
          fill={THICK_WALL_ELEVATION_PLAN_FILL}
          stroke={THICK_WALL_ELEVATION_PLAN_STROKE}
          strokeWidth={THICK_WALL_ELEVATION_PLAN_STROKE_WIDTH_PIXELS}
          vectorEffect="non-scaling-stroke"
        />
      </g>
    </g>
  );
}
