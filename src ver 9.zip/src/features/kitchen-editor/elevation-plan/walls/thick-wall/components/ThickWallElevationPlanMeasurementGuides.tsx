import {
  formatLengthFromInches,
  type MeasurementUnit,
} from "@/shared/units/length";
import type { ThickWallElevationPlanSideRenderItem } from "../logic/thickWallElevationPlanRenderItems";

const MEASUREMENT_GUIDE_STROKE = "#4f46e5";
const MEASUREMENT_LABEL_STROKE = "white";
const MEASUREMENT_GUIDE_STROKE_WIDTH_PIXELS = 1.4;
const MEASUREMENT_LABEL_STROKE_WIDTH_PIXELS = 4;
const MEASUREMENT_GUIDE_OFFSET_PIXELS = 44;
const MEASUREMENT_TICK_LENGTH_PIXELS = 10;
const MEASUREMENT_LABEL_FONT_SIZE_PIXELS = 15;
const HORIZONTAL_MEASUREMENT_LABEL_WIDTH_PIXELS = 76;
const HORIZONTAL_MEASUREMENT_LABEL_HEIGHT_PIXELS = 26;
const VERTICAL_MEASUREMENT_LABEL_WIDTH_PIXELS = 44;
const VERTICAL_MEASUREMENT_LABEL_HEIGHT_PIXELS = 36;

type ThickWallElevationPlanMeasurementGuidesProps = Readonly<{
  renderItem: ThickWallElevationPlanSideRenderItem;
  elevationPlanPixelsPerInch: number;
  measurementUnit: MeasurementUnit;
}>;

type MeasurementLabelProps = Readonly<{
  children: string;
  fontSizeInches: number;
  rotate?: number;
  strokeWidthInches: number;
  xInches: number;
  yInches: number;
}>;

function getMeasurementInches(pixels: number, pixelsPerInch: number) {
  return pixels / pixelsPerInch;
}

function MeasurementLabel({
  children,
  fontSizeInches,
  rotate = 0,
  strokeWidthInches,
  xInches,
  yInches,
}: MeasurementLabelProps) {
  return (
    <text
      x={xInches}
      y={yInches}
      textAnchor="middle"
      dominantBaseline="middle"
      transform={
        rotate ? `rotate(${rotate} ${xInches} ${yInches})` : undefined
      }
      className="fill-indigo-600 font-bold"
      fontSize={fontSizeInches}
      paintOrder="stroke"
      stroke={MEASUREMENT_LABEL_STROKE}
      strokeWidth={strokeWidthInches}
      strokeLinejoin="round"
    >
      {children}
    </text>
  );
}

type HorizontalMeasurementGuideProps = Readonly<{
  label: string;
  labelFontSizeInches: number;
  labelStrokeWidthInches: number;
  labelWidthInches: number;
  labelHeightInches: number;
  tickLengthInches: number;
  x1Inches: number;
  x2Inches: number;
  yInches: number;
}>;

function HorizontalMeasurementGuide({
  label,
  labelFontSizeInches,
  labelHeightInches,
  labelStrokeWidthInches,
  labelWidthInches,
  tickLengthInches,
  x1Inches,
  x2Inches,
  yInches,
}: HorizontalMeasurementGuideProps) {
  const centerXInches = (x1Inches + x2Inches) / 2;

  return (
    <g pointerEvents="none">
      <line
        x1={x1Inches}
        y1={yInches}
        x2={x2Inches}
        y2={yInches}
        stroke={MEASUREMENT_GUIDE_STROKE}
        strokeWidth={MEASUREMENT_GUIDE_STROKE_WIDTH_PIXELS}
        vectorEffect="non-scaling-stroke"
      />
      <line
        x1={x1Inches}
        y1={yInches - tickLengthInches / 2}
        x2={x1Inches}
        y2={yInches + tickLengthInches / 2}
        stroke={MEASUREMENT_GUIDE_STROKE}
        strokeWidth={MEASUREMENT_GUIDE_STROKE_WIDTH_PIXELS}
        vectorEffect="non-scaling-stroke"
      />
      <line
        x1={x2Inches}
        y1={yInches - tickLengthInches / 2}
        x2={x2Inches}
        y2={yInches + tickLengthInches / 2}
        stroke={MEASUREMENT_GUIDE_STROKE}
        strokeWidth={MEASUREMENT_GUIDE_STROKE_WIDTH_PIXELS}
        vectorEffect="non-scaling-stroke"
      />
      <rect
        x={centerXInches - labelWidthInches / 2}
        y={yInches - labelHeightInches / 2}
        width={labelWidthInches}
        height={labelHeightInches}
        rx={labelHeightInches / 2}
        fill="white"
      />
      <MeasurementLabel
        xInches={centerXInches}
        yInches={yInches}
        fontSizeInches={labelFontSizeInches}
        strokeWidthInches={labelStrokeWidthInches}
      >
        {label}
      </MeasurementLabel>
    </g>
  );
}

type VerticalMeasurementGuideProps = Readonly<{
  label: string;
  labelFontSizeInches: number;
  labelStrokeWidthInches: number;
  labelWidthInches: number;
  labelHeightInches: number;
  tickLengthInches: number;
  xInches: number;
  y1Inches: number;
  y2Inches: number;
}>;

function VerticalMeasurementGuide({
  label,
  labelFontSizeInches,
  labelHeightInches,
  labelStrokeWidthInches,
  labelWidthInches,
  tickLengthInches,
  xInches,
  y1Inches,
  y2Inches,
}: VerticalMeasurementGuideProps) {
  const centerYInches = (y1Inches + y2Inches) / 2;

  return (
    <g pointerEvents="none">
      <line
        x1={xInches}
        y1={y1Inches}
        x2={xInches}
        y2={y2Inches}
        stroke={MEASUREMENT_GUIDE_STROKE}
        strokeWidth={MEASUREMENT_GUIDE_STROKE_WIDTH_PIXELS}
        vectorEffect="non-scaling-stroke"
      />
      <line
        x1={xInches - tickLengthInches / 2}
        y1={y1Inches}
        x2={xInches + tickLengthInches / 2}
        y2={y1Inches}
        stroke={MEASUREMENT_GUIDE_STROKE}
        strokeWidth={MEASUREMENT_GUIDE_STROKE_WIDTH_PIXELS}
        vectorEffect="non-scaling-stroke"
      />
      <line
        x1={xInches - tickLengthInches / 2}
        y1={y2Inches}
        x2={xInches + tickLengthInches / 2}
        y2={y2Inches}
        stroke={MEASUREMENT_GUIDE_STROKE}
        strokeWidth={MEASUREMENT_GUIDE_STROKE_WIDTH_PIXELS}
        vectorEffect="non-scaling-stroke"
      />
      <rect
        x={xInches - labelWidthInches / 2}
        y={centerYInches - labelHeightInches / 2}
        width={labelWidthInches}
        height={labelHeightInches}
        rx={labelHeightInches / 2}
        fill="white"
      />
      <MeasurementLabel
        xInches={xInches}
        yInches={centerYInches}
        fontSizeInches={labelFontSizeInches}
        strokeWidthInches={labelStrokeWidthInches}
        rotate={-90}
      >
        {label}
      </MeasurementLabel>
    </g>
  );
}

export function ThickWallElevationPlanMeasurementGuides({
  elevationPlanPixelsPerInch,
  measurementUnit,
  renderItem,
}: ThickWallElevationPlanMeasurementGuidesProps) {
  const elevationPlanSizeInches = renderItem.elevationPlan.sizeInches;
  const measurementGuideOffsetInches = getMeasurementInches(
    MEASUREMENT_GUIDE_OFFSET_PIXELS,
    elevationPlanPixelsPerInch,
  );
  const tickLengthInches = getMeasurementInches(
    MEASUREMENT_TICK_LENGTH_PIXELS,
    elevationPlanPixelsPerInch,
  );
  const labelFontSizeInches = getMeasurementInches(
    MEASUREMENT_LABEL_FONT_SIZE_PIXELS,
    elevationPlanPixelsPerInch,
  );
  const labelStrokeWidthInches = getMeasurementInches(
    MEASUREMENT_LABEL_STROKE_WIDTH_PIXELS,
    elevationPlanPixelsPerInch,
  );
  const horizontalLabelWidthInches = getMeasurementInches(
    HORIZONTAL_MEASUREMENT_LABEL_WIDTH_PIXELS,
    elevationPlanPixelsPerInch,
  );
  const horizontalLabelHeightInches = getMeasurementInches(
    HORIZONTAL_MEASUREMENT_LABEL_HEIGHT_PIXELS,
    elevationPlanPixelsPerInch,
  );
  const verticalLabelWidthInches = getMeasurementInches(
    VERTICAL_MEASUREMENT_LABEL_WIDTH_PIXELS,
    elevationPlanPixelsPerInch,
  );
  const verticalLabelHeightInches = getMeasurementInches(
    VERTICAL_MEASUREMENT_LABEL_HEIGHT_PIXELS,
    elevationPlanPixelsPerInch,
  );
  const widthLabel = formatLengthFromInches(
    elevationPlanSizeInches.widthInches,
    measurementUnit,
  );
  const heightLabel = formatLengthFromInches(
    elevationPlanSizeInches.heightInches,
    measurementUnit,
  );

  return (
    <g pointerEvents="none" aria-hidden="true">
      <HorizontalMeasurementGuide
        label={widthLabel}
        x1Inches={0}
        x2Inches={elevationPlanSizeInches.widthInches}
        yInches={-measurementGuideOffsetInches}
        tickLengthInches={tickLengthInches}
        labelFontSizeInches={labelFontSizeInches}
        labelStrokeWidthInches={labelStrokeWidthInches}
        labelWidthInches={horizontalLabelWidthInches}
        labelHeightInches={horizontalLabelHeightInches}
      />

      <VerticalMeasurementGuide
        label={heightLabel}
        xInches={-measurementGuideOffsetInches}
        y1Inches={0}
        y2Inches={elevationPlanSizeInches.heightInches}
        tickLengthInches={tickLengthInches}
        labelFontSizeInches={labelFontSizeInches}
        labelStrokeWidthInches={labelStrokeWidthInches}
        labelWidthInches={verticalLabelWidthInches}
        labelHeightInches={verticalLabelHeightInches}
      />

      <HorizontalMeasurementGuide
        label={widthLabel}
        x1Inches={0}
        x2Inches={elevationPlanSizeInches.widthInches}
        yInches={elevationPlanSizeInches.heightInches + measurementGuideOffsetInches}
        tickLengthInches={tickLengthInches}
        labelFontSizeInches={labelFontSizeInches}
        labelStrokeWidthInches={labelStrokeWidthInches}
        labelWidthInches={horizontalLabelWidthInches}
        labelHeightInches={horizontalLabelHeightInches}
      />
    </g>
  );
}
