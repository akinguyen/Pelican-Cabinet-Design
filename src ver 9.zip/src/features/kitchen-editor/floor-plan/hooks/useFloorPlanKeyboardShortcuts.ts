import { useEffect } from "react";
import type {
  ThickWallSegmentSelection,
  ThinWallSegmentSelection,
} from "@/features/kitchen-editor/state/designStoreTypes";

type UseFloorPlanKeyboardShortcutsParams = Readonly<{
  cancelCandidateThinWallSegment: () => void;
  cancelCandidateThickWallSegment: () => void;
  cancelBasicUnitFloorPlanCandidate: () => void;
  deleteSelectedThinWallSegment: () => void;
  deleteSelectedThickWallSegment: () => void;
  deleteSelectedBasicUnit: () => void;
  isDrawingThinWall: boolean;
  isDrawingThickWall: boolean;
  isPlacingBasicUnit: boolean;
  selectedThinWallSegment: ThinWallSegmentSelection | null;
  selectedThickWallSegment: ThickWallSegmentSelection | null;
  selectedBasicUnitId: string | null;
}>;

function isTypingTarget(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) {
    return false;
  }

  return (
    target.isContentEditable ||
    target instanceof HTMLInputElement ||
    target instanceof HTMLTextAreaElement ||
    target instanceof HTMLSelectElement
  );
}

function isDeleteKey(key: string) {
  return key === "Backspace" || key === "Delete";
}

export function useFloorPlanKeyboardShortcuts({
  cancelCandidateThinWallSegment,
  cancelCandidateThickWallSegment,
  cancelBasicUnitFloorPlanCandidate,
  deleteSelectedThinWallSegment,
  deleteSelectedThickWallSegment,
  deleteSelectedBasicUnit,
  isDrawingThinWall,
  isDrawingThickWall,
  isPlacingBasicUnit,
  selectedThinWallSegment,
  selectedThickWallSegment,
  selectedBasicUnitId,
}: UseFloorPlanKeyboardShortcutsParams) {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (isTypingTarget(event.target)) {
        return;
      }

      if (event.key === "Escape" && isDrawingThinWall) {
        event.preventDefault();
        cancelCandidateThinWallSegment();
        return;
      }

      if (event.key === "Escape" && isDrawingThickWall) {
        event.preventDefault();
        cancelCandidateThickWallSegment();
        return;
      }

      if (event.key === "Escape" && isPlacingBasicUnit) {
        event.preventDefault();
        cancelBasicUnitFloorPlanCandidate();
        return;
      }

      if (isDeleteKey(event.key) && selectedBasicUnitId) {
        event.preventDefault();
        deleteSelectedBasicUnit();
        return;
      }

      if (isDeleteKey(event.key) && selectedThinWallSegment) {
        event.preventDefault();
        deleteSelectedThinWallSegment();
        return;
      }

      if (isDeleteKey(event.key) && selectedThickWallSegment) {
        event.preventDefault();
        deleteSelectedThickWallSegment();
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [
    cancelBasicUnitFloorPlanCandidate,
    cancelCandidateThinWallSegment,
    cancelCandidateThickWallSegment,
    deleteSelectedBasicUnit,
    deleteSelectedThinWallSegment,
    deleteSelectedThickWallSegment,
    isDrawingThinWall,
    isDrawingThickWall,
    isPlacingBasicUnit,
    selectedBasicUnitId,
    selectedThinWallSegment,
    selectedThickWallSegment,
  ]);
}
