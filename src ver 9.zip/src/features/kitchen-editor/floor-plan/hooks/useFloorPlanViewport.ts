import { useCallback, useEffect, useRef } from "react";
import type { RefObject } from "react";
import type { Point2DInches, Point2DPixels, Size2DPixels } from "@/shared/types/geometryTypes";
import { pixelsToInches } from "@/shared/units/length";

type UseFloorPlanViewportParams = Readonly<{
  panOffsetPixels: Point2DPixels;
  floorPlanPixelsPerInch: number;
  centerFloorPlanView: () => void;
  setFloorPlanViewportSizePixels: (sizePixels: Size2DPixels) => void;
}>;

export function getViewportPointPixelsFromClientPointPixels(
  viewportElement: HTMLDivElement,
  clientPointPixels: Point2DPixels,
): Point2DPixels {
  const rect = viewportElement.getBoundingClientRect();

  return {
    xPixels: clientPointPixels.xPixels - rect.left,
    yPixels: clientPointPixels.yPixels - rect.top,
  };
}

export function getFloorPlanPointInchesFromViewportPointPixels(
  viewportPointPixels: Point2DPixels,
  panOffsetPixels: Point2DPixels,
  floorPlanPixelsPerInch: number,
): Point2DInches {
  return {
    xInches: pixelsToInches(viewportPointPixels.xPixels - panOffsetPixels.xPixels, floorPlanPixelsPerInch),
    yInches: pixelsToInches(viewportPointPixels.yPixels - panOffsetPixels.yPixels, floorPlanPixelsPerInch),
  };
}

export function useFloorPlanViewport({
  panOffsetPixels,
  floorPlanPixelsPerInch,
  centerFloorPlanView,
  setFloorPlanViewportSizePixels,
}: UseFloorPlanViewportParams): Readonly<{
  floorPlanViewportRef: RefObject<HTMLDivElement | null>;
  getFloorPlanPointInchesFromClientPointPixels: (clientPointPixels: Point2DPixels) => Point2DInches | null;
}> {
  const floorPlanViewportRef = useRef<HTMLDivElement | null>(null);
  const hasCenteredInitialViewRef = useRef(false);

  const getFloorPlanPointInchesFromClientPointPixels = useCallback(
    (clientPointPixels: Point2DPixels): Point2DInches | null => {
      const viewportElement = floorPlanViewportRef.current;

      if (!viewportElement) {
        return null;
      }

      const viewportPointPixels = getViewportPointPixelsFromClientPointPixels(
        viewportElement,
        clientPointPixels,
      );

      return getFloorPlanPointInchesFromViewportPointPixels(
        viewportPointPixels,
        panOffsetPixels,
        floorPlanPixelsPerInch,
      );
    },
    [panOffsetPixels.xPixels, panOffsetPixels.yPixels, floorPlanPixelsPerInch],
  );

  useEffect(() => {
    const viewportElement = floorPlanViewportRef.current;

    if (!viewportElement) {
      return;
    }

    const updateViewportSize = () => {
      const rect = viewportElement.getBoundingClientRect();

      setFloorPlanViewportSizePixels({
        widthPixels: rect.width,
        heightPixels: rect.height,
      });

      if (!hasCenteredInitialViewRef.current && rect.width > 0 && rect.height > 0) {
        centerFloorPlanView();
        hasCenteredInitialViewRef.current = true;
      }
    };

    updateViewportSize();

    const resizeObserver = new ResizeObserver(updateViewportSize);
    resizeObserver.observe(viewportElement);

    return () => {
      resizeObserver.disconnect();
    };
  }, [centerFloorPlanView, setFloorPlanViewportSizePixels]);

  return {
    floorPlanViewportRef,
    getFloorPlanPointInchesFromClientPointPixels,
  };
}
