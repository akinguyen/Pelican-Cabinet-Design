import {
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
  type RefObject,
} from "react";
import { pixelsToInches } from "@/shared/units/length";
import {
  distanceBetweenPixelPoints,
  getSegmentMidpoint,
} from "@/shared/math/geometry";
import type { Point2DInches, Point2DPixels } from "@/shared/types/geometryTypes";
import type { PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";
import type { PlacedThickWallChain, PlacedThinWallChain } from "@/domains/walls/model/wallTypes";
import type {
  ThickWallSegmentSelection,
  ThinWallSegmentSelection,
} from "@/features/kitchen-editor/state/designStoreTypes";
import { getBasicUnitAtPoint2DInches } from "@/features/kitchen-editor/floor-plan/basic-units/logic/basicUnitFloorPlanHitTesting";
import { getThickWallSegmentAtPoint2DInches } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallFloorPlanHitTesting";
import { getThinWallSegmentAtPoint2DInches } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanHitTesting";
import { getViewportPointPixelsFromClientPointPixels } from "./useFloorPlanViewport";

type ThinWallDrawingController = Readonly<{
  isDrawingThinWall: boolean;
  placePoint: (pointInches: Point2DInches) => void;
  updateCandidatePoint: (pointInches: Point2DInches | null) => void;
}>;

type ThickWallDrawingController = Readonly<{
  isDrawingThickWall: boolean;
  placePoint: (pointInches: Point2DInches) => void;
  updateCandidatePoint: (pointInches: Point2DInches | null) => void;
}>;

type BasicUnitPlacementController = Readonly<{
  isPlacingBasicUnit: boolean;
  placePoint: (pointInches: Point2DInches) => void;
  updateCandidatePoint: (pointInches: Point2DInches | null) => void;
}>;

type UseFloorPlanCanvasPointerHandlersParams = Readonly<{
  floorPlanPixelsPerInch: number;
  getFloorPlanPointInchesFromClientPointPixels: (
    clientPointPixels: Point2DPixels,
  ) => Point2DInches | null;
  panFloorPlanBy: (deltaPixels: Point2DPixels) => void;
  selectThinWallSegment: (selection: ThinWallSegmentSelection | null) => void;
  selectThickWallSegment: (selection: ThickWallSegmentSelection | null) => void;
  clearWallSegmentSelection: () => void;
  selectBasicUnit: (basicUnitId: string | null) => void;
  placedBasicUnits: readonly PlacedBasicUnit[];
  placedThinWallChains: readonly PlacedThinWallChain[];
  placedThickWallChains: readonly PlacedThickWallChain[];
  basicUnitPlacement: BasicUnitPlacementController;
  thinWallDrawing: ThinWallDrawingController;
  thickWallDrawing: ThickWallDrawingController;
  floorPlanViewportRef: RefObject<HTMLDivElement | null>;
  zoomFloorPlanByAtPoint: (
    viewportPointPixels: Point2DPixels,
    zoomFactor: number,
  ) => void;
}>;

const CLICK_DISTANCE_THRESHOLD_PIXELS = 4;
const WALL_HIT_THRESHOLD_PIXELS = 10;

function getClientPointPixels(
  event: ReactPointerEvent<HTMLDivElement>,
): Point2DPixels {
  return {
    xPixels: event.clientX,
    yPixels: event.clientY,
  };
}

export function useFloorPlanCanvasPointerHandlers({
  floorPlanPixelsPerInch,
  getFloorPlanPointInchesFromClientPointPixels,
  panFloorPlanBy,
  selectThinWallSegment,
  selectThickWallSegment,
  clearWallSegmentSelection,
  selectBasicUnit,
  placedBasicUnits,
  placedThinWallChains,
  placedThickWallChains,
  basicUnitPlacement,
  thinWallDrawing,
  thickWallDrawing,
  floorPlanViewportRef,
  zoomFloorPlanByAtPoint,
}: UseFloorPlanCanvasPointerHandlersParams) {
  const activePointersRef = useRef<Map<number, Point2DPixels>>(new Map());
  const lastPanPointPixelsRef = useRef<Point2DPixels | null>(null);
  const pointerDownPointPixelsRef = useRef<Point2DPixels | null>(null);
  const lastPinchDistancePixelsRef = useRef<number | null>(null);
  const [isPanning, setIsPanning] = useState(false);
  const isCreatingFloorPlanObject =
    thinWallDrawing.isDrawingThinWall ||
    thickWallDrawing.isDrawingThickWall ||
    basicUnitPlacement.isPlacingBasicUnit;

  const clearPointerInteraction = () => {
    activePointersRef.current.clear();
    lastPanPointPixelsRef.current = null;
    pointerDownPointPixelsRef.current = null;
    lastPinchDistancePixelsRef.current = null;
    setIsPanning(false);
  };

  const endPointerInteraction = (event: ReactPointerEvent<HTMLDivElement>) => {
    activePointersRef.current.delete(event.pointerId);

    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }

    const remainingPointersPixels = [...activePointersRef.current.values()];

    if (remainingPointersPixels.length === 0) {
      clearPointerInteraction();
      return;
    }

    if (remainingPointersPixels.length === 1) {
      lastPanPointPixelsRef.current = remainingPointersPixels[0];
      lastPinchDistancePixelsRef.current = null;
    }
  };

  const handlePointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (event.pointerType === "mouse" && event.button !== 0) {
      return;
    }

    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);

    const currentPointPixels = getClientPointPixels(event);

    if (isCreatingFloorPlanObject) {
      return;
    }

    activePointersRef.current.set(event.pointerId, currentPointPixels);
    pointerDownPointPixelsRef.current = currentPointPixels;
    lastPanPointPixelsRef.current = currentPointPixels;
  };

  const handleCreationPointerMove = (currentPointPixels: Point2DPixels) => {
    const floorPlanPointInches =
      getFloorPlanPointInchesFromClientPointPixels(currentPointPixels);

    if (!floorPlanPointInches) {
      return;
    }

    if (thinWallDrawing.isDrawingThinWall) {
      thinWallDrawing.updateCandidatePoint(floorPlanPointInches);
      return;
    }

    if (thickWallDrawing.isDrawingThickWall) {
      thickWallDrawing.updateCandidatePoint(floorPlanPointInches);
      return;
    }

    if (basicUnitPlacement.isPlacingBasicUnit) {
      basicUnitPlacement.updateCandidatePoint(floorPlanPointInches);
    }
  };

  const handlePointerMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    const currentPointPixels = getClientPointPixels(event);

    if (isCreatingFloorPlanObject) {
      handleCreationPointerMove(currentPointPixels);
      return;
    }

    if (!activePointersRef.current.has(event.pointerId)) {
      return;
    }

    if (event.pointerType === "mouse" && event.buttons !== 1) {
      endPointerInteraction(event);
      return;
    }

    event.preventDefault();
    activePointersRef.current.set(event.pointerId, currentPointPixels);

    const activePointersPixels = [...activePointersRef.current.values()];

    if (activePointersPixels.length >= 2) {
      const [firstPointerPixels, secondPointerPixels] = activePointersPixels;
      const nextPinchDistancePixels = distanceBetweenPixelPoints(
        firstPointerPixels,
        secondPointerPixels,
      );
      const previousPinchDistancePixels = lastPinchDistancePixelsRef.current;
      const viewportElement = floorPlanViewportRef.current;

      if (
        previousPinchDistancePixels &&
        previousPinchDistancePixels > 0 &&
        nextPinchDistancePixels > 0 &&
        viewportElement
      ) {
        const midpointPixels = getSegmentMidpoint(
          {
            xInches: firstPointerPixels.xPixels,
            yInches: firstPointerPixels.yPixels,
          },
          {
            xInches: secondPointerPixels.xPixels,
            yInches: secondPointerPixels.yPixels,
          },
        );

        zoomFloorPlanByAtPoint(
          getViewportPointPixelsFromClientPointPixels(viewportElement, {
            xPixels: midpointPixels.xInches,
            yPixels: midpointPixels.yInches,
          }),
          nextPinchDistancePixels / previousPinchDistancePixels,
        );
      }

      setIsPanning(true);
      lastPinchDistancePixelsRef.current = nextPinchDistancePixels;
      return;
    }

    const pointerDownPointPixels = pointerDownPointPixelsRef.current;

    if (
      !isPanning &&
      pointerDownPointPixels &&
      distanceBetweenPixelPoints(pointerDownPointPixels, currentPointPixels) <=
        CLICK_DISTANCE_THRESHOLD_PIXELS
    ) {
      return;
    }

    const lastPanPointPixels = lastPanPointPixelsRef.current;

    if (!lastPanPointPixels) {
      lastPanPointPixelsRef.current = currentPointPixels;
      return;
    }

    if (!isPanning) {
      setIsPanning(true);
      lastPanPointPixelsRef.current = currentPointPixels;
      return;
    }

    panFloorPlanBy({
      xPixels: currentPointPixels.xPixels - lastPanPointPixels.xPixels,
      yPixels: currentPointPixels.yPixels - lastPanPointPixels.yPixels,
    });

    lastPanPointPixelsRef.current = currentPointPixels;
  };

  const handleCreationPointerUp = (
    event: ReactPointerEvent<HTMLDivElement>,
    floorPlanPointInches: Point2DInches | null,
  ) => {
    if (floorPlanPointInches) {
      if (thinWallDrawing.isDrawingThinWall) {
        thinWallDrawing.placePoint(floorPlanPointInches);
      } else if (thickWallDrawing.isDrawingThickWall) {
        thickWallDrawing.placePoint(floorPlanPointInches);
      } else if (basicUnitPlacement.isPlacingBasicUnit) {
        basicUnitPlacement.placePoint(floorPlanPointInches);
      }
    }

    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
  };

  const handlePointerUp = (event: ReactPointerEvent<HTMLDivElement>) => {
    const currentClientPointPixels = getClientPointPixels(event);
    const floorPlanPointInches = getFloorPlanPointInchesFromClientPointPixels(
      currentClientPointPixels,
    );

    if (isCreatingFloorPlanObject) {
      handleCreationPointerUp(event, floorPlanPointInches);
      return;
    }

    const pointerDownPointPixels = pointerDownPointPixelsRef.current;
    const isClick = pointerDownPointPixels
      ? distanceBetweenPixelPoints(
          pointerDownPointPixels,
          currentClientPointPixels,
        ) <= CLICK_DISTANCE_THRESHOLD_PIXELS
      : false;

    if (isClick && floorPlanPointInches) {
      const basicUnitId = getBasicUnitAtPoint2DInches(
        floorPlanPointInches,
        placedBasicUnits,
      );

      if (basicUnitId) {
        selectBasicUnit(basicUnitId);
      } else {
        const wallHitThresholdInches =
          pixelsToInches(WALL_HIT_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
        const thickWallSelection = getThickWallSegmentAtPoint2DInches(
          floorPlanPointInches,
          placedThickWallChains,
          wallHitThresholdInches,
        );

        if (thickWallSelection) {
          selectThickWallSegment(thickWallSelection);
        } else {
          const thinWallSelection = getThinWallSegmentAtPoint2DInches(
            floorPlanPointInches,
            placedThinWallChains,
            wallHitThresholdInches,
          );

          if (thinWallSelection) {
            selectThinWallSegment(thinWallSelection);
          } else {
            clearWallSegmentSelection();
            selectBasicUnit(null);
          }
        }
      }
    }

    endPointerInteraction(event);
  };

  return {
    isPanning,
    pointerHandlers: {
      onPointerCancel: endPointerInteraction,
      onPointerDown: handlePointerDown,
      onPointerLeave: (event: ReactPointerEvent<HTMLDivElement>) => {
        if (event.pointerType === "mouse" && event.buttons !== 1) {
          endPointerInteraction(event);
        }
      },
      onPointerMove: handlePointerMove,
      onPointerUp: handlePointerUp,
    },
  };
}
