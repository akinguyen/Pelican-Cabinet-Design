import { useEffect, type RefObject } from "react";
import type { Point2DPixels } from "@/shared/types/geometryTypes";
import { getViewportPointPixelsFromClientPointPixels } from "./useFloorPlanViewport";

type UseFloorPlanWheelZoomParams = Readonly<{
  floorPlanViewportRef: RefObject<HTMLDivElement | null>;
  zoomFloorPlanByAtPoint: (viewportPointPixels: Point2DPixels, zoomFactor: number) => void;
}>;

function getNormalizedWheelDeltaY(event: WheelEvent) {
  if (event.deltaMode === WheelEvent.DOM_DELTA_LINE) {
    return event.deltaY * 16;
  }

  if (event.deltaMode === WheelEvent.DOM_DELTA_PAGE) {
    return event.deltaY * window.innerHeight;
  }

  return event.deltaY;
}

export function useFloorPlanWheelZoom({
  floorPlanViewportRef,
  zoomFloorPlanByAtPoint,
}: UseFloorPlanWheelZoomParams) {
  useEffect(() => {
    const viewportElement = floorPlanViewportRef.current;

    if (!viewportElement) {
      return;
    }

    const preventBrowserZoomOrScroll = (event: Event) => {
      if (event.cancelable) {
        event.preventDefault();
      }

      event.stopPropagation();
    };

    const handleWheel = (event: WheelEvent) => {
      preventBrowserZoomOrScroll(event);

      const normalizedDeltaY = getNormalizedWheelDeltaY(event);
      const zoomFactor = Math.exp(-normalizedDeltaY * 0.0015);

      zoomFloorPlanByAtPoint(
        getViewportPointPixelsFromClientPointPixels(viewportElement, {
          xPixels: event.clientX,
          yPixels: event.clientY,
        }),
        zoomFactor,
      );
    };

    const listenerOptions: AddEventListenerOptions = {
      passive: false,
    };

    viewportElement.addEventListener("wheel", handleWheel, listenerOptions);
    viewportElement.addEventListener("gesturestart", preventBrowserZoomOrScroll, listenerOptions);
    viewportElement.addEventListener("gesturechange", preventBrowserZoomOrScroll, listenerOptions);
    viewportElement.addEventListener("gestureend", preventBrowserZoomOrScroll, listenerOptions);

    return () => {
      viewportElement.removeEventListener("wheel", handleWheel);
      viewportElement.removeEventListener("gesturestart", preventBrowserZoomOrScroll);
      viewportElement.removeEventListener("gesturechange", preventBrowserZoomOrScroll);
      viewportElement.removeEventListener("gestureend", preventBrowserZoomOrScroll);
    };
  }, [floorPlanViewportRef, zoomFloorPlanByAtPoint]);
}
