"use client";

import { useMemo, type CSSProperties } from "react";
import { inchesToPixels } from "@/shared/units/length";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";
import {
  FLOOR_PLAN_SIZE_INCHES,
  useUiStore,
} from "@/features/kitchen-editor/state/useUIStore";
import { useFloorPlanViewport } from "@/features/kitchen-editor/floor-plan/hooks/useFloorPlanViewport";
import { useFloorPlanWheelZoom } from "@/features/kitchen-editor/floor-plan/hooks/useFloorPlanWheelZoom";
import { useFloorPlanCanvasPointerHandlers } from "@/features/kitchen-editor/floor-plan/hooks/useFloorPlanCanvasPointerHandlers";
import { BasicUnitFloorPlanCandidateLayer } from "@/features/kitchen-editor/floor-plan/basic-units/components/BasicUnitFloorPlanCandidateLayer";
import { BasicUnitFloorPlanLayer } from "@/features/kitchen-editor/floor-plan/basic-units/components/BasicUnitFloorPlanLayer";
import { useBasicUnitFloorPlanPlacement } from "@/features/kitchen-editor/floor-plan/basic-units/logic/useBasicUnitFloorPlanPlacement";
import { useThickWallFloorPlanDrawing } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/useThickWallFloorPlanDrawing";
import { useThinWallFloorPlanDrawing } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/useThinWallFloorPlanDrawing";
import { useFloorPlanKeyboardShortcuts } from "@/features/kitchen-editor/floor-plan/hooks/useFloorPlanKeyboardShortcuts";
import { FloorPlanWallLayers } from "./FloorPlanWallLayers";
import { FloorPlanGridGuides } from "./FloorPlanGridGuides";
import { getThickWallFloorPlanCandidateChains } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallFloorPlanCandidateGeometry";

type FloorPlanCanvasAreaProps = Readonly<{
  label?: string;
}>;

export function FloorPlanCanvasArea({
  label = "Floor plan canvas",
}: FloorPlanCanvasAreaProps) {
  const panOffsetPixels = useUiStore((state) => state.panOffsetPixels);
  const floorPlanPixelsPerInch = useUiStore((state) => state.floorPlanPixelsPerInch);
  const measurementUnit = useUiStore((state) => state.measurementUnit);
  const setFloorPlanViewportSizePixels = useUiStore(
    (state) => state.setFloorPlanViewportSizePixels,
  );
  const panFloorPlanBy = useUiStore((state) => state.panFloorPlanBy);
  const zoomFloorPlanByAtPoint = useUiStore((state) => state.zoomFloorPlanByAtPoint);
  const centerFloorPlanView = useUiStore((state) => state.centerFloorPlanView);

  const activeTool = useDesignStore((state) => state.activeTool);
  const placedThinWallChains = useDesignStore((state) => state.placedThinWallChains);
  const placedThickWallChains = useDesignStore((state) => state.placedThickWallChains);
  const placedBasicUnits = useDesignStore((state) => state.placedBasicUnits);
  const basicUnitFloorPlanCandidate = useDesignStore(
    (state) => state.basicUnitFloorPlanCandidate,
  );
  const selectedBasicUnitId = useDesignStore((state) => state.selectedBasicUnitId);
  const selectedThinWallSegment = useDesignStore(
    (state) => state.selectedThinWallSegment,
  );
  const selectedThickWallSegment = useDesignStore(
    (state) => state.selectedThickWallSegment,
  );
  const selectThinWallSegment = useDesignStore(
    (state) => state.selectThinWallSegment,
  );
  const selectThickWallSegment = useDesignStore(
    (state) => state.selectThickWallSegment,
  );
  const clearWallSegmentSelection = useDesignStore(
    (state) => state.clearWallSegmentSelection,
  );
  const selectBasicUnit = useDesignStore((state) => state.selectBasicUnit);
  const cancelCandidateThinWallSegment = useDesignStore(
    (state) => state.cancelCandidateThinWallSegment,
  );
  const cancelCandidateThickWallSegment = useDesignStore(
    (state) => state.cancelCandidateThickWallSegment,
  );
  const deleteSelectedThinWallSegment = useDesignStore(
    (state) => state.deleteSelectedThinWallSegment,
  );
  const deleteSelectedThickWallSegment = useDesignStore(
    (state) => state.deleteSelectedThickWallSegment,
  );
  const cancelBasicUnitFloorPlanCandidate = useDesignStore(
    (state) => state.cancelBasicUnitFloorPlanCandidate,
  );
  const deleteSelectedBasicUnit = useDesignStore(
    (state) => state.deleteSelectedBasicUnit,
  );
  const thinWallDrawing = useThinWallFloorPlanDrawing({ floorPlanPixelsPerInch });
  const thickWallDrawing = useThickWallFloorPlanDrawing({ floorPlanPixelsPerInch });
  const basicUnitPlacement = useBasicUnitFloorPlanPlacement({
    floorPlanSizeInches: FLOOR_PLAN_SIZE_INCHES,
  });
  const { floorPlanViewportRef, getFloorPlanPointInchesFromClientPointPixels } = useFloorPlanViewport({
    panOffsetPixels,
    floorPlanPixelsPerInch,
    centerFloorPlanView,
    setFloorPlanViewportSizePixels,
  });

  const { isPanning, pointerHandlers } = useFloorPlanCanvasPointerHandlers({
    floorPlanPixelsPerInch,
    getFloorPlanPointInchesFromClientPointPixels,
    panFloorPlanBy,
    selectThinWallSegment,
    selectThickWallSegment,
    clearWallSegmentSelection,
    selectBasicUnit,
    placedBasicUnits,
    placedThinWallChains,
    placedThickWallChains,
    basicUnitPlacement,
    thinWallDrawing,
    thickWallDrawing,
    floorPlanViewportRef,
    zoomFloorPlanByAtPoint,
  });

  useFloorPlanWheelZoom({ floorPlanViewportRef, zoomFloorPlanByAtPoint });

  useFloorPlanKeyboardShortcuts({
    cancelCandidateThinWallSegment,
    cancelCandidateThickWallSegment,
    cancelBasicUnitFloorPlanCandidate,
    deleteSelectedThinWallSegment,
    deleteSelectedThickWallSegment,
    deleteSelectedBasicUnit,
    isDrawingThinWall: activeTool === "draw-thin-wall",
    isDrawingThickWall: activeTool === "draw-thick-wall",
    isPlacingBasicUnit: activeTool === "place-basic-unit",
    selectedThinWallSegment,
    selectedThickWallSegment,
    selectedBasicUnitId,
  });

  const isCreatingFloorPlanObject =
    thinWallDrawing.isDrawingThinWall ||
    thickWallDrawing.isDrawingThickWall ||
    basicUnitPlacement.isPlacingBasicUnit;
  const renderedThickWallChains = useMemo(
    () =>
      getThickWallFloorPlanCandidateChains({
        candidateThickWallSegment: thickWallDrawing.candidateThickWallSegment,
        chains: placedThickWallChains,
      }),
    [placedThickWallChains, thickWallDrawing.candidateThickWallSegment],
  );
  const thickWallCandidateSegment = useMemo(() => {
    const candidate = thickWallDrawing.candidateThickWallSegment;

    if (
      !thickWallDrawing.isDrawingThickWall ||
      !candidate?.chainId ||
      !thickWallDrawing.candidatePoint
    ) {
      return null;
    }

    const renderedActiveChain = renderedThickWallChains.find(
      (chain) => chain.id === candidate.chainId,
    );

    if (!renderedActiveChain || renderedActiveChain.floorPlan.centerlinePointsInches.length < 2) {
      return null;
    }

    return {
      type: "thick-wall-segment" as const,
      chainId: renderedActiveChain.id,
      segmentIndex: renderedActiveChain.floorPlan.centerlinePointsInches.length - 2,
    };
  }, [
    renderedThickWallChains,
    thickWallDrawing.candidatePoint,
    thickWallDrawing.candidateThickWallSegment,
    thickWallDrawing.isDrawingThickWall,
  ]);
  const hiddenThinWallTerminalEndpoint =
    activeTool === "draw-thin-wall" && thinWallDrawing.activeChain
      ? thinWallDrawing.activeChain.floorPlan.centerlinePointsInches[
          thinWallDrawing.activeChain.floorPlan.centerlinePointsInches.length - 1
        ]
      : null;
  const hiddenThickWallTerminalEndpoint =
    activeTool === "draw-thick-wall" && thickWallDrawing.activeChain
      ? thickWallDrawing.activeChain.floorPlan.centerlinePointsInches[
          thickWallDrawing.activeChain.floorPlan.centerlinePointsInches.length - 1
        ]
      : null;
  const floorPlanEditableAreaSvgStylePixels: CSSProperties = {
    width: inchesToPixels(FLOOR_PLAN_SIZE_INCHES.widthInches, floorPlanPixelsPerInch),
    height: inchesToPixels(FLOOR_PLAN_SIZE_INCHES.heightInches, floorPlanPixelsPerInch),
    transform: `translate3d(${panOffsetPixels.xPixels}px, ${panOffsetPixels.yPixels}px, 0)`,
    transformOrigin: "0 0",
    willChange: "transform",
  };

  return (
    <div
      ref={floorPlanViewportRef}
      aria-label={label}
      className={[
        "relative min-h-0 flex-1 overflow-hidden bg-slate-100 overscroll-none touch-none select-none",
        isCreatingFloorPlanObject
          ? "cursor-crosshair"
          : isPanning
            ? "cursor-grabbing"
            : "cursor-default",
      ].join(" ")}
      {...pointerHandlers}
    >
      <svg
        className="absolute left-0 top-0 overflow-hidden border border-slate-200 bg-white shadow-sm"
        style={floorPlanEditableAreaSvgStylePixels}
        viewBox={`0 0 ${FLOOR_PLAN_SIZE_INCHES.widthInches} ${FLOOR_PLAN_SIZE_INCHES.heightInches}`}
      >
        <FloorPlanGridGuides floorPlanSizeInches={FLOOR_PLAN_SIZE_INCHES} />

        <FloorPlanWallLayers
          floorPlanSizeInches={FLOOR_PLAN_SIZE_INCHES}
          hiddenThickWallTerminalEndpointInches={hiddenThickWallTerminalEndpoint}
          hiddenThinWallTerminalEndpointInches={hiddenThinWallTerminalEndpoint}
          measurementUnit={measurementUnit}
          placedThickWallChains={placedThickWallChains}
          placedThinWallChains={placedThinWallChains}
          renderedThickWallChains={renderedThickWallChains}
          selectedThickWallSegment={selectedThickWallSegment}
          selectedThinWallSegment={selectedThinWallSegment}
          thickWallCandidateSegment={thickWallCandidateSegment}
          thickWallDrawing={thickWallDrawing}
          thinWallDrawing={thinWallDrawing}
        />

        <BasicUnitFloorPlanLayer
          placedBasicUnits={placedBasicUnits}
          selectedBasicUnitId={selectedBasicUnitId}
        />

        <BasicUnitFloorPlanCandidateLayer
          basicUnitFloorPlanCandidate={basicUnitFloorPlanCandidate}
          floorPlanSizeInches={FLOOR_PLAN_SIZE_INCHES}
        />
      </svg>
    </div>
  );
}
