import type { MeasurementUnit } from "@/shared/units/length";
import type { Point2DInches, Size2DInches } from "@/shared/types/geometryTypes";
import type {
  PlacedThickWallChain,
  PlacedThinWallChain,
} from "@/domains/walls/model/wallTypes";
import type {
  ThickWallSegmentSelection,
  ThinWallSegmentSelection,
} from "@/features/kitchen-editor/state/designStoreTypes";
import type { useThinWallFloorPlanDrawing } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/useThinWallFloorPlanDrawing";
import type { useThickWallFloorPlanDrawing } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/useThickWallFloorPlanDrawing";
import { ThickWallFloorPlanCandidateLayer } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/components/ThickWallFloorPlanCandidateLayer";
import { ThickWallFloorPlanLayer } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/components/ThickWallFloorPlanLayer";
import { ThickWallFloorPlanReferenceGuides } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/components/ThickWallFloorPlanReferenceGuides";
import { ThickWallFloorPlanSnapPointMarker } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/components/ThickWallFloorPlanSnapPointMarker";
import { ThinWallFloorPlanCandidateLayer } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/components/ThinWallFloorPlanCandidateLayer";
import { ThinWallFloorPlanLayer } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/components/ThinWallFloorPlanLayer";
import { ThinWallFloorPlanReferenceGuides } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/components/ThinWallFloorPlanReferenceGuides";
import { ThinWallFloorPlanSnapPointMarker } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/components/ThinWallFloorPlanSnapPointMarker";

type ThinWallDrawingState = ReturnType<typeof useThinWallFloorPlanDrawing>;
type ThickWallDrawingState = ReturnType<typeof useThickWallFloorPlanDrawing>;

type ThickWallCandidateSegmentSelection = Readonly<{
  type: "thick-wall-segment";
  chainId: string;
  segmentIndex: number;
}> | null;

type FloorPlanWallLayersProps = Readonly<{
  floorPlanSizeInches: Size2DInches;
  measurementUnit: MeasurementUnit;
  placedThinWallChains: readonly PlacedThinWallChain[];
  renderedThickWallChains: readonly PlacedThickWallChain[];
  placedThickWallChains: readonly PlacedThickWallChain[];
  selectedThinWallSegment: ThinWallSegmentSelection | null;
  selectedThickWallSegment: ThickWallSegmentSelection | null;
  thickWallCandidateSegment: ThickWallCandidateSegmentSelection;
  hiddenThinWallTerminalEndpointInches: Point2DInches | null;
  hiddenThickWallTerminalEndpointInches: Point2DInches | null;
  thinWallDrawing: ThinWallDrawingState;
  thickWallDrawing: ThickWallDrawingState;
}>;

export function FloorPlanWallLayers({
  floorPlanSizeInches,
  measurementUnit,
  placedThinWallChains,
  renderedThickWallChains,
  placedThickWallChains,
  selectedThinWallSegment,
  selectedThickWallSegment,
  thickWallCandidateSegment,
  hiddenThinWallTerminalEndpointInches,
  hiddenThickWallTerminalEndpointInches,
  thinWallDrawing,
  thickWallDrawing,
}: FloorPlanWallLayersProps) {
  return (
    <>
      <ThickWallFloorPlanLayer
        candidateSegment={thickWallCandidateSegment}
        chains={renderedThickWallChains}
        hiddenTerminalEndpoint={hiddenThickWallTerminalEndpointInches}
        measurementUnit={measurementUnit}
        selectedSegment={selectedThickWallSegment}
      />

      <ThinWallFloorPlanLayer
        chains={placedThinWallChains}
        hiddenTerminalEndpoint={hiddenThinWallTerminalEndpointInches}
        measurementUnit={measurementUnit}
        selectedSegment={selectedThinWallSegment}
      />

      {thinWallDrawing.isDrawingThinWall ? (
        <>
          <ThinWallFloorPlanReferenceGuides
            constructedReferenceGuide={thinWallDrawing.constructedReferenceGuide}
            floorPlanSizeInches={floorPlanSizeInches}
            originInches={thinWallDrawing.origin}
          />
          <ThinWallFloorPlanCandidateLayer
            candidateThinWallSegment={thinWallDrawing.candidateThinWallSegment}
            measurementUnit={measurementUnit}
          />
          <ThinWallFloorPlanSnapPointMarker
            markerPointInches={
              thinWallDrawing.isCatalogStart
                ? thinWallDrawing.catalogStartMarkerPoint2DInches
                : null
            }
            snapPointInches={
              thinWallDrawing.isCatalogStart ? thinWallDrawing.hoveredSnapPoint : null
            }
          />
        </>
      ) : null}

      {thickWallDrawing.isDrawingThickWall ? (
        <>
          <ThickWallFloorPlanReferenceGuides
            constructedReferenceGuide={thickWallDrawing.constructedReferenceGuide}
            floorPlanSizeInches={floorPlanSizeInches}
            originInches={thickWallDrawing.origin}
          />
          <ThickWallFloorPlanCandidateLayer
            candidateSegmentRenderMode={
              thickWallDrawing.candidateThickWallSegment?.chainId
                ? "guides-only"
                : "segment-and-guides"
            }
            candidateThickWallSegment={thickWallDrawing.candidateThickWallSegment}
            hoveredSnapPoint={thickWallDrawing.hoveredSnapPoint}
            measurementUnit={measurementUnit}
          />
          <ThickWallFloorPlanSnapPointMarker
            chains={placedThickWallChains}
            markerPointInches={
              thickWallDrawing.isCatalogStart
                ? thickWallDrawing.catalogStartMarkerPoint2DInches
                : null
            }
            snapPointInches={
              thickWallDrawing.isCatalogStart ? thickWallDrawing.hoveredSnapPoint : null
            }
          />
        </>
      ) : null}
    </>
  );
}
