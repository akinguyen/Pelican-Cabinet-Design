"use client";

import { FloorPlanCanvasArea } from "./FloorPlanCanvasArea";
import { FloorPlanControls } from "./FloorPlanControls";

export function FloorPlanEditor() {
  return (
    <section className="flex h-full min-w-0 flex-1 flex-col bg-slate-50">
      <FloorPlanControls />
      <FloorPlanCanvasArea />
    </section>
  );
}
