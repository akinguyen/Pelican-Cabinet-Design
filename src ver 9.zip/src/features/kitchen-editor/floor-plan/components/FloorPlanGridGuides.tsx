import type { Size2DInches } from "@/shared/types/geometryTypes";

const FLOOR_PLAN_GRID_SPACING_INCHES = 12;
const FLOOR_PLAN_MAJOR_GRID_SPACING_INCHES = 60;
const GRID_OFFSET_TOLERANCE_INCHES = 0.001;

type FloorPlanGridGuidesProps = Readonly<{
  floorPlanSizeInches: Size2DInches;
}>;

function getGridOffsetsInches(
  maxOffsetInches: number,
  spacingInches: number,
): readonly number[] {
  const offsetsInches: number[] = [];

  for (
    let offsetInches = 0;
    offsetInches <= maxOffsetInches + GRID_OFFSET_TOLERANCE_INCHES;
    offsetInches += spacingInches
  ) {
    offsetsInches.push(Number(offsetInches.toFixed(4)));
  }

  return offsetsInches;
}

function isMajorGridOffset(offsetInches: number) {
  return (
    Math.abs(offsetInches % FLOOR_PLAN_MAJOR_GRID_SPACING_INCHES) <=
      GRID_OFFSET_TOLERANCE_INCHES ||
    Math.abs(
      FLOOR_PLAN_MAJOR_GRID_SPACING_INCHES -
        (offsetInches % FLOOR_PLAN_MAJOR_GRID_SPACING_INCHES),
    ) <= GRID_OFFSET_TOLERANCE_INCHES
  );
}

export function FloorPlanGridGuides({
  floorPlanSizeInches,
}: FloorPlanGridGuidesProps) {
  const verticalGridOffsetsInches = getGridOffsetsInches(
    floorPlanSizeInches.widthInches,
    FLOOR_PLAN_GRID_SPACING_INCHES,
  );
  const horizontalGridOffsetsInches = getGridOffsetsInches(
    floorPlanSizeInches.heightInches,
    FLOOR_PLAN_GRID_SPACING_INCHES,
  );

  return (
    <g pointerEvents="none" aria-hidden="true">
      {verticalGridOffsetsInches.map((xInches) => (
        <line
          key={`vertical-grid-${xInches}`}
          x1={xInches}
          y1={0}
          x2={xInches}
          y2={floorPlanSizeInches.heightInches}
          stroke={isMajorGridOffset(xInches) ? "#cbd5e1" : "#e2e8f0"}
          strokeWidth={isMajorGridOffset(xInches) ? 1.25 : 0.75}
          vectorEffect="non-scaling-stroke"
        />
      ))}
      {horizontalGridOffsetsInches.map((yInches) => (
        <line
          key={`horizontal-grid-${yInches}`}
          x1={0}
          y1={yInches}
          x2={floorPlanSizeInches.widthInches}
          y2={yInches}
          stroke={isMajorGridOffset(yInches) ? "#cbd5e1" : "#e2e8f0"}
          strokeWidth={isMajorGridOffset(yInches) ? 1.25 : 0.75}
          vectorEffect="non-scaling-stroke"
        />
      ))}
    </g>
  );
}
