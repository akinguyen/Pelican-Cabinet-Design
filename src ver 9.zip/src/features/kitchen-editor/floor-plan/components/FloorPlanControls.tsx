"use client";

import type { ReactNode } from "react";
import { LocateFixed, ZoomIn, ZoomOut } from "lucide-react";
import { useUiStore } from "@/features/kitchen-editor/state/useUIStore";

function FloorPlanControlButton({
  children,
  disabled = false,
  label,
  onClick,
}: Readonly<{
  children: ReactNode;
  disabled?: boolean;
  label: string;
  onClick: () => void;
}>) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-300"
    >
      {children}
    </button>
  );
}

export function FloorPlanControls() {
  const zoomFloorPlanIn = useUiStore((state) => state.zoomFloorPlanIn);
  const zoomFloorPlanOut = useUiStore((state) => state.zoomFloorPlanOut);
  const centerFloorPlanView = useUiStore((state) => state.centerFloorPlanView);

  return (
    <div className="flex h-16 items-center gap-3 border-b border-slate-200 bg-white px-5">
      <FloorPlanControlButton label="Zoom out" onClick={zoomFloorPlanOut}>
        <ZoomOut className="h-5 w-5" strokeWidth={2} />
      </FloorPlanControlButton>

      <FloorPlanControlButton label="Zoom in" onClick={zoomFloorPlanIn}>
        <ZoomIn className="h-5 w-5" strokeWidth={2} />
      </FloorPlanControlButton>

      <FloorPlanControlButton label="Center view" onClick={centerFloorPlanView}>
        <LocateFixed className="h-5 w-5" strokeWidth={2} />
      </FloorPlanControlButton>
    </div>
  );
}
