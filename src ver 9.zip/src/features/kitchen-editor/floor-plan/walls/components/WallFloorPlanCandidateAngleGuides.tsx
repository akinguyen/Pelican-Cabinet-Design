import { distanceBetweenPoints } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";

export type WallFloorPlanCandidateAngleGuideValue = Readonly<{
  smallerAngle: number;
  largerAngle: number;
  isHorizontal: boolean;
  isVertical: boolean;
  isBelowHorizontal: boolean;
}>;

type WallFloorPlanCandidateAngleGuidesProps = Readonly<{
  origin: Point2DInches;
  candidatePoint2DInches: Point2DInches;
  angleGuide: WallFloorPlanCandidateAngleGuideValue;
}>;

type AngleGuideLabelPositions = Readonly<{
  inner: Point2DInches;
  outer: Point2DInches;
}>;

const MIN_GUIDE_LABEL_RADIUS_INCHES = 36;

function degreesToRadians(degrees: number) {
  return (degrees * Math.PI) / 180;
}

function getPoint2DInchesFromAngle(
  origin: Point2DInches,
  radius: number,
  angleDegrees: number,
): Point2DInches {
  const angle = degreesToRadians(angleDegrees);

  return {
    xInches: origin.xInches + Math.cos(angle) * radius,
    yInches: origin.yInches + Math.sin(angle) * radius,
  };
}

function getAverageAngleDegrees(firstDegrees: number, secondDegrees: number) {
  const first = degreesToRadians(firstDegrees);
  const second = degreesToRadians(secondDegrees);

  return (
    Math.atan2(
      Math.sin(first) + Math.sin(second),
      Math.cos(first) + Math.cos(second),
    ) * 180
  ) / Math.PI;
}

function getSegmentAngleDegrees(origin: Point2DInches, candidatePoint2DInches: Point2DInches) {
  return (
    Math.atan2(candidatePoint2DInches.yInches - origin.yInches, candidatePoint2DInches.xInches - origin.xInches) * 180
  ) / Math.PI;
}

function getAngleLabelPositions({
  angleGuide,
  candidatePoint2DInches,
  origin,
}: Readonly<{
  angleGuide: WallFloorPlanCandidateAngleGuideValue;
  candidatePoint2DInches: Point2DInches;
  origin: Point2DInches;
}>): AngleGuideLabelPositions {
  const radius = distanceBetweenPoints(origin, candidatePoint2DInches);
  const labelRadius = Math.max(MIN_GUIDE_LABEL_RADIUS_INCHES, radius * 0.48);

  if (angleGuide.isHorizontal) {
    return {
      inner: { xInches: origin.xInches, yInches: origin.yInches - labelRadius },
      outer: { xInches: origin.xInches, yInches: origin.yInches + labelRadius },
    };
  }

  if (angleGuide.isVertical) {
    const midpointY = (origin.yInches + candidatePoint2DInches.yInches) / 2;
    const sideOffset = Math.max(36, radius * 0.28);

    return {
      inner: { xInches: origin.xInches - sideOffset, yInches: midpointY },
      outer: { xInches: origin.xInches + sideOffset, yInches: midpointY },
    };
  }

  const segmentAngle = getSegmentAngleDegrees(origin, candidatePoint2DInches);
  const nearestHorizontalAngle = candidatePoint2DInches.xInches >= origin.xInches ? 0 : 180;
  const innerAngle = getAverageAngleDegrees(
    segmentAngle,
    nearestHorizontalAngle,
  );
  const outerAngle = candidatePoint2DInches.yInches < origin.yInches ? -90 : 90;

  return {
    inner: getPoint2DInchesFromAngle(origin, labelRadius, innerAngle),
    outer: getPoint2DInchesFromAngle(origin, labelRadius, outerAngle),
  };
}

export function getWallFloorPlanCandidateMeasurementLabelSide({
  angleGuide,
  candidatePoint2DInches,
  origin,
}: Readonly<{
  angleGuide: WallFloorPlanCandidateAngleGuideValue;
  candidatePoint2DInches: Point2DInches;
  origin: Point2DInches;
}>): -1 | 1 {
  const labelPositions = getAngleLabelPositions({ angleGuide, candidatePoint2DInches, origin });
  const dx = candidatePoint2DInches.xInches - origin.xInches;
  const dy = candidatePoint2DInches.yInches - origin.yInches;
  const length = distanceBetweenPoints(origin, candidatePoint2DInches);

  if (length === 0) {
    return 1;
  }

  const normal = {
    xInches: -dy / length,
    yInches: dx / length,
  };
  const midpoint = {
    xInches: (origin.xInches + candidatePoint2DInches.xInches) / 2,
    yInches: (origin.yInches + candidatePoint2DInches.yInches) / 2,
  };
  const dot =
    (labelPositions.inner.xInches - midpoint.xInches) * normal.xInches +
    (labelPositions.inner.yInches - midpoint.yInches) * normal.yInches;

  return dot >= 0 ? -1 : 1;
}

function AngleText({ point, value }: Readonly<{ point: Point2DInches; value: number }>) {
  return (
    <text
      x={point.xInches}
      y={point.yInches}
      textAnchor="middle"
      dominantBaseline="middle"
      className="fill-slate-950 text-[14px] font-bold"
      paintOrder="stroke"
      stroke="white"
      strokeWidth={4}
      strokeLinejoin="round"
    >
      {value}&#176;
    </text>
  );
}

export function WallFloorPlanCandidateAngleGuides({
  angleGuide,
  candidatePoint2DInches,
  origin,
}: WallFloorPlanCandidateAngleGuidesProps) {
  const radius = distanceBetweenPoints(origin, candidatePoint2DInches);

  if (radius < 1) {
    return null;
  }

  const labelPositions = getAngleLabelPositions({ angleGuide, candidatePoint2DInches, origin });
  const arcPath = `M ${origin.xInches - radius} ${origin.yInches} A ${radius} ${radius} 0 0 ${
    candidatePoint2DInches.yInches < origin.yInches ? 1 : 0
  } ${origin.xInches + radius} ${origin.yInches}`;

  return (
    <g pointerEvents="none">
      {angleGuide.isHorizontal ? (
        <circle
          cx={origin.xInches}
          cy={origin.yInches}
          r={radius}
          fill="none"
          stroke="#8f8f8f"
          strokeWidth={1.4}
        />
      ) : (
        <path d={arcPath} fill="none" stroke="#8f8f8f" strokeWidth={1.4} />
      )}

      <AngleText point={labelPositions.inner} value={angleGuide.smallerAngle} />
      <AngleText point={labelPositions.outer} value={angleGuide.largerAngle} />
    </g>
  );
}
