import type { Point2DInches, Size2DInches } from "@/shared/types/geometryTypes";

export type WallFloorPlanReferenceGuideSegment = Readonly<{
  segmentStart: Point2DInches;
  segmentEnd: Point2DInches;
}>;

export type WallFloorPlanReferenceGuideStyle = Readonly<{
  guideStroke: string;
  guideStrokeWidthInches: number;
  segmentGuideStrokeWidthInches: number;
  originMarkerRadiusInches: number;
  originMarkerFill: string;
  originMarkerStroke: string;
  originMarkerStrokeWidthInches: number;
}>;

type WallFloorPlanReferenceGuidesProps = Readonly<{
  originInches: Point2DInches | null;
  floorPlanSizeInches: Size2DInches;
  horizontalGuideYInches: number | null;
  verticalGuideXInches: number | null;
  segmentGuide: WallFloorPlanReferenceGuideSegment | null;
  style: WallFloorPlanReferenceGuideStyle;
}>;

export function WallFloorPlanReferenceGuides({
  originInches,
  floorPlanSizeInches,
  horizontalGuideYInches,
  verticalGuideXInches,
  segmentGuide,
  style,
}: WallFloorPlanReferenceGuidesProps) {
  if (!originInches || horizontalGuideYInches === null) {
    return null;
  }

  return (
    <g pointerEvents="none">
      <line
        x1={0}
        y1={horizontalGuideYInches}
        x2={floorPlanSizeInches.widthInches}
        y2={horizontalGuideYInches}
        stroke={style.guideStroke}
        strokeWidth={style.guideStrokeWidthInches}
      />

      {verticalGuideXInches !== null ? (
        <line
          x1={verticalGuideXInches}
          y1={0}
          x2={verticalGuideXInches}
          y2={floorPlanSizeInches.heightInches}
          stroke={style.guideStroke}
          strokeWidth={style.guideStrokeWidthInches}
        />
      ) : null}

      {segmentGuide ? (
        <line
          x1={segmentGuide.segmentStart.xInches}
          y1={segmentGuide.segmentStart.yInches}
          x2={segmentGuide.segmentEnd.xInches}
          y2={segmentGuide.segmentEnd.yInches}
          stroke={style.guideStroke}
          strokeWidth={style.segmentGuideStrokeWidthInches}
          strokeLinecap="round"
        />
      ) : null}

      <circle
        cx={originInches.xInches}
        cy={originInches.yInches}
        r={style.originMarkerRadiusInches}
        fill={style.originMarkerFill}
        stroke={style.originMarkerStroke}
        strokeWidth={style.originMarkerStrokeWidthInches}
      />
    </g>
  );
}
