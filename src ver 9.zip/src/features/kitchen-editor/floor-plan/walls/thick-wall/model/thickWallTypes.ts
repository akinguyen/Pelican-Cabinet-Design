export type ThickWallFloorPlanSegmentRenderState = "default" | "selected" | "candidate";
