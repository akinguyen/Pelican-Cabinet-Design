import { distanceBetweenPoints } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { MeasurementUnit } from "@/shared/units/length";
import { ThickWallSegmentGeometry } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";
import { ThickWallFloorPlanMeasurementLabel } from "./ThickWallFloorPlanMeasurementLabel";

type ThickWallMeasurementGuideSide = "left" | "right";

type ThickWallMeasurementGuide = Readonly<{
  side: ThickWallMeasurementGuideSide;
  start: Point2DInches;
  end: Point2DInches;
}>;

type ThickWallFloorPlanMeasurementGuidesProps = Readonly<{
  geometry: ThickWallSegmentGeometry;
  measurementUnit: MeasurementUnit;
}>;

const GUIDE_LINE_OFFSET_INCHES = 14;
const GUIDE_LABEL_OFFSET_INCHES = 18;
const GUIDE_CAP_HALF_LENGTH = 10;

function getSegmentNormal(start: Point2DInches, end: Point2DInches) {
  const length = distanceBetweenPoints(start, end);

  if (length === 0) {
    return { xInches: 0, yInches: 0 };
  }

  return {
    xInches: -(end.yInches - start.yInches) / length,
    yInches: (end.xInches - start.xInches) / length,
  };
}

function getMeasurementGuide(
  start: Point2DInches,
  end: Point2DInches,
  side: ThickWallMeasurementGuideSide,
  segmentStart: Point2DInches,
  segmentEnd: Point2DInches,
): ThickWallMeasurementGuide {
  const normal = getSegmentNormal(segmentStart, segmentEnd);
  const direction = side === "left" ? 1 : -1;
  const offset = {
    xInches: normal.xInches * GUIDE_LINE_OFFSET_INCHES * direction,
    yInches: normal.yInches * GUIDE_LINE_OFFSET_INCHES * direction,
  };

  return {
    side,
    start: {
      xInches: start.xInches + offset.xInches,
      yInches: start.yInches + offset.yInches,
    },
    end: {
      xInches: end.xInches + offset.xInches,
      yInches: end.yInches + offset.yInches,
    },
  };
}

function getMeasurementGuides(geometry: ThickWallSegmentGeometry) {
  return [
    getMeasurementGuide(
      geometry.floorPlan.startLeftCornerPointInches,
      geometry.floorPlan.endLeftCornerPointInches,
      "left",
      geometry.floorPlan.centerlineStartPointInches,
      geometry.floorPlan.centerlineEndPointInches,
    ),
    getMeasurementGuide(
      geometry.floorPlan.startRightCornerPointInches,
      geometry.floorPlan.endRightCornerPointInches,
      "right",
      geometry.floorPlan.centerlineStartPointInches,
      geometry.floorPlan.centerlineEndPointInches,
    ),
  ] as const;
}

export function ThickWallFloorPlanMeasurementGuides({
  geometry,
  measurementUnit,
}: ThickWallFloorPlanMeasurementGuidesProps) {
  const measurementGuides = getMeasurementGuides(geometry);
  const normal = getSegmentNormal(geometry.floorPlan.centerlineStartPointInches, geometry.floorPlan.centerlineEndPointInches);
  const capOffset = {
    xInches: normal.xInches * GUIDE_CAP_HALF_LENGTH,
    yInches: normal.yInches * GUIDE_CAP_HALF_LENGTH,
  };

  return (
    <g pointerEvents="none">
      {measurementGuides.map((guide) => {
        const labelOffset = guide.side === "left" ? GUIDE_LABEL_OFFSET_INCHES : -GUIDE_LABEL_OFFSET_INCHES;

        return (
          <g key={`${guide.side}-${guide.start.xInches}-${guide.start.yInches}`}>
            <line
              x1={guide.start.xInches}
              y1={guide.start.yInches}
              x2={guide.end.xInches}
              y2={guide.end.yInches}
              stroke="#38bdf8"
              strokeWidth={1.5}
              strokeDasharray="8 10"
            />
            <line
              x1={guide.start.xInches - capOffset.xInches}
              y1={guide.start.yInches - capOffset.yInches}
              x2={guide.start.xInches + capOffset.xInches}
              y2={guide.start.yInches + capOffset.yInches}
              stroke="#38bdf8"
              strokeWidth={1.5}
            />
            <line
              x1={guide.end.xInches - capOffset.xInches}
              y1={guide.end.yInches - capOffset.yInches}
              x2={guide.end.xInches + capOffset.xInches}
              y2={guide.end.yInches + capOffset.yInches}
              stroke="#38bdf8"
              strokeWidth={1.5}
            />
            <ThickWallFloorPlanMeasurementLabel
              start={guide.start}
              end={guide.end}
              unit={measurementUnit}
              offset={labelOffset}
            />
          </g>
        );
      })}
    </g>
  );
}
