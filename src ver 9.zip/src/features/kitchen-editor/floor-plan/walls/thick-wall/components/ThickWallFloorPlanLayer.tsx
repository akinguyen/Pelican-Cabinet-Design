import type { MeasurementUnit } from "@/shared/units/length";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThickWallChain, ThickWallPlacementSide } from "@/domains/walls/model/wallTypes";
import type { ThickWallSegmentSelection } from "@/features/kitchen-editor/state/designStoreTypes";
import {
  getPlacedThickWallChainSegmentGeometries,
  type ThickWallSegmentGeometry,
} from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";
import { getThickWallJointFillPolygons } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallJointGeometry";
import { ThickWallFloorPlanCornerMarkers } from "./ThickWallFloorPlanCornerMarkers";
import { ThickWallFloorPlanElevationStartMarker } from "./ThickWallFloorPlanElevationStartMarker";
import { ThickWallFloorPlanJointFillShapes } from "./ThickWallFloorPlanJointFillShapes";
import { ThickWallFloorPlanPlacementSideMarkers } from "./ThickWallFloorPlanPlacementSideMarkers";
import { ThickWallFloorPlanSegmentRenderer } from "./ThickWallFloorPlanSegmentRenderer";
import { ThickWallFloorPlanTerminalEndpointMarkers } from "./ThickWallFloorPlanTerminalEndpointMarkers";

type ThickWallFloorPlanLayerProps = Readonly<{
  chains: readonly PlacedThickWallChain[];
  selectedSegment: ThickWallSegmentSelection | null;
  candidateSegment: ThickWallSegmentSelection | null;
  measurementUnit: MeasurementUnit;
  hiddenTerminalEndpoint: Point2DInches | null;
}>;

type ThickWallFloorPlanSegmentRenderItem = Readonly<{
  renderKey: string;
  chain: PlacedThickWallChain;
  chainId: string;
  segmentIndex: number;
  geometry: ThickWallSegmentGeometry;
  placementSide: ThickWallPlacementSide;
}>;

function doesSelectionMatchThickWallSegment(
  segmentRenderItem: ThickWallFloorPlanSegmentRenderItem,
  selection: ThickWallSegmentSelection | null,
) {
  return (
    selection?.chainId === segmentRenderItem.chainId &&
    selection.segmentIndex === segmentRenderItem.segmentIndex
  );
}

function getThickWallFloorPlanSegmentRenderItems(
  chains: readonly PlacedThickWallChain[],
): readonly ThickWallFloorPlanSegmentRenderItem[] {
  return chains.flatMap((chain) =>
    getPlacedThickWallChainSegmentGeometries(chain, chains).map(
      (geometry, segmentIndex): ThickWallFloorPlanSegmentRenderItem => ({
        renderKey: `${chain.id}-segment-${segmentIndex}`,
        chain,
        chainId: chain.id,
        segmentIndex,
        geometry,
        placementSide: chain.segmentPlacementSides[segmentIndex] ?? "interior",
      }),
    ),
  );
}

export function ThickWallFloorPlanLayer({
  chains,
  selectedSegment,
  candidateSegment,
  measurementUnit,
  hiddenTerminalEndpoint,
}: ThickWallFloorPlanLayerProps) {
  const jointFillPolygons = getThickWallJointFillPolygons(chains);
  const segmentRenderItems = getThickWallFloorPlanSegmentRenderItems(chains);
  const selectedSegmentRenderItem =
    segmentRenderItems.find((segmentRenderItem) =>
      doesSelectionMatchThickWallSegment(segmentRenderItem, selectedSegment),
    ) ?? null;
  const candidateSegmentRenderItem =
    segmentRenderItems.find((segmentRenderItem) =>
      doesSelectionMatchThickWallSegment(segmentRenderItem, candidateSegment),
    ) ?? null;
  const backgroundSegmentRenderItems = segmentRenderItems.filter(
    (segmentRenderItem) =>
      !doesSelectionMatchThickWallSegment(segmentRenderItem, selectedSegment) &&
      !doesSelectionMatchThickWallSegment(segmentRenderItem, candidateSegment),
  );

  return (
    <g>
      <ThickWallFloorPlanJointFillShapes fillPolygons={jointFillPolygons} />
      <ThickWallFloorPlanPlacementSideMarkers
        chains={chains}
        segments={segmentRenderItems}
      />

      {backgroundSegmentRenderItems.map((segmentRenderItem) => (
        <ThickWallFloorPlanSegmentRenderer
          key={segmentRenderItem.renderKey}
          geometry={segmentRenderItem.geometry}
          measurementUnit={measurementUnit}
          renderState="default"
        />
      ))}

      {selectedSegmentRenderItem ? (
        <ThickWallFloorPlanSegmentRenderer
          key={`${selectedSegmentRenderItem.renderKey}-selected`}
          geometry={selectedSegmentRenderItem.geometry}
          measurementUnit={measurementUnit}
          renderState="selected"
        />
      ) : null}

      {candidateSegmentRenderItem ? (
        <ThickWallFloorPlanSegmentRenderer
          key={`${candidateSegmentRenderItem.renderKey}-candidate`}
          geometry={candidateSegmentRenderItem.geometry}
          measurementUnit={measurementUnit}
          renderState="candidate"
        />
      ) : null}

      <ThickWallFloorPlanCornerMarkers segmentRenderItems={segmentRenderItems} />

      <ThickWallFloorPlanTerminalEndpointMarkers
        chains={chains}
        hiddenTerminalEndpoint={hiddenTerminalEndpoint}
      />

      <ThickWallFloorPlanElevationStartMarker
        chains={chains}
        segment={selectedSegmentRenderItem}
      />
    </g>
  );
}
