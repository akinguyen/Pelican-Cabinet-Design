import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThickWallChain } from "@/domains/walls/model/wallTypes";
import { getThickWallSnapMarkerPoint2DInches } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallJointGeometry";
import { type ThickWallSnapPoint } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallFloorPlanSnapping";

type ThickWallFloorPlanSnapPointMarkerProps = Readonly<{
  snapPointInches: ThickWallSnapPoint | null;
  chains: readonly PlacedThickWallChain[];
  markerPointInches?: Point2DInches | null;
}>;

export function ThickWallFloorPlanSnapPointMarker({
  snapPointInches,
  chains,
  markerPointInches,
}: ThickWallFloorPlanSnapPointMarkerProps) {
  const point = markerPointInches ?? (snapPointInches ? getThickWallSnapMarkerPoint2DInches(snapPointInches, chains) : null);

  if (!point) {
    return null;
  }

  return (
    <g pointerEvents="none">
      <circle
        cx={point.xInches}
        cy={point.yInches}
        r={14}
        fill="#38bdf8"
        stroke="white"
        strokeWidth={3}
      />
      <line
        x1={point.xInches - 7}
        y1={point.yInches}
        x2={point.xInches + 7}
        y2={point.yInches}
        stroke="white"
        strokeWidth={4}
        strokeLinecap="round"
      />
      <line
        x1={point.xInches}
        y1={point.yInches - 7}
        x2={point.xInches}
        y2={point.yInches + 7}
        stroke="white"
        strokeWidth={4}
        strokeLinecap="round"
      />
    </g>
  );
}
