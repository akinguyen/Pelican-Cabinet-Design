import type { Point2DInches } from "@/shared/types/geometryTypes";

type ThickWallFloorPlanEndpointMarkerProps = Readonly<{
  centerInches: Point2DInches;
  firstCornerInches: Point2DInches;
  secondCornerInches: Point2DInches;
}>;

const ENDPOINT_CENTER_RADIUS_INCHES = 14;
const ENDPOINT_CENTER_STROKE_WIDTH_INCHES = 4;
const ENDPOINT_CORNER_RADIUS_INCHES = 4.5;

export function ThickWallFloorPlanEndpointMarker({
  centerInches,
  firstCornerInches,
  secondCornerInches,
}: ThickWallFloorPlanEndpointMarkerProps) {
  return (
    <g pointerEvents="none">
      <circle
        cx={centerInches.xInches}
        cy={centerInches.yInches}
        r={ENDPOINT_CENTER_RADIUS_INCHES}
        fill="#fecaca"
        stroke="#fb7185"
        strokeWidth={ENDPOINT_CENTER_STROKE_WIDTH_INCHES}
      />
      <circle
        cx={firstCornerInches.xInches}
        cy={firstCornerInches.yInches}
        r={ENDPOINT_CORNER_RADIUS_INCHES}
        fill="#020617"
      />
      <circle
        cx={secondCornerInches.xInches}
        cy={secondCornerInches.yInches}
        r={ENDPOINT_CORNER_RADIUS_INCHES}
        fill="#020617"
      />
    </g>
  );
}
