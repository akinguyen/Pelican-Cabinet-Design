import { ThickWallSegmentGeometry } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";

export type ThickWallCornerMarkerSegmentRenderItem = Readonly<{
  renderKey: string;
  geometry: ThickWallSegmentGeometry;
}>;

type ThickWallFloorPlanCornerMarkersProps = Readonly<{
  segmentRenderItems: readonly ThickWallCornerMarkerSegmentRenderItem[];
}>;

function ThickWallSegmentCornerMarkers({
  geometry,
}: Readonly<{
  geometry: ThickWallSegmentGeometry;
}>) {
  return (
    <g pointerEvents="none">
      <circle cx={geometry.floorPlan.startLeftCornerPointInches.xInches} cy={geometry.floorPlan.startLeftCornerPointInches.yInches} r={4.5} fill="#020617" />
      <circle cx={geometry.floorPlan.startRightCornerPointInches.xInches} cy={geometry.floorPlan.startRightCornerPointInches.yInches} r={4.5} fill="#020617" />
      <circle cx={geometry.floorPlan.endLeftCornerPointInches.xInches} cy={geometry.floorPlan.endLeftCornerPointInches.yInches} r={4.5} fill="#020617" />
      <circle cx={geometry.floorPlan.endRightCornerPointInches.xInches} cy={geometry.floorPlan.endRightCornerPointInches.yInches} r={4.5} fill="#020617" />
    </g>
  );
}

export function ThickWallFloorPlanCornerMarkers({
  segmentRenderItems,
}: ThickWallFloorPlanCornerMarkersProps) {
  if (segmentRenderItems.length === 0) {
    return null;
  }

  return (
    <g pointerEvents="none">
      {segmentRenderItems.map(({ renderKey, geometry }) => (
        <ThickWallSegmentCornerMarkers key={renderKey} geometry={geometry} />
      ))}
    </g>
  );
}
