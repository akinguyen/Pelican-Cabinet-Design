import { getPolygonPointsAttribute } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSvg";
import { type ThickWallJointFillPolygon } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallJointGeometry";

type ThickWallFloorPlanJointFillShapesProps = Readonly<{
  fillPolygons: readonly ThickWallJointFillPolygon[];
}>;

export function ThickWallFloorPlanJointFillShapes({ fillPolygons }: ThickWallFloorPlanJointFillShapesProps) {
  if (fillPolygons.length === 0) {
    return null;
  }

  return (
    <g pointerEvents="none">
      {fillPolygons.map((fillPolygon) => (
        <polygon
          key={fillPolygon.id}
          points={getPolygonPointsAttribute(fillPolygon.floorPlan.polygonInches)}
          fill="#c9c9c9"
          stroke="#c9c9c9"
          strokeWidth={1}
          strokeLinejoin="round"
        />
      ))}
    </g>
  );
}
