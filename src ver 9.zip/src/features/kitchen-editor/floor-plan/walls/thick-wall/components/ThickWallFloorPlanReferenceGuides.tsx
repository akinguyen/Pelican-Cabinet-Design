import type { Point2DInches, Size2DInches } from "@/shared/types/geometryTypes";
import type { ThickWallConstructedReferenceGuide } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallFloorPlanSnapping";
import {
  WallFloorPlanReferenceGuides,
  type WallFloorPlanReferenceGuideStyle,
} from "@/features/kitchen-editor/floor-plan/walls/components/WallFloorPlanReferenceGuides";

type ThickWallFloorPlanReferenceGuidesProps = Readonly<{
  constructedReferenceGuide: ThickWallConstructedReferenceGuide | null;
  originInches: Point2DInches | null;
  floorPlanSizeInches: Size2DInches;
}>;

const THICK_WALL_REFERENCE_GUIDE_STYLE: WallFloorPlanReferenceGuideStyle = {
  guideStroke: "#ff4b4b",
  guideStrokeWidthInches: 2,
  segmentGuideStrokeWidthInches: 2.5,
  originMarkerRadiusInches: 14,
  originMarkerFill: "none",
  originMarkerStroke: "#0ea5e9",
  originMarkerStrokeWidthInches: 3,
};

export function ThickWallFloorPlanReferenceGuides({
  constructedReferenceGuide,
  originInches,
  floorPlanSizeInches,
}: ThickWallFloorPlanReferenceGuidesProps) {
  return (
    <WallFloorPlanReferenceGuides
      floorPlanSizeInches={floorPlanSizeInches}
      horizontalGuideYInches={
        constructedReferenceGuide?.horizontalGuide.referencePointInches.yInches ??
        originInches?.yInches ??
        null
      }
      originInches={originInches}
      segmentGuide={constructedReferenceGuide?.centerlineGuide ?? null}
      style={THICK_WALL_REFERENCE_GUIDE_STYLE}
      verticalGuideXInches={
        constructedReferenceGuide?.verticalGuide?.referencePointInches.xInches ?? null
      }
    />
  );
}
