import type { MeasurementUnit } from "@/shared/units/length";
import { getPolygonPointsAttribute } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSvg";
import { type ThickWallSegmentGeometry } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";
import type { ThickWallFloorPlanSegmentRenderState } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/model/thickWallTypes";
import { ThickWallFloorPlanMeasurementGuides } from "./ThickWallFloorPlanMeasurementGuides";

type ThickWallFloorPlanSegmentRendererProps = Readonly<{
  geometry: ThickWallSegmentGeometry;
  measurementUnit: MeasurementUnit;
  renderState: ThickWallFloorPlanSegmentRenderState;
}>;

function ThickWallInnerCenterline({
  geometry,
}: Readonly<{
  geometry: ThickWallSegmentGeometry;
}>) {
  return (
    <line
      x1={geometry.floorPlan.centerlineStartPointInches.xInches}
      y1={geometry.floorPlan.centerlineStartPointInches.yInches}
      x2={geometry.floorPlan.centerlineEndPointInches.xInches}
      y2={geometry.floorPlan.centerlineEndPointInches.yInches}
      stroke="#8b5cf6"
      strokeWidth={1.5}
      strokeDasharray="7 7"
      strokeLinecap="round"
      pointerEvents="none"
    />
  );
}

export function ThickWallFloorPlanSegmentRenderer({
  geometry,
  measurementUnit,
  renderState,
}: ThickWallFloorPlanSegmentRendererProps) {
  const highlighted = renderState === "selected" || renderState === "candidate";

  return (
    <g pointerEvents="none">
      <polygon
        points={getPolygonPointsAttribute(geometry.floorPlan.polygonInches)}
        fill={highlighted ? "#bae6fd" : "#c9c9c9"}
        stroke={highlighted ? "#0ea5e9" : "#c9c9c9"}
        strokeWidth={highlighted ? 4 : 1}
        strokeLinejoin="round"
      />

      <ThickWallInnerCenterline geometry={geometry} />
      <ThickWallFloorPlanMeasurementGuides geometry={geometry} measurementUnit={measurementUnit} />
    </g>
  );
}
