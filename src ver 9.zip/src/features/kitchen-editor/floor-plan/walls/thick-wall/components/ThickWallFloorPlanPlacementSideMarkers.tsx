import type { PlacedThickWallChain, ThickWallPlacementSide } from "@/domains/walls/model/wallTypes";
import { getThickWallPlacementSideEdgeForPlacementSide } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallPlacementSideGeometry";
import { type ThickWallSegmentGeometry } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";

type ThickWallPlacementSideMarkerSegment = Readonly<{
  chain: PlacedThickWallChain;
  chainId: string;
  segmentIndex: number;
  geometry: ThickWallSegmentGeometry;
  placementSide: ThickWallPlacementSide;
}>;

type ThickWallFloorPlanPlacementSideMarkersProps = Readonly<{
  chains: readonly PlacedThickWallChain[];
  segments: readonly ThickWallPlacementSideMarkerSegment[];
}>;

const PLACEMENT_SIDE_STROKE = "#475569";
const PLACEMENT_SIDE_STROKE_WIDTH_INCHES = 3;

export function ThickWallFloorPlanPlacementSideMarkers({
  chains,
  segments,
}: ThickWallFloorPlanPlacementSideMarkersProps) {
  if (segments.length === 0) {
    return null;
  }

  return (
    <g pointerEvents="none">
      {segments.flatMap((segment) => {
        const sideEdge = getThickWallPlacementSideEdgeForPlacementSide(
          segment.chain,
          segment.geometry,
          segment.placementSide,
          chains,
        );

        if (!sideEdge) {
          return [];
        }

        return [
          <line
            key={`${segment.chainId}-${segment.segmentIndex}-placement-side`}
            x1={sideEdge.floorPlan.sideStartPointInches.xInches}
            y1={sideEdge.floorPlan.sideStartPointInches.yInches}
            x2={sideEdge.floorPlan.sideEndPointInches.xInches}
            y2={sideEdge.floorPlan.sideEndPointInches.yInches}
            stroke={PLACEMENT_SIDE_STROKE}
            strokeWidth={PLACEMENT_SIDE_STROKE_WIDTH_INCHES}
            strokeLinecap="round"
            pointerEvents="none"
          />,
        ];
      })}
    </g>
  );
}
