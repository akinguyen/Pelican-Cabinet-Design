import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThickWallChain, ThickWallPlacementSide } from "@/domains/walls/model/wallTypes";
import { getThickWallPlacementSideEdgeForPlacementSide } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallPlacementSideGeometry";
import { type ThickWallSegmentGeometry } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";

type ThickWallFloorPlanElevationStartMarkerSegment = Readonly<{
  chain: PlacedThickWallChain;
  geometry: ThickWallSegmentGeometry;
  placementSide: ThickWallPlacementSide;
}>;

type ThickWallFloorPlanElevationStartMarkerProps = Readonly<{
  chains: readonly PlacedThickWallChain[];
  segment: ThickWallFloorPlanElevationStartMarkerSegment | null;
}>;

function ThickWallFloorPlanElevationStartMarkerIcon({ point }: Readonly<{ point: Point2DInches }>) {
  return (
    <circle
      cx={point.xInches}
      cy={point.yInches}
      r={6}
      fill="#8b5cf6"
      stroke="white"
      strokeWidth={2}
      pointerEvents="none"
    />
  );
}

export function ThickWallFloorPlanElevationStartMarker({
  chains,
  segment,
}: ThickWallFloorPlanElevationStartMarkerProps) {
  if (!segment) {
    return null;
  }

  const sideEdge = getThickWallPlacementSideEdgeForPlacementSide(
    segment.chain,
    segment.geometry,
    segment.placementSide,
    chains,
  );

  if (!sideEdge) {
    return null;
  }

  return <ThickWallFloorPlanElevationStartMarkerIcon point={sideEdge.elevationPlan.startPointInches} />;
}
