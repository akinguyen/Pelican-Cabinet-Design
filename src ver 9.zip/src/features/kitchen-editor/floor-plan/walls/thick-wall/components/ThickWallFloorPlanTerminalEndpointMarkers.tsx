import type { ReactElement } from "react";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThickWallChain } from "@/domains/walls/model/wallTypes";
import { getPlacedThickWallChainSegmentGeometries } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";
import { ThickWallFloorPlanEndpointMarker } from "./ThickWallFloorPlanEndpointMarker";

type ThickWallFloorPlanTerminalEndpointMarkersProps = Readonly<{
  chains: readonly PlacedThickWallChain[];
  hiddenTerminalEndpoint: Point2DInches | null;
}>;

const POINT_KEY_PRECISION = 1000;

function getPointKey(point: Point2DInches) {
  const x = Math.round(point.xInches * POINT_KEY_PRECISION) / POINT_KEY_PRECISION;
  const y = Math.round(point.yInches * POINT_KEY_PRECISION) / POINT_KEY_PRECISION;

  return `${x}:${y}`;
}

function getPointConnectionCounts(chains: readonly PlacedThickWallChain[]) {
  const connectionCounts = new Map<string, number>();

  chains.forEach((chain) => {
    chain.floorPlan.centerlinePointsInches.forEach((point, pointIndex) => {
      const connectedSegmentCount =
        (pointIndex > 0 ? 1 : 0) + (pointIndex < chain.floorPlan.centerlinePointsInches.length - 1 ? 1 : 0);
      const pointKey = getPointKey(point);

      connectionCounts.set(pointKey, (connectionCounts.get(pointKey) ?? 0) + connectedSegmentCount);
    });
  });

  return connectionCounts;
}

export function ThickWallFloorPlanTerminalEndpointMarkers({
  chains,
  hiddenTerminalEndpoint,
}: ThickWallFloorPlanTerminalEndpointMarkersProps) {
  const connectionCounts = getPointConnectionCounts(chains);
  const renderedEndpointKeys = new Set<string>();
  const hiddenKey = hiddenTerminalEndpoint ? getPointKey(hiddenTerminalEndpoint) : null;

  return (
    <g>
      {chains.flatMap((chain) => {
        const segmentGeometries = getPlacedThickWallChainSegmentGeometries(chain, chains);

        return segmentGeometries.flatMap((geometry, segmentIndex) => {
          const markers: ReactElement[] = [];
          const startKey = getPointKey(geometry.floorPlan.centerlineStartPointInches);
          const endKey = getPointKey(geometry.floorPlan.centerlineEndPointInches);

          if (
            (connectionCounts.get(startKey) ?? 0) <= 1 &&
            !renderedEndpointKeys.has(startKey) &&
            startKey !== hiddenKey
          ) {
            renderedEndpointKeys.add(startKey);
            markers.push(
              <ThickWallFloorPlanEndpointMarker
                key={`${chain.id}-${segmentIndex}-start-endpoint`}
                centerInches={geometry.floorPlan.centerlineStartPointInches}
                firstCornerInches={geometry.floorPlan.startLeftCornerPointInches}
                secondCornerInches={geometry.floorPlan.startRightCornerPointInches}
              />,
            );
          }

          if (
            (connectionCounts.get(endKey) ?? 0) <= 1 &&
            !renderedEndpointKeys.has(endKey) &&
            endKey !== hiddenKey
          ) {
            renderedEndpointKeys.add(endKey);
            markers.push(
              <ThickWallFloorPlanEndpointMarker
                key={`${chain.id}-${segmentIndex}-end-endpoint`}
                centerInches={geometry.floorPlan.centerlineEndPointInches}
                firstCornerInches={geometry.floorPlan.endLeftCornerPointInches}
                secondCornerInches={geometry.floorPlan.endRightCornerPointInches}
              />,
            );
          }

          return markers;
        });
      })}
    </g>
  );
}
