import { distanceBetweenPoints } from "@/shared/math/geometry";
import type { MeasurementUnit } from "@/shared/units/length";
import type { CandidateThickWallSegment } from "@/domains/walls/model/wallTypes";
import { getPolygonPointsAttribute } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSvg";
import { getThickWallAngleGuide } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallFloorPlanCandidateGeometry";
import { getThickWallSegmentGeometry } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallSegmentGeometry";
import { type ThickWallSnapPoint } from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallFloorPlanSnapping";
import { WallFloorPlanCandidateAngleGuides } from "@/features/kitchen-editor/floor-plan/walls/components/WallFloorPlanCandidateAngleGuides";
import { ThickWallFloorPlanCornerMarkers } from "./ThickWallFloorPlanCornerMarkers";
import { ThickWallFloorPlanMeasurementGuides } from "./ThickWallFloorPlanMeasurementGuides";
import { ThickWallFloorPlanEndpointMarker } from "./ThickWallFloorPlanEndpointMarker";

type ThickWallFloorPlanCandidateLayerProps = Readonly<{
  candidateThickWallSegment: CandidateThickWallSegment | null;
  hoveredSnapPoint: ThickWallSnapPoint | null;
  measurementUnit: MeasurementUnit;
  candidateSegmentRenderMode?: "segment-and-guides" | "guides-only";
}>;

export function ThickWallFloorPlanCandidateLayer({
  candidateThickWallSegment,
  hoveredSnapPoint,
  measurementUnit,
  candidateSegmentRenderMode = "segment-and-guides",
}: ThickWallFloorPlanCandidateLayerProps) {
  if (!candidateThickWallSegment) {
    return null;
  }

  const origin = candidateThickWallSegment.floorPlan.startPointInches;
  const candidatePointInches = candidateThickWallSegment.floorPlan.endPointInches;

  if (distanceBetweenPoints(origin, candidatePointInches) < 1) {
    return null;
  }

  const angleGuide = getThickWallAngleGuide(origin, candidatePointInches);

  if (candidateSegmentRenderMode === "guides-only") {
    return (
      <g pointerEvents="none">
        <WallFloorPlanCandidateAngleGuides
          angleGuide={angleGuide}
          origin={origin}
          candidatePoint2DInches={candidatePointInches}
        />
      </g>
    );
  }

  const geometry = getThickWallSegmentGeometry(
    origin,
    candidatePointInches,
    candidateThickWallSegment.thicknessInches,
  );

  return (
    <g pointerEvents="none">
      <WallFloorPlanCandidateAngleGuides
        angleGuide={angleGuide}
        origin={origin}
        candidatePoint2DInches={candidatePointInches}
      />

      <polygon
        points={getPolygonPointsAttribute(geometry.floorPlan.polygonInches)}
        fill="#bae6fd"
        stroke="#0ea5e9"
        strokeWidth={3}
        strokeLinejoin="round"
      />

      <line
        x1={geometry.floorPlan.centerlineStartPointInches.xInches}
        y1={geometry.floorPlan.centerlineStartPointInches.yInches}
        x2={geometry.floorPlan.centerlineEndPointInches.xInches}
        y2={geometry.floorPlan.centerlineEndPointInches.yInches}
        stroke="#8b5cf6"
        strokeWidth={1.5}
        strokeDasharray="7 7"
        strokeLinecap="round"
      />

      <ThickWallFloorPlanMeasurementGuides
        geometry={geometry}
        measurementUnit={measurementUnit}
      />
      <ThickWallFloorPlanCornerMarkers
        segmentRenderItems={[{ renderKey: "candidate-corner-markers", geometry }]}
      />

      {!hoveredSnapPoint ? (
        <ThickWallFloorPlanEndpointMarker
          centerInches={candidatePointInches}
          firstCornerInches={geometry.floorPlan.endLeftCornerPointInches}
          secondCornerInches={geometry.floorPlan.endRightCornerPointInches}
        />
      ) : null}
    </g>
  );
}
