import { distanceBetweenPoints } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type {
  PlacedThickWallChain,
  ThickWallElevationPlanSide,
  ThickWallPlacementSide,
} from "@/domains/walls/model/wallTypes";
import {
  getPlacedThickWallChainSegmentGeometries,
  type ThickWallSegmentGeometry,
} from "./thickWallSegmentGeometry";

export type ThickWallChainSideKey = "side-a" | "side-b";

export type ThickWallResolvedChainSide = Readonly<{
  sideKey: ThickWallChainSideKey;
  totalLength: number;
}>;

export type ThickWallChainSideResolution = Readonly<{
  interiorSideKey: ThickWallChainSideKey;
  exteriorSideKey: ThickWallChainSideKey;
  sides: readonly ThickWallResolvedChainSide[];
}>;

export type ThickWallPlacementSideEdge = Readonly<{
  side: ThickWallElevationPlanSide;
  chainSideKey: ThickWallChainSideKey;
  sideLengthInches: number;
  floorPlan: Readonly<{
    sideStartPointInches: Point2DInches;
    sideEndPointInches: Point2DInches;
  }>;
  elevationPlan: Readonly<{
    startPointInches: Point2DInches;
    endPointInches: Point2DInches;
  }>;
}>;

type ThickWallRawSideEdge = Readonly<{
  chainSideKey: ThickWallChainSideKey;
  sideLengthInches: number;
  floorPlan: Readonly<{
    sideStartPointInches: Point2DInches;
    sideEndPointInches: Point2DInches;
  }>;
}>;

function getRawThickWallPlacementSideEdges(
  geometry: ThickWallSegmentGeometry,
): Record<ThickWallChainSideKey, ThickWallRawSideEdge> {
  return {
    "side-a": {
      chainSideKey: "side-a",
      floorPlan: {
        sideStartPointInches: geometry.floorPlan.startLeftCornerPointInches,
        sideEndPointInches: geometry.floorPlan.endLeftCornerPointInches,
      },
      sideLengthInches: distanceBetweenPoints(
        geometry.floorPlan.startLeftCornerPointInches,
        geometry.floorPlan.endLeftCornerPointInches,
      ),
    },
    "side-b": {
      chainSideKey: "side-b",
      floorPlan: {
        sideStartPointInches: geometry.floorPlan.startRightCornerPointInches,
        sideEndPointInches: geometry.floorPlan.endRightCornerPointInches,
      },
      sideLengthInches: distanceBetweenPoints(
        geometry.floorPlan.startRightCornerPointInches,
        geometry.floorPlan.endRightCornerPointInches,
      ),
    },
  };
}

function getOppositeThickWallChainSideKey(
  sideKey: ThickWallChainSideKey,
): ThickWallChainSideKey {
  return sideKey === "side-a" ? "side-b" : "side-a";
}

const THICK_WALL_SIDE_LENGTH_EQUAL_THRESHOLD_INCHES = 0.001;

export function getThickWallChainSideResolution(
  chain: PlacedThickWallChain,
  allChains: readonly PlacedThickWallChain[] = [chain],
): ThickWallChainSideResolution {
  const totals: Record<ThickWallChainSideKey, number> = {
    "side-a": 0,
    "side-b": 0,
  };

  getPlacedThickWallChainSegmentGeometries(chain, allChains).forEach((geometry) => {
    const rawEdges = getRawThickWallPlacementSideEdges(geometry);

    totals["side-a"] += rawEdges["side-a"].sideLengthInches;
    totals["side-b"] += rawEdges["side-b"].sideLengthInches;
  });

  const sideA: ThickWallResolvedChainSide = {
    sideKey: "side-a",
    totalLength: totals["side-a"],
  };
  const sideB: ThickWallResolvedChainSide = {
    sideKey: "side-b",
    totalLength: totals["side-b"],
  };
  const sideDifference = sideA.totalLength - sideB.totalLength;
  const interiorSideKey =
    Math.abs(sideDifference) <= THICK_WALL_SIDE_LENGTH_EQUAL_THRESHOLD_INCHES
      ? "side-a"
      : sideDifference < 0
        ? "side-a"
        : "side-b";

  return {
    interiorSideKey,
    exteriorSideKey: getOppositeThickWallChainSideKey(interiorSideKey),
    sides: [sideA, sideB],
  };
}

function getThickWallChainSideKeyForElevationSide(
  chain: PlacedThickWallChain,
  side: ThickWallElevationPlanSide,
  allChains: readonly PlacedThickWallChain[],
): ThickWallChainSideKey {
  const resolution = getThickWallChainSideResolution(chain, allChains);

  return side === "interior"
    ? resolution.interiorSideKey
    : resolution.exteriorSideKey;
}

function getThickWallElevationPlanStartPoint(rawEdge: ThickWallRawSideEdge) {
  // The elevation plan starts from the floor-plan corner that appears on the
  // left when the user stands in front of this physical side path. This depends
  // on the resolved chain side key, not on whether that side is currently named
  // interior or exterior.
  return rawEdge.chainSideKey === "side-a"
    ? rawEdge.floorPlan.sideStartPointInches
    : rawEdge.floorPlan.sideEndPointInches;
}

function getThickWallElevationPlanEndPoint(rawEdge: ThickWallRawSideEdge) {
  return rawEdge.chainSideKey === "side-a"
    ? rawEdge.floorPlan.sideEndPointInches
    : rawEdge.floorPlan.sideStartPointInches;
}

export function getThickWallPlacementSideEdge(
  chain: PlacedThickWallChain,
  geometry: ThickWallSegmentGeometry,
  side: ThickWallElevationPlanSide,
  allChains: readonly PlacedThickWallChain[] = [chain],
): ThickWallPlacementSideEdge {
  const rawEdges = getRawThickWallPlacementSideEdges(geometry);
  const chainSideKey = getThickWallChainSideKeyForElevationSide(
    chain,
    side,
    allChains,
  );
  const rawEdge = rawEdges[chainSideKey];

  return {
    side,
    chainSideKey,
    sideLengthInches: rawEdge.sideLengthInches,
    floorPlan: {
      sideStartPointInches: rawEdge.floorPlan.sideStartPointInches,
      sideEndPointInches: rawEdge.floorPlan.sideEndPointInches,
    },
    elevationPlan: {
      startPointInches: getThickWallElevationPlanStartPoint(rawEdge),
      endPointInches: getThickWallElevationPlanEndPoint(rawEdge),
    },
  };
}

export function getThickWallPlacementSideEdgeForPlacementSide(
  chain: PlacedThickWallChain,
  geometry: ThickWallSegmentGeometry,
  placementSide: ThickWallPlacementSide,
  allChains: readonly PlacedThickWallChain[] = [chain],
): ThickWallPlacementSideEdge | null {
  if (placementSide === "none") {
    return null;
  }

  return getThickWallPlacementSideEdge(
    chain,
    geometry,
    placementSide,
    allChains,
  );
}
