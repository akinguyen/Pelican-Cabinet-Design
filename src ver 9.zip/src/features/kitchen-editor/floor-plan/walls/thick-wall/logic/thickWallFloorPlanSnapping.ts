import { distanceBetweenPoints, projectPointOntoSegment } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThickWallChain } from "@/domains/walls/model/wallTypes";
import {
  THICK_WALL_LINE_INTERSECTION_EPSILON,
  areThickWallPointsEqual,
  getThickWallPointKey,
  getThickWallResolvedCenterlineJointPoint2DInches,
  getThickWallSnapMarkerPoint2DInches,
} from "./thickWallJointGeometry";

export type ThickWallReferenceAxis = "horizontal" | "vertical";

export type ThickWallSnapPoint = Readonly<{
  kind: "thick-wall-path-point";
  chainId: string;
  pointIndex: number;
  point: Point2DInches;
}>;

export type ThickWallCenterlineSnapPoint = Readonly<{
  kind: "thick-wall-centerline";
  chainId: string;
  segmentIndex: number;
  point: Point2DInches;
  segmentStart: Point2DInches;
  segmentEnd: Point2DInches;
}>;

export type ThickWallCatalogStartSnapTarget = Readonly<
  | {
      kind: "thick-wall-catalog-start-path-point";
      markerPointInches: Point2DInches;
      placementPointInches: Point2DInches;
      snapPointInches: ThickWallSnapPoint;
    }
  | {
      kind: "thick-wall-catalog-start-centerline-point";
      markerPointInches: Point2DInches;
      placementPointInches: Point2DInches;
      centerlineSnapPoint: ThickWallCenterlineSnapPoint;
    }
>;

export type ThickWallAxisSnapGuide = Readonly<{
  axis: ThickWallReferenceAxis;
  referencePointInches: Point2DInches;
  isSnapping: boolean;
}>;

export type ThickWallConstructedReferenceGuide = Readonly<{
  horizontalGuide: ThickWallAxisSnapGuide;
  verticalGuide: ThickWallAxisSnapGuide | null;
  centerlineGuide: ThickWallCenterlineSnapPoint | null;
}>;

export type ThickWallSnapCrossPoint = Readonly<{
  point: Point2DInches;
  source:
    | "horizontal-vertical-snap-cross"
    | "vertical-centerline-snap-cross"
    | "horizontal-centerline-snap-cross";
}>;

type ThickWallAxisAlignmentCandidate = Readonly<{
  axis: ThickWallReferenceAxis;
  distance: number;
  referencePointInches: Point2DInches;
}>;

function isPoint2DInchesNearSegmentEndpoint(point: Point2DInches, start: Point2DInches, end: Point2DInches, threshold: number) {
  return (
    distanceBetweenPoints(point, start) <= threshold ||
    distanceBetweenPoints(point, end) <= threshold
  );
}

export function getNearestThickWallCenterlineSnapPoint(
  point: Point2DInches,
  chains: readonly PlacedThickWallChain[],
  snapThreshold: number,
  excludedPoint2DInches: Point2DInches | null,
): ThickWallCenterlineSnapPoint | null {
  let closestSnapPoint: ThickWallCenterlineSnapPoint | null = null;
  let closestDistance = snapThreshold;

  chains.forEach((chain) => {
    chain.floorPlan.centerlinePointsInches.slice(0, -1).forEach((start, segmentIndex) => {
      const end = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
      const projectedPoint2DInches = projectPointOntoSegment(point, start, end).pointInches;

      if (excludedPoint2DInches && areThickWallPointsEqual(projectedPoint2DInches, excludedPoint2DInches)) {
        return;
      }

      // Endpoint snapping is handled by ThickWallSnapPoint. This helper only covers
      // sliding along the inner centerline of an existing thick wall segment.
      if (isPoint2DInchesNearSegmentEndpoint(projectedPoint2DInches, start, end, snapThreshold)) {
        return;
      }

      const distance = distanceBetweenPoints(point, projectedPoint2DInches);

      if (distance <= closestDistance) {
        closestDistance = distance;
        closestSnapPoint = {
          kind: "thick-wall-centerline",
          chainId: chain.id,
          segmentIndex,
          point: projectedPoint2DInches,
          segmentStart: start,
          segmentEnd: end,
        };
      }
    });
  });

  return closestSnapPoint;
}

export function getThickWallSnapPoints(
  chains: readonly PlacedThickWallChain[],
): readonly ThickWallSnapPoint[] {
  const snapPointInchesMap = new Map<string, ThickWallSnapPoint>();

  chains.forEach((chain) => {
    chain.floorPlan.centerlinePointsInches.forEach((point, pointIndex) => {
      snapPointInchesMap.set(getThickWallPointKey(point), {
        kind: "thick-wall-path-point",
        chainId: chain.id,
        pointIndex,
        point,
      });
    });
  });

  return [...snapPointInchesMap.values()];
}

export function getNearestThickWallSnapPoint(
  point: Point2DInches,
  chains: readonly PlacedThickWallChain[],
  snapThreshold: number,
): ThickWallSnapPoint | null {
  let closestSnapPoint: ThickWallSnapPoint | null = null;
  let closestDistance = snapThreshold;

  getThickWallSnapPoints(chains).forEach((snapPointInches) => {
    const markerPointInches = getThickWallSnapMarkerPoint2DInches(snapPointInches, chains);
    const distance = Math.min(
      distanceBetweenPoints(point, snapPointInches.point),
      distanceBetweenPoints(point, markerPointInches),
    );

    if (distance <= closestDistance) {
      closestDistance = distance;
      closestSnapPoint = snapPointInches;
    }
  });

  return closestSnapPoint;
}

export function getNearestThickWallCatalogStartSnapTarget(
  point: Point2DInches,
  chains: readonly PlacedThickWallChain[],
  snapThreshold: number,
): ThickWallCatalogStartSnapTarget | null {
  const nearestSnapPoint = getNearestThickWallSnapPoint(point, chains, snapThreshold);

  if (nearestSnapPoint) {
    const markerPointInches = getThickWallResolvedCenterlineJointPoint2DInches(
      nearestSnapPoint.point,
      chains,
    );

    return {
      kind: "thick-wall-catalog-start-path-point",
      markerPointInches,
      placementPointInches: markerPointInches,
      snapPointInches: nearestSnapPoint,
    };
  }

  const nearestCenterlineSnapPoint = getNearestThickWallCenterlineSnapPoint(
    point,
    chains,
    snapThreshold,
    null,
  );

  if (!nearestCenterlineSnapPoint) {
    return null;
  }

  return {
    kind: "thick-wall-catalog-start-centerline-point",
    markerPointInches: nearestCenterlineSnapPoint.point,
    placementPointInches: nearestCenterlineSnapPoint.point,
    centerlineSnapPoint: nearestCenterlineSnapPoint,
  };
}

function getNearestThickWallAxisSnapGuides(
  point: Point2DInches,
  chains: readonly PlacedThickWallChain[],
  snapThreshold: number,
  origin: Point2DInches,
): Pick<ThickWallConstructedReferenceGuide, "horizontalGuide" | "verticalGuide"> {
  let closestHorizontalCandidate: ThickWallAxisAlignmentCandidate | null = null;
  let closestVerticalCandidate: ThickWallAxisAlignmentCandidate | null = null;

  const referencePointsInches = [
    origin,
    ...getThickWallSnapPoints(chains)
      .map((snapPointInches) => getThickWallResolvedCenterlineJointPoint2DInches(snapPointInches.point, chains))
      .filter((referencePointInches) => !areThickWallPointsEqual(referencePointInches, origin)),
  ];

  for (const referencePointInches of referencePointsInches) {
    const horizontalDistance = Math.abs(point.yInches - referencePointInches.yInches);
    const verticalDistance = Math.abs(point.xInches - referencePointInches.xInches);

    if (
      horizontalDistance <= snapThreshold &&
      (!closestHorizontalCandidate || horizontalDistance < closestHorizontalCandidate.distance)
    ) {
      closestHorizontalCandidate = {
        axis: "horizontal",
        distance: horizontalDistance,
        referencePointInches,
      };
    }

    if (
      verticalDistance <= snapThreshold &&
      (!closestVerticalCandidate || verticalDistance < closestVerticalCandidate.distance)
    ) {
      closestVerticalCandidate = {
        axis: "vertical",
        distance: verticalDistance,
        referencePointInches,
      };
    }
  }

  return {
    horizontalGuide: {
      axis: "horizontal",
      referencePointInches: closestHorizontalCandidate?.referencePointInches ?? origin,
      isSnapping: Boolean(closestHorizontalCandidate),
    },
    verticalGuide: closestVerticalCandidate
      ? {
          axis: "vertical",
          referencePointInches: closestVerticalCandidate.referencePointInches,
          isSnapping: true,
        }
      : null,
  };
}

export function getNearestThickWallConstructedReferenceGuide(
  point: Point2DInches,
  chains: readonly PlacedThickWallChain[],
  snapThreshold: number,
  origin: Point2DInches,
): ThickWallConstructedReferenceGuide {
  return {
    ...getNearestThickWallAxisSnapGuides(point, chains, snapThreshold, origin),
    centerlineGuide: null,
  };
}

function getLineIntersectionWithVerticalX(
  lineStart: Point2DInches,
  lineEnd: Point2DInches,
  xInches: number,
): Point2DInches | null {
  const deltaX = lineEnd.xInches - lineStart.xInches;

  if (Math.abs(deltaX) < THICK_WALL_LINE_INTERSECTION_EPSILON) {
    return null;
  }

  const factor = (xInches - lineStart.xInches) / deltaX;

  return {
    xInches,
    yInches: lineStart.yInches + (lineEnd.yInches - lineStart.yInches) * factor,
  };
}

function getLineIntersectionWithHorizontalY(
  lineStart: Point2DInches,
  lineEnd: Point2DInches,
  yInches: number,
): Point2DInches | null {
  const deltaY = lineEnd.yInches - lineStart.yInches;

  if (Math.abs(deltaY) < THICK_WALL_LINE_INTERSECTION_EPSILON) {
    return null;
  }

  const factor = (yInches - lineStart.yInches) / deltaY;

  return {
    xInches: lineStart.xInches + (lineEnd.xInches - lineStart.xInches) * factor,
    yInches,
  };
}

function getUniqueCrossPoints(crossPoints: readonly ThickWallSnapCrossPoint[]) {
  const crossPoint2DInchesMap = new Map<string, ThickWallSnapCrossPoint>();

  crossPoints.forEach((crossPoint2DInches) => {
    crossPoint2DInchesMap.set(getThickWallPointKey(crossPoint2DInches.point), crossPoint2DInches);
  });

  return [...crossPoint2DInchesMap.values()];
}

export function getThickWallSnapCrossPoints(
  referenceGuide: ThickWallConstructedReferenceGuide,
): readonly ThickWallSnapCrossPoint[] {
  const crossPoints: ThickWallSnapCrossPoint[] = [];

  if (referenceGuide.verticalGuide && referenceGuide.horizontalGuide.isSnapping) {
    crossPoints.push({
      point: {
        xInches: referenceGuide.verticalGuide.referencePointInches.xInches,
        yInches: referenceGuide.horizontalGuide.referencePointInches.yInches,
      },
      source: "horizontal-vertical-snap-cross",
    });
  }

  if (referenceGuide.centerlineGuide) {
    const centerline = referenceGuide.centerlineGuide;

    if (referenceGuide.verticalGuide) {
      const verticalCrossPoint2DInches = getLineIntersectionWithVerticalX(
        centerline.segmentStart,
        centerline.segmentEnd,
        referenceGuide.verticalGuide.referencePointInches.xInches,
      );

      if (verticalCrossPoint2DInches) {
        crossPoints.push({
          point: verticalCrossPoint2DInches,
          source: "vertical-centerline-snap-cross",
        });
      }
    }

    if (referenceGuide.horizontalGuide.isSnapping) {
      const horizontalCrossPoint2DInches = getLineIntersectionWithHorizontalY(
        centerline.segmentStart,
        centerline.segmentEnd,
        referenceGuide.horizontalGuide.referencePointInches.yInches,
      );

      if (horizontalCrossPoint2DInches) {
        crossPoints.push({
          point: horizontalCrossPoint2DInches,
          source: "horizontal-centerline-snap-cross",
        });
      }
    }
  }

  return getUniqueCrossPoints(crossPoints);
}

export function getNearestThickWallSnapCrossPoint(
  point: Point2DInches,
  referenceGuide: ThickWallConstructedReferenceGuide,
  snapThreshold: number,
): ThickWallSnapCrossPoint | null {
  return getThickWallSnapCrossPoints(referenceGuide).reduce<ThickWallSnapCrossPoint | null>(
    (closestCrossPoint2DInches, crossPoint2DInches) => {
      const distance = distanceBetweenPoints(point, crossPoint2DInches.point);

      if (distance > snapThreshold) {
        return closestCrossPoint2DInches;
      }

      if (!closestCrossPoint2DInches) {
        return crossPoint2DInches;
      }

      return distance < distanceBetweenPoints(point, closestCrossPoint2DInches.point)
        ? crossPoint2DInches
        : closestCrossPoint2DInches;
    },
    null,
  );
}

export function snapPointInchesToThickWallConstructedReferenceGuide(
  point: Point2DInches,
  referenceGuide: ThickWallConstructedReferenceGuide,
): Point2DInches {
  if (referenceGuide.centerlineGuide) {
    return referenceGuide.centerlineGuide.point;
  }

  if (referenceGuide.verticalGuide && referenceGuide.horizontalGuide.isSnapping) {
    return {
      xInches: referenceGuide.verticalGuide.referencePointInches.xInches,
      yInches: referenceGuide.horizontalGuide.referencePointInches.yInches,
    };
  }

  if (referenceGuide.verticalGuide) {
    return {
      xInches: referenceGuide.verticalGuide.referencePointInches.xInches,
      yInches: point.yInches,
    };
  }

  if (referenceGuide.horizontalGuide.isSnapping) {
    return {
      xInches: point.xInches,
      yInches: referenceGuide.horizontalGuide.referencePointInches.yInches,
    };
  }

  return point;
}
