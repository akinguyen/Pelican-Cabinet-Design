import { getAngleDegrees } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThickWallChain } from "@/domains/walls/model/wallTypes";
import {
  getEndpointJointPair,
  getResolvedConnectionPair,
  getResolvedJointMap,
  getSingleConnectionJointPair,
  type ThickWallPathPointConnection,
} from "./thickWallJointGeometry";

export type ThickWallSegmentGeometry = Readonly<{
  floorPlan: Readonly<{
    centerlineStartPointInches: Point2DInches;
    centerlineEndPointInches: Point2DInches;
    startLeftCornerPointInches: Point2DInches;
    startRightCornerPointInches: Point2DInches;
    endLeftCornerPointInches: Point2DInches;
    endRightCornerPointInches: Point2DInches;
    polygonInches: readonly Point2DInches[];
  }>;
  thicknessInches: number;
  centerAngleDegrees: number;
}>;

export function getThickWallSegmentGeometry(
  startPointInches: Point2DInches,
  endPointInches: Point2DInches,
  thicknessInches: number,
): ThickWallSegmentGeometry {
  const startPair = getEndpointJointPair(startPointInches, startPointInches, endPointInches, thicknessInches);
  const endPair = getEndpointJointPair(endPointInches, startPointInches, endPointInches, thicknessInches);

  return {
    floorPlan: {
      centerlineStartPointInches: startPointInches,
      centerlineEndPointInches: endPointInches,
      startLeftCornerPointInches: startPair.left,
      startRightCornerPointInches: startPair.right,
      endLeftCornerPointInches: endPair.left,
      endRightCornerPointInches: endPair.right,
      polygonInches: [startPair.left, endPair.left, endPair.right, startPair.right],
    },
    thicknessInches,
    centerAngleDegrees: getAngleDegrees(startPointInches, endPointInches),
  };
}

export function getPlacedThickWallChainSegmentGeometries(
  chain: PlacedThickWallChain,
  allChains: readonly PlacedThickWallChain[] = [chain],
): readonly ThickWallSegmentGeometry[] {
  const jointMap = getResolvedJointMap(allChains);

  return chain.floorPlan.centerlinePointsInches.slice(0, -1).map((startPointInches, segmentIndex) => {
    const endPointInches = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
    const startConnection: ThickWallPathPointConnection = {
      chainId: chain.id,
      segmentIndex,
      pointIndex: segmentIndex,
      point: startPointInches,
      otherPoint2DInches: endPointInches,
      thicknessInches: chain.thicknessInches,
      angleRadians: Math.atan2(endPointInches.yInches - startPointInches.yInches, endPointInches.xInches - startPointInches.xInches),
    };
    const endConnection: ThickWallPathPointConnection = {
      chainId: chain.id,
      segmentIndex,
      pointIndex: segmentIndex + 1,
      point: endPointInches,
      otherPoint2DInches: startPointInches,
      thicknessInches: chain.thicknessInches,
      angleRadians: Math.atan2(startPointInches.yInches - endPointInches.yInches, startPointInches.xInches - endPointInches.xInches),
    };
    const startPair =
      getResolvedConnectionPair(jointMap, startConnection) ??
      getSingleConnectionJointPair(startConnection);
    const endPair =
      getResolvedConnectionPair(jointMap, endConnection) ??
      getSingleConnectionJointPair(endConnection);

    return {
      floorPlan: {
        centerlineStartPointInches: startPointInches,
        centerlineEndPointInches: endPointInches,
        startLeftCornerPointInches: startPair.left,
        startRightCornerPointInches: startPair.right,
        endLeftCornerPointInches: endPair.left,
        endRightCornerPointInches: endPair.right,
        polygonInches: [startPair.left, endPair.left, endPair.right, startPair.right],
      },
      thicknessInches: chain.thicknessInches,
      centerAngleDegrees: getAngleDegrees(startPointInches, endPointInches),
    };
  });
}
