import { getPointToSegmentDistance } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { ThickWallSegmentSelection } from "@/features/kitchen-editor/state/designStoreTypes";
import type { PlacedThickWallChain } from "@/domains/walls/model/wallTypes";

export function getThickWallSegmentAtPoint2DInches(
  point: Point2DInches,
  chains: readonly PlacedThickWallChain[],
  hitThreshold: number,
): ThickWallSegmentSelection | null {
  let closestSelection: ThickWallSegmentSelection | null = null;
  let closestDistance = Number.POSITIVE_INFINITY;

  chains.forEach((chain) => {
    chain.floorPlan.centerlinePointsInches.slice(0, -1).forEach((start, segmentIndex) => {
      const end = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
      const distance = getPointToSegmentDistance(point, start, end);
      const maxDistance = chain.thicknessInches / 2 + hitThreshold;

      if (distance <= maxDistance && distance < closestDistance) {
        closestDistance = distance;
        closestSelection = {
          type: "thick-wall-segment",
          chainId: chain.id,
          segmentIndex,
        };
      }
    });
  });

  return closestSelection;
}
