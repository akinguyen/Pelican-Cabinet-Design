import { useMemo, useState } from "react";
import { pixelsToInches } from "@/shared/units/length";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThickWallChain } from "@/domains/walls/model/wallTypes";
import { DEFAULT_THICK_WALL_THICKNESS_INCHES, useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";
import {
  getNearestThickWallCatalogStartSnapTarget,
  getNearestThickWallCenterlineSnapPoint,
  getNearestThickWallConstructedReferenceGuide,
  getNearestThickWallSnapCrossPoint,
  getNearestThickWallSnapPoint,
  snapPointInchesToThickWallConstructedReferenceGuide,
  type ThickWallCatalogStartSnapTarget,
  type ThickWallCenterlineSnapPoint,
  type ThickWallConstructedReferenceGuide,
  type ThickWallSnapPoint,
} from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallFloorPlanSnapping";
import {
  getThickWallFloorPlanCandidateChains,
  isThickWallFloorPlanCandidateOverlappingConnectedCollinearSegment,
  snapPointInchesToHorizontalOrVerticalAxis,
} from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallFloorPlanCandidateGeometry";
import {
  getThickWallResolvedCenterlineJointPoint2DInches,
  getThickWallSnapMarkerPoint2DInches,
} from "@/features/kitchen-editor/floor-plan/walls/thick-wall/logic/thickWallJointGeometry";

const AXIS_SNAP_THRESHOLD_PIXELS = 8;
const POINT_SNAP_THRESHOLD_PIXELS = 14;
const CROSS_POINT_SNAP_THRESHOLD_PIXELS = 12;
const CENTERLINE_SNAP_THRESHOLD_PIXELS = 12;
const CONSTRUCTED_REFERENCE_GUIDE_THRESHOLD_PIXELS = 10;
const LOGICAL_POINT_MATCH_THRESHOLD_INCHES = 0.001;

type UseThickWallDrawingParams = Readonly<{
  floorPlanPixelsPerInch: number;
}>;

type ThickWallDrawablePoint2DInches = Readonly<{
  visualPoint2DInches: Point2DInches;
  logicalPoint2DInches: Point2DInches;
  constructedReferenceGuide: ThickWallConstructedReferenceGuide | null;
  snapPointInches: ThickWallSnapPoint | null;
  centerlineSnapPoint: ThickWallCenterlineSnapPoint | null;
  catalogStartSnapTarget: ThickWallCatalogStartSnapTarget | null;
}>;

function getResolvedCandidateReferencePoint2DInches(
  logicalPoint2DInches: Point2DInches | null,
  candidatePlacedThickWallChains: readonly PlacedThickWallChain[],
): Point2DInches | null {
  if (!logicalPoint2DInches) {
    return null;
  }

  return getThickWallResolvedCenterlineJointPoint2DInches(logicalPoint2DInches, candidatePlacedThickWallChains);
}

function getCatalogStartMarkerPoint2DInches(
  target: ThickWallCatalogStartSnapTarget | null,
): Point2DInches | null {
  return target?.markerPointInches ?? null;
}

function getVisualPoint2DInchesFromLogicalPoint2DInches(
  logicalPoint2DInches: Point2DInches | null,
  placedThickWallChains: readonly PlacedThickWallChain[],
): Point2DInches | null {
  if (!logicalPoint2DInches) {
    return null;
  }

  const matchingSnapPoint = getNearestThickWallSnapPoint(
    logicalPoint2DInches,
    placedThickWallChains,
    LOGICAL_POINT_MATCH_THRESHOLD_INCHES,
  );

  if (!matchingSnapPoint) {
    return logicalPoint2DInches;
  }

  return getThickWallSnapMarkerPoint2DInches(matchingSnapPoint, placedThickWallChains);
}

function withCenterlineSnapGuide(
  referenceGuide: ThickWallConstructedReferenceGuide,
  centerlineSnapPoint: ThickWallCenterlineSnapPoint,
): ThickWallConstructedReferenceGuide {
  return {
    ...referenceGuide,
    centerlineGuide: centerlineSnapPoint,
  };
}

export function useThickWallFloorPlanDrawing({ floorPlanPixelsPerInch }: UseThickWallDrawingParams) {
  const [hoveredSnapPoint, setHoveredSnapPoint] = useState<ThickWallSnapPoint | null>(null);
  const [catalogStartSnapTarget, setCatalogStartSnapTarget] =
    useState<ThickWallCatalogStartSnapTarget | null>(null);
  const [centerlineSnapPoint, setCenterlineSnapPoint] =
    useState<ThickWallCenterlineSnapPoint | null>(null);
  const [constructedReferenceGuide, setConstructedReferenceGuide] =
    useState<ThickWallConstructedReferenceGuide | null>(null);

  const activeTool = useDesignStore((state) => state.activeTool);
  const placedThickWallChains = useDesignStore((state) => state.placedThickWallChains);
  const candidateThickWallSegment = useDesignStore((state) => state.candidateThickWallSegment);
  const startCandidateThickWallSegment = useDesignStore((state) => state.startCandidateThickWallSegment);
  const updateCandidateThickWallSegment = useDesignStore((state) => state.updateCandidateThickWallSegment);
  const commitCandidateThickWallSegment = useDesignStore((state) => state.commitCandidateThickWallSegment);

  const activeChain = useMemo(
    () =>
      candidateThickWallSegment?.chainId
        ? placedThickWallChains.find((chain) => chain.id === candidateThickWallSegment.chainId) ?? null
        : null,
    [candidateThickWallSegment?.chainId, placedThickWallChains],
  );

  const logicalOrigin = candidateThickWallSegment?.floorPlan.startPointInches ?? null;
  const candidatePointInches = candidateThickWallSegment?.floorPlan.endPointInches ?? null;
  const candidatePlacedThickWallChains = useMemo(
    () =>
      getThickWallFloorPlanCandidateChains({
        candidateThickWallSegment,
        chains: placedThickWallChains,
      }),
    [candidateThickWallSegment, placedThickWallChains],
  );
  const resolvedCandidateOrigin = getResolvedCandidateReferencePoint2DInches(
    logicalOrigin,
    candidatePlacedThickWallChains,
  );
  const visualOrigin =
    resolvedCandidateOrigin ?? getVisualPoint2DInchesFromLogicalPoint2DInches(logicalOrigin, placedThickWallChains);
  const thickness = candidateThickWallSegment?.thicknessInches ?? activeChain?.thicknessInches ?? DEFAULT_THICK_WALL_THICKNESS_INCHES;
  const isDrawingThickWall = activeTool === "draw-thick-wall";
  const isCatalogStart = !candidateThickWallSegment;

  const getCatalogStartDrawablePoint2DInches = (point: Point2DInches): ThickWallDrawablePoint2DInches => {
    const snapThreshold = pixelsToInches(CENTERLINE_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestCatalogStartSnapTarget = getNearestThickWallCatalogStartSnapTarget(
      point,
      placedThickWallChains,
      snapThreshold,
    );

    if (nearestCatalogStartSnapTarget) {
      return {
        visualPoint2DInches: nearestCatalogStartSnapTarget.markerPointInches,
        logicalPoint2DInches: nearestCatalogStartSnapTarget.placementPointInches,
        constructedReferenceGuide: null,
        snapPointInches:
          nearestCatalogStartSnapTarget.kind === "thick-wall-catalog-start-path-point"
            ? nearestCatalogStartSnapTarget.snapPointInches
            : null,
        centerlineSnapPoint:
          nearestCatalogStartSnapTarget.kind === "thick-wall-catalog-start-centerline-point"
            ? nearestCatalogStartSnapTarget.centerlineSnapPoint
            : null,
        catalogStartSnapTarget: nearestCatalogStartSnapTarget,
      };
    }

    return {
      visualPoint2DInches: point,
      logicalPoint2DInches: point,
      constructedReferenceGuide: null,
      snapPointInches: null,
      centerlineSnapPoint: null,
      catalogStartSnapTarget: null,
    };
  };

  const getChainContinuationDrawablePoint2DInches = (point: Point2DInches): ThickWallDrawablePoint2DInches => {
    const pointSnapThreshold = pixelsToInches(POINT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestSnapPoint = getNearestThickWallSnapPoint(
      point,
      placedThickWallChains,
      pointSnapThreshold,
    );

    if (nearestSnapPoint) {
      return {
        visualPoint2DInches: nearestSnapPoint.point,
        logicalPoint2DInches: nearestSnapPoint.point,
        constructedReferenceGuide: null,
        snapPointInches: nearestSnapPoint,
        centerlineSnapPoint: null,
        catalogStartSnapTarget: null,
      };
    }

    if (!visualOrigin) {
      return {
        visualPoint2DInches: point,
        logicalPoint2DInches: point,
        constructedReferenceGuide: null,
        snapPointInches: null,
        centerlineSnapPoint: null,
        catalogStartSnapTarget: null,
      };
    }

    const referenceGuideSnapThreshold =
      pixelsToInches(CONSTRUCTED_REFERENCE_GUIDE_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestConstructedReferenceGuide = getNearestThickWallConstructedReferenceGuide(
      point,
      placedThickWallChains,
      referenceGuideSnapThreshold,
      visualOrigin,
    );

    const centerlineSnapThreshold = pixelsToInches(CENTERLINE_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestCenterlineSnapPoint = getNearestThickWallCenterlineSnapPoint(
      point,
      placedThickWallChains,
      centerlineSnapThreshold,
      visualOrigin,
    );

    if (nearestCenterlineSnapPoint) {
      const centerlineReferenceGuide = withCenterlineSnapGuide(
        nearestConstructedReferenceGuide,
        nearestCenterlineSnapPoint,
      );
      const crossPoint2DInchesSnapThreshold = pixelsToInches(CROSS_POINT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
      const nearestCrossPoint2DInches = getNearestThickWallSnapCrossPoint(
        point,
        centerlineReferenceGuide,
        crossPoint2DInchesSnapThreshold,
      );
      const visualPoint2DInches =
        nearestCrossPoint2DInches?.point ??
        snapPointInchesToThickWallConstructedReferenceGuide(point, centerlineReferenceGuide);

      return {
        visualPoint2DInches,
        logicalPoint2DInches: visualPoint2DInches,
        constructedReferenceGuide: centerlineReferenceGuide,
        snapPointInches: null,
        centerlineSnapPoint: nearestCenterlineSnapPoint,
        catalogStartSnapTarget: null,
      };
    }

    const crossPoint2DInchesSnapThreshold = pixelsToInches(CROSS_POINT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestCrossPoint2DInches = getNearestThickWallSnapCrossPoint(
      point,
      nearestConstructedReferenceGuide,
      crossPoint2DInchesSnapThreshold,
    );

    if (nearestCrossPoint2DInches) {
      return {
        visualPoint2DInches: nearestCrossPoint2DInches.point,
        logicalPoint2DInches: nearestCrossPoint2DInches.point,
        constructedReferenceGuide: nearestConstructedReferenceGuide,
        snapPointInches: null,
        centerlineSnapPoint: null,
        catalogStartSnapTarget: null,
      };
    }

    const snappedReferencePoint2DInches = snapPointInchesToThickWallConstructedReferenceGuide(
      point,
      nearestConstructedReferenceGuide,
    );

    if (
      snappedReferencePoint2DInches.xInches !== point.xInches ||
      snappedReferencePoint2DInches.yInches !== point.yInches ||
      nearestConstructedReferenceGuide.verticalGuide ||
      nearestConstructedReferenceGuide.horizontalGuide.isSnapping
    ) {
      return {
        visualPoint2DInches: snappedReferencePoint2DInches,
        logicalPoint2DInches: snappedReferencePoint2DInches,
        constructedReferenceGuide: nearestConstructedReferenceGuide,
        snapPointInches: null,
        centerlineSnapPoint: null,
        catalogStartSnapTarget: null,
      };
    }

    const visualPoint2DInches = snapPointInchesToHorizontalOrVerticalAxis(
      point,
      visualOrigin,
      pixelsToInches(AXIS_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch),
    ).point;

    return {
      visualPoint2DInches,
      logicalPoint2DInches: visualPoint2DInches,
      constructedReferenceGuide: nearestConstructedReferenceGuide,
      snapPointInches: null,
      centerlineSnapPoint: null,
      catalogStartSnapTarget: null,
    };
  };

  const getDrawablePoint2DInches = (point: Point2DInches): ThickWallDrawablePoint2DInches => {
    if (isCatalogStart) {
      return getCatalogStartDrawablePoint2DInches(point);
    }

    return getChainContinuationDrawablePoint2DInches(point);
  };

  const isOverlappingConnectedCollinearSegment = (point: Point2DInches) =>
    Boolean(
      logicalOrigin &&
        !isCatalogStart &&
        isThickWallFloorPlanCandidateOverlappingConnectedCollinearSegment({
          chains: placedThickWallChains,
          candidatePoint2DInches: point,
          origin: logicalOrigin,
        }),
    );

  return {
    activeChain,
    catalogStartMarkerPoint2DInches: getCatalogStartMarkerPoint2DInches(catalogStartSnapTarget),
    centerlineSnapPoint,
    constructedReferenceGuide,
    hoveredSnapPoint,
    origin: visualOrigin,
    candidateThickWallSegment,
    candidatePoint: candidatePointInches,
    candidatePointInches,
    isCatalogStart,
    isDrawingThickWall,
    thicknessInches: thickness,
    placePoint: (point: Point2DInches) => {
      const drawablePoint2DInches = getDrawablePoint2DInches(point);

      if (isOverlappingConnectedCollinearSegment(drawablePoint2DInches.logicalPoint2DInches)) {
        return;
      }

      if (!candidateThickWallSegment) {
        startCandidateThickWallSegment(drawablePoint2DInches.logicalPoint2DInches);
      } else {
        updateCandidateThickWallSegment(drawablePoint2DInches.logicalPoint2DInches);
        commitCandidateThickWallSegment();
      }
      setCatalogStartSnapTarget(null);
      setCenterlineSnapPoint(null);
      setConstructedReferenceGuide(null);
      setHoveredSnapPoint(null);
    },
    updateCandidatePoint: (point: Point2DInches | null) => {
      if (!point) {
        setCatalogStartSnapTarget(null);
        setCenterlineSnapPoint(null);
        setConstructedReferenceGuide(null);
        setHoveredSnapPoint(null);
        return;
      }

      const drawablePoint2DInches = getDrawablePoint2DInches(point);

      setCatalogStartSnapTarget(drawablePoint2DInches.catalogStartSnapTarget);
      setCenterlineSnapPoint(drawablePoint2DInches.centerlineSnapPoint);
      setConstructedReferenceGuide(drawablePoint2DInches.constructedReferenceGuide);
      setHoveredSnapPoint(isCatalogStart ? drawablePoint2DInches.snapPointInches : null);
      if (visualOrigin && !isOverlappingConnectedCollinearSegment(drawablePoint2DInches.logicalPoint2DInches)) {
        updateCandidateThickWallSegment(drawablePoint2DInches.visualPoint2DInches);
        return;
      }

      if (visualOrigin) {
        updateCandidateThickWallSegment(visualOrigin);
      }
    },
  };
}
