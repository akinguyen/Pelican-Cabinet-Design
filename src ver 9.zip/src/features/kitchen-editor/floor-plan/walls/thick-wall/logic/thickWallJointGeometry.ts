import { getUnitVector } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThickWallChain } from "@/domains/walls/model/wallTypes";

export type ThickWallJointFillPolygon = Readonly<{
  id: string;
  floorPlan: Readonly<{
    polygonInches: readonly Point2DInches[];
  }>;
}>;

export type ThickWallJointPair = Readonly<{
  left: Point2DInches;
  right: Point2DInches;
}>;

export type ThickWallPathPointConnection = Readonly<{
  chainId: string;
  segmentIndex: number;
  pointIndex: number;
  point: Point2DInches;
  otherPoint2DInches: Point2DInches;
  thicknessInches: number;
  angleRadians: number;
}>;

type ThickWallResolvedJoint = Readonly<{
  point: Point2DInches;
  connections: readonly ThickWallPathPointConnection[];
  cornerByConnectionKey: ReadonlyMap<string, ThickWallJointPair>;
  fillPolygon: readonly Point2DInches[] | null;
}>;

const POINT_KEY_PRECISION = 1000;
export const THICK_WALL_LINE_INTERSECTION_EPSILON = 0.0001;
const MIN_JOINT_MITER_SINE = 0.35;

export function getThickWallPointKey(point: Point2DInches) {
  const x = Math.round(point.xInches * POINT_KEY_PRECISION) / POINT_KEY_PRECISION;
  const y = Math.round(point.yInches * POINT_KEY_PRECISION) / POINT_KEY_PRECISION;

  return `${x}:${y}`;
}

function getConnectionKey(connection: ThickWallPathPointConnection) {
  return `${connection.chainId}:${connection.segmentIndex}:${connection.pointIndex}`;
}

export function areThickWallPointsEqual(first: Point2DInches, second: Point2DInches) {
  return getThickWallPointKey(first) === getThickWallPointKey(second);
}

function translatePoint2DInches(point: Point2DInches, offset: Point2DInches): Point2DInches {
  return {
    xInches: point.xInches + offset.xInches,
    yInches: point.yInches + offset.yInches,
  };
}

function subtractPoints(first: Point2DInches, second: Point2DInches): Point2DInches {
  return {
    xInches: first.xInches - second.xInches,
    yInches: first.yInches - second.yInches,
  };
}

function scaleVector(vector: Point2DInches, value: number): Point2DInches {
  return {
    xInches: vector.xInches * value,
    yInches: vector.yInches * value,
  };
}

function getUnitNormal(start: Point2DInches, end: Point2DInches) {
  const direction = getUnitVector(start, end);

  return {
    xInches: -direction.yInches,
    yInches: direction.xInches,
  };
}

function getLineIntersection(
  firstStart: Point2DInches,
  firstEnd: Point2DInches,
  secondStart: Point2DInches,
  secondEnd: Point2DInches,
): Point2DInches | null {
  const firstDelta = subtractPoints(firstEnd, firstStart);
  const secondDelta = subtractPoints(secondEnd, secondStart);
  const denominator = firstDelta.xInches * secondDelta.yInches - firstDelta.yInches * secondDelta.xInches;

  if (Math.abs(denominator) < THICK_WALL_LINE_INTERSECTION_EPSILON) {
    return null;
  }

  const startDelta = subtractPoints(secondStart, firstStart);
  const factor =
    (startDelta.xInches * secondDelta.yInches - startDelta.yInches * secondDelta.xInches) / denominator;

  return {
    xInches: firstStart.xInches + firstDelta.xInches * factor,
    yInches: firstStart.yInches + firstDelta.yInches * factor,
  };
}

export function getEndpointJointPair(
  point: Point2DInches,
  segmentStart: Point2DInches,
  segmentEnd: Point2DInches,
  thicknessInches: number,
): ThickWallJointPair {
  const halfThickness = thicknessInches / 2;
  const normal = getUnitNormal(segmentStart, segmentEnd);
  const offset = scaleVector(normal, halfThickness);

  return {
    left: translatePoint2DInches(point, offset),
    right: translatePoint2DInches(point, scaleVector(offset, -1)),
  };
}

function getOffsetLineForConnection(
  connection: ThickWallPathPointConnection,
  side: "left" | "right",
) {
  const halfThickness = connection.thicknessInches / 2;
  const sideMultiplier = side === "left" ? 1 : -1;
  const normal = getUnitNormal(connection.point, connection.otherPoint2DInches);
  const offset = scaleVector(normal, halfThickness * sideMultiplier);

  return {
    start: translatePoint2DInches(connection.point, offset),
    end: translatePoint2DInches(connection.otherPoint2DInches, offset),
  };
}

function getPositiveAngleDelta(startRadians: number, endRadians: number) {
  const fullCircle = Math.PI * 2;
  const delta = (endRadians - startRadians + fullCircle) % fullCircle;

  return delta === 0 ? fullCircle : delta;
}

function getCappedJointCorner(
  current: ThickWallPathPointConnection,
  next: ThickWallPathPointConnection,
): Point2DInches {
  const delta = getPositiveAngleDelta(current.angleRadians, next.angleRadians);
  const angle = current.angleRadians + delta / 2;
  const maxHalfThickness = Math.max(current.thicknessInches, next.thicknessInches) / 2;
  const miterLength = maxHalfThickness / Math.max(Math.sin(delta / 2), MIN_JOINT_MITER_SINE);

  return {
    xInches: current.point.xInches + Math.cos(angle) * miterLength,
    yInches: current.point.yInches + Math.sin(angle) * miterLength,
  };
}

function getSectorCorner(
  current: ThickWallPathPointConnection,
  next: ThickWallPathPointConnection,
): Point2DInches {
  const currentLine = getOffsetLineForConnection(current, "left");
  const nextLine = getOffsetLineForConnection(next, "right");
  const miterCorner = getLineIntersection(
    currentLine.start,
    currentLine.end,
    nextLine.start,
    nextLine.end,
  );

  return miterCorner ?? getCappedJointCorner(current, next);
}

function getConnectionJointPair(
  connection: ThickWallPathPointConnection,
  branchLeftCorner: Point2DInches,
  branchRightCorner: Point2DInches,
): ThickWallJointPair {
  const isSegmentStart = connection.pointIndex === connection.segmentIndex;

  if (isSegmentStart) {
    return {
      left: branchLeftCorner,
      right: branchRightCorner,
    };
  }

  return {
    left: branchRightCorner,
    right: branchLeftCorner,
  };
}

export function getSingleConnectionJointPair(
  connection: ThickWallPathPointConnection,
): ThickWallJointPair {
  const isSegmentStart = connection.pointIndex === connection.segmentIndex;

  if (isSegmentStart) {
    return getEndpointJointPair(
      connection.point,
      connection.point,
      connection.otherPoint2DInches,
      connection.thicknessInches,
    );
  }

  return getEndpointJointPair(
    connection.point,
    connection.otherPoint2DInches,
    connection.point,
    connection.thicknessInches,
  );
}

function getPointConnectionMap(chains: readonly PlacedThickWallChain[]) {
  const connectionMap = new Map<string, ThickWallPathPointConnection[]>();

  chains.forEach((chain) => {
    chain.floorPlan.centerlinePointsInches.slice(0, -1).forEach((start, segmentIndex) => {
      const end = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
      const connections: readonly ThickWallPathPointConnection[] = [
        {
          chainId: chain.id,
          segmentIndex,
          pointIndex: segmentIndex,
          point: start,
          otherPoint2DInches: end,
          thicknessInches: chain.thicknessInches,
          angleRadians: Math.atan2(end.yInches - start.yInches, end.xInches - start.xInches),
        },
        {
          chainId: chain.id,
          segmentIndex,
          pointIndex: segmentIndex + 1,
          point: end,
          otherPoint2DInches: start,
          thicknessInches: chain.thicknessInches,
          angleRadians: Math.atan2(start.yInches - end.yInches, start.xInches - end.xInches),
        },
      ];

      connections.forEach((connection) => {
        const pointKey = getThickWallPointKey(connection.point);
        const currentConnections = connectionMap.get(pointKey) ?? [];

        connectionMap.set(pointKey, [...currentConnections, connection]);
      });
    });
  });

  return connectionMap;
}

function getResolvedJoint(
  connections: readonly ThickWallPathPointConnection[],
): ThickWallResolvedJoint {
  if (connections.length === 0) {
    return {
      point: { xInches: 0, yInches: 0 },
      connections,
      cornerByConnectionKey: new Map(),
      fillPolygon: null,
    };
  }

  if (connections.length === 1) {
    const connection = connections[0];

    return {
      point: connection.point,
      connections,
      cornerByConnectionKey: new Map([
        [getConnectionKey(connection), getSingleConnectionJointPair(connection)],
      ]),
      fillPolygon: null,
    };
  }

  const sortedConnections = [...connections].sort(
    (first, second) => first.angleRadians - second.angleRadians,
  );
  const branchCorners = sortedConnections.map((connection, index) => {
    const nextConnection = sortedConnections[(index + 1) % sortedConnections.length];

    return getSectorCorner(connection, nextConnection);
  });
  const cornerByConnectionKey = new Map<string, ThickWallJointPair>();

  sortedConnections.forEach((connection, index) => {
    const leftCorner = branchCorners[index];
    const rightCorner = branchCorners[(index - 1 + branchCorners.length) % branchCorners.length];

    cornerByConnectionKey.set(
      getConnectionKey(connection),
      getConnectionJointPair(connection, leftCorner, rightCorner),
    );
  });

  return {
    point: sortedConnections[0].point,
    connections: sortedConnections,
    cornerByConnectionKey,
    fillPolygon: sortedConnections.length >= 3 ? branchCorners : null,
  };
}

export function getResolvedJointMap(chains: readonly PlacedThickWallChain[]) {
  const connectionMap = getPointConnectionMap(chains);
  const jointMap = new Map<string, ThickWallResolvedJoint>();

  connectionMap.forEach((connections, pointKey) => {
    jointMap.set(pointKey, getResolvedJoint(connections));
  });

  return jointMap;
}

export function getResolvedConnectionPair(
  jointMap: ReadonlyMap<string, ThickWallResolvedJoint>,
  connection: ThickWallPathPointConnection,
) {
  const pointKey = getThickWallPointKey(connection.point);
  const joint = jointMap.get(pointKey);

  return joint?.cornerByConnectionKey.get(getConnectionKey(connection));
}

function getUniquePoints(points: readonly Point2DInches[]) {
  const pointMap = new Map<string, Point2DInches>();

  points.forEach((point) => {
    pointMap.set(getThickWallPointKey(point), point);
  });

  return [...pointMap.values()];
}

function getAveragePoint2DInches(points: readonly Point2DInches[]): Point2DInches | null {
  if (points.length === 0) {
    return null;
  }

  const total = points.reduce(
    (sum, point) => ({
      xInches: sum.xInches + point.xInches,
      yInches: sum.yInches + point.yInches,
    }),
    { xInches: 0, yInches: 0 },
  );

  return {
    xInches: total.xInches / points.length,
    yInches: total.yInches / points.length,
  };
}

function getPolygonCentroid(points: readonly Point2DInches[]): Point2DInches | null {
  if (points.length < 3) {
    return getAveragePoint2DInches(points);
  }

  let signedArea = 0;
  let centroidX = 0;
  let centroidY = 0;

  points.forEach((point, index) => {
    const nextPoint2DInches = points[(index + 1) % points.length];
    const cross = point.xInches * nextPoint2DInches.yInches - nextPoint2DInches.xInches * point.yInches;

    signedArea += cross;
    centroidX += (point.xInches + nextPoint2DInches.xInches) * cross;
    centroidY += (point.yInches + nextPoint2DInches.yInches) * cross;
  });

  if (Math.abs(signedArea) < THICK_WALL_LINE_INTERSECTION_EPSILON) {
    return getAveragePoint2DInches(points);
  }

  const area = signedArea / 2;

  return {
    xInches: centroidX / (6 * area),
    yInches: centroidY / (6 * area),
  };
}

function getJointCornerPoints(joint: ThickWallResolvedJoint) {
  const cornerPoints: Point2DInches[] = [];

  joint.cornerByConnectionKey.forEach((pair) => {
    cornerPoints.push(pair.left, pair.right);
  });

  return getUniquePoints(cornerPoints);
}

export function getThickWallJointFillPolygons(
  chains: readonly PlacedThickWallChain[],
): readonly ThickWallJointFillPolygon[] {
  return [...getResolvedJointMap(chains).entries()]
    .map(([pointKey, joint]) => {
      if (!joint.fillPolygon) {
        return null;
      }

      return {
        id: pointKey,
        floorPlan: {
          polygonInches: joint.fillPolygon,
        },
      };
    })
    .filter((item): item is ThickWallJointFillPolygon => Boolean(item));
}

export function getThickWallSnapMarkerPoint2DInches(
  snapPointInches: { point: Point2DInches },
  chains: readonly PlacedThickWallChain[],
): Point2DInches {
  const joint = getResolvedJointMap(chains).get(getThickWallPointKey(snapPointInches.point));

  if (!joint) {
    return snapPointInches.point;
  }

  if (joint.fillPolygon) {
    return getPolygonCentroid(joint.fillPolygon) ?? snapPointInches.point;
  }

  return getAveragePoint2DInches(getJointCornerPoints(joint)) ?? snapPointInches.point;
}

export function getThickWallResolvedCenterlineJointPoint2DInches(
  point: Point2DInches,
  chains: readonly PlacedThickWallChain[],
): Point2DInches {
  return getResolvedJointMap(chains).get(getThickWallPointKey(point))?.point ?? point;
}
