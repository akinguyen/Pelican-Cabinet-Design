import type { Point2DInches } from "@/shared/types/geometryTypes";

export function getPolygonPointsAttribute(points: readonly Point2DInches[]) {
  return points.map((point) => `${point.xInches},${point.yInches}`).join(" ");
}
