import {
  FULL_CIRCLE_DEGREES,
  RIGHT_ANGLE_DEGREES,
  STRAIGHT_ANGLE_DEGREES,
  distanceBetweenPoints,
  getAngleDegrees,
  getUnitVector,
  normalizeDegrees,
  projectPointOntoSegment,
} from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { CandidateThickWallSegment, PlacedThickWallChain, ThickWallPlacementSide } from "@/domains/walls/model/wallTypes";
import {
  THICK_WALL_LINE_INTERSECTION_EPSILON,
  areThickWallPointsEqual,
} from "./thickWallJointGeometry";

export type ThickWallReferenceAxis = "horizontal" | "vertical";

export type AxisSnapResult = Readonly<{
  point: Point2DInches;
  snappedAxis: ThickWallReferenceAxis | null;
}>;

export type ThickWallAngleGuide = Readonly<{
  smallerAngle: number;
  largerAngle: number;
  isHorizontal: boolean;
  isVertical: boolean;
  isBelowHorizontal: boolean;
}>;

const THICK_WALL_COLLINEAR_OVERLAP_DOT_THRESHOLD = Math.cos((3 * Math.PI) / 180);

function getDotProduct(first: Point2DInches, second: Point2DInches) {
  return first.xInches * second.xInches + first.yInches * second.yInches;
}

function isThickWallPathPoint2DInchesConnectedToSegment(
  point: Point2DInches,
  segmentStart: Point2DInches,
  segmentEnd: Point2DInches,
): Point2DInches | null {
  if (areThickWallPointsEqual(point, segmentStart)) {
    return segmentEnd;
  }

  if (areThickWallPointsEqual(point, segmentEnd)) {
    return segmentStart;
  }

  return null;
}

function isSameDirectionCollinearFromOrigin(
  origin: Point2DInches,
  firstPoint2DInches: Point2DInches,
  secondPoint2DInches: Point2DInches,
) {
  const firstLength = distanceBetweenPoints(origin, firstPoint2DInches);
  const secondLength = distanceBetweenPoints(origin, secondPoint2DInches);

  if (firstLength <= THICK_WALL_LINE_INTERSECTION_EPSILON || secondLength <= THICK_WALL_LINE_INTERSECTION_EPSILON) {
    return false;
  }

  const firstDirection = getUnitVector(origin, firstPoint2DInches);
  const secondDirection = getUnitVector(origin, secondPoint2DInches);

  return getDotProduct(firstDirection, secondDirection) >= THICK_WALL_COLLINEAR_OVERLAP_DOT_THRESHOLD;
}

function shouldInsertThickWallFloorPlanCandidateJunctionPoint2DInches(
  point: Point2DInches,
  segmentStart: Point2DInches,
  segmentEnd: Point2DInches,
) {
  const projectedPoint2DInches = projectPointOntoSegment(point, segmentStart, segmentEnd).pointInches;

  return (
    distanceBetweenPoints(point, projectedPoint2DInches) <= THICK_WALL_LINE_INTERSECTION_EPSILON &&
    distanceBetweenPoints(point, segmentStart) > THICK_WALL_LINE_INTERSECTION_EPSILON &&
    distanceBetweenPoints(point, segmentEnd) > THICK_WALL_LINE_INTERSECTION_EPSILON
  );
}

function getThickWallSegmentPlacementSide(
  chain: PlacedThickWallChain,
  segmentIndex: number,
): ThickWallPlacementSide {
  return chain.segmentPlacementSides[segmentIndex] ?? "interior";
}

function insertThickWallFloorPlanCandidateJunctionPoint2DInches(
  chain: PlacedThickWallChain,
  point: Point2DInches,
): PlacedThickWallChain {
  const candidatePoints: Point2DInches[] = [];
  const candidatePlacementSides: Record<number, ThickWallPlacementSide> = {};
  let nextSegmentIndex = 0;
  let inserted = false;

  chain.floorPlan.centerlinePointsInches.slice(0, -1).forEach((start, segmentIndex) => {
    const end = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
    const placementSide = getThickWallSegmentPlacementSide(chain, segmentIndex);

    candidatePoints.push(start);

    if (!inserted && shouldInsertThickWallFloorPlanCandidateJunctionPoint2DInches(point, start, end)) {
      candidatePoints.push(point);
      candidatePlacementSides[nextSegmentIndex] = placementSide;
      nextSegmentIndex += 1;
      candidatePlacementSides[nextSegmentIndex] = placementSide;
      nextSegmentIndex += 1;
      inserted = true;
      return;
    }

    candidatePlacementSides[nextSegmentIndex] = placementSide;
    nextSegmentIndex += 1;
  });

  candidatePoints.push(chain.floorPlan.centerlinePointsInches[chain.floorPlan.centerlinePointsInches.length - 1]);

  if (!inserted) {
    return chain;
  }

  return {
    ...chain,
    floorPlan: {
      ...chain.floorPlan,
      centerlinePointsInches: candidatePoints,
    },
    segmentPlacementSides: candidatePlacementSides,
  };
}

export function getThickWallFloorPlanCandidateChains({
  candidateThickWallSegment,
  chains,
}: Readonly<{
  candidateThickWallSegment: CandidateThickWallSegment | null;
  chains: readonly PlacedThickWallChain[];
}>): readonly PlacedThickWallChain[] {
  if (!candidateThickWallSegment?.chainId) {
    return chains;
  }

  const activeChain = chains.find(
    (chain) => chain.id === candidateThickWallSegment.chainId,
  );

  if (!activeChain) {
    return chains;
  }

  const candidateEndPointInches = candidateThickWallSegment.floorPlan.endPointInches;
  const lastPoint2DInches = activeChain.floorPlan.centerlinePointsInches[activeChain.floorPlan.centerlinePointsInches.length - 1];

  if (!lastPoint2DInches || areThickWallPointsEqual(lastPoint2DInches, candidateEndPointInches)) {
    return chains;
  }

  const chainsWithCandidateJunction = chains.map((chain) =>
    insertThickWallFloorPlanCandidateJunctionPoint2DInches(chain, candidateEndPointInches),
  );

  return chainsWithCandidateJunction.map((chain) => {
    if (chain.id !== candidateThickWallSegment.chainId) {
      return chain;
    }

    return {
      ...chain,
      floorPlan: {
        ...chain.floorPlan,
        centerlinePointsInches: [...chain.floorPlan.centerlinePointsInches, candidateEndPointInches],
      },
      segmentPlacementSides: {
        ...chain.segmentPlacementSides,
        [chain.floorPlan.centerlinePointsInches.length - 1]: candidateThickWallSegment.placementSide,
      },
    };
  });
}

export function snapPointInchesToHorizontalOrVerticalAxis(
  point: Point2DInches,
  origin: Point2DInches,
  threshold: number,
): AxisSnapResult {
  const xDistance = Math.abs(point.xInches - origin.xInches);
  const yDistance = Math.abs(point.yInches - origin.yInches);

  if (xDistance > threshold && yDistance > threshold) {
    return { point, snappedAxis: null };
  }

  if (xDistance <= yDistance) {
    return {
      point: {
        xInches: origin.xInches,
        yInches: point.yInches,
      },
      snappedAxis: "vertical",
    };
  }

  return {
    point: {
      xInches: point.xInches,
      yInches: origin.yInches,
    },
    snappedAxis: "horizontal",
  };
}

export function getThickWallAngleGuide(start: Point2DInches, end: Point2DInches): ThickWallAngleGuide {
  const angle = normalizeDegrees(getAngleDegrees(start, end));
  const distanceFromHorizontal =
    angle > STRAIGHT_ANGLE_DEGREES ? FULL_CIRCLE_DEGREES - angle : angle;
  const smallerAngle = Math.min(
    distanceFromHorizontal,
    STRAIGHT_ANGLE_DEGREES - distanceFromHorizontal,
  );
  const roundedSmallerAngle = Math.round(smallerAngle);
  const isHorizontal =
    roundedSmallerAngle === 0 || roundedSmallerAngle === STRAIGHT_ANGLE_DEGREES;
  const isVertical = roundedSmallerAngle === RIGHT_ANGLE_DEGREES;

  if (isHorizontal) {
    return {
      smallerAngle: STRAIGHT_ANGLE_DEGREES,
      largerAngle: STRAIGHT_ANGLE_DEGREES,
      isHorizontal: true,
      isVertical: false,
      isBelowHorizontal: end.yInches > start.yInches,
    };
  }

  return {
    smallerAngle: roundedSmallerAngle,
    largerAngle: STRAIGHT_ANGLE_DEGREES - roundedSmallerAngle,
    isHorizontal: false,
    isVertical,
    isBelowHorizontal: end.yInches > start.yInches,
  };
}

export function isThickWallFloorPlanCandidateOverlappingConnectedCollinearSegment({
  chains,
  candidatePoint2DInches,
  origin,
}: Readonly<{
  chains: readonly PlacedThickWallChain[];
  candidatePoint2DInches: Point2DInches;
  origin: Point2DInches;
}>) {
  if (areThickWallPointsEqual(origin, candidatePoint2DInches)) {
    return false;
  }

  return chains.some((chain) =>
    chain.floorPlan.centerlinePointsInches.slice(0, -1).some((segmentStart, segmentIndex) => {
      const segmentEnd = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
      const connectedSegmentOtherPoint2DInches = isThickWallPathPoint2DInchesConnectedToSegment(
        origin,
        segmentStart,
        segmentEnd,
      );

      if (!connectedSegmentOtherPoint2DInches) {
        return false;
      }

      return isSameDirectionCollinearFromOrigin(origin, candidatePoint2DInches, connectedSegmentOtherPoint2DInches);
    }),
  );
}
