import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { ThinWallSnapPoint } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanSegmentGeometry";

type ThinWallFloorPlanEndpointMarkersProps = Readonly<{
  points: readonly ThinWallSnapPoint[];
  isSelectedPoint2DInches: (point: Point2DInches) => boolean;
}>;

function ThinWallEndpointMarker({ point, selected }: Readonly<{ point: Point2DInches; selected: boolean }>) {
  return (
    <circle
      cx={point.xInches}
      cy={point.yInches}
      r={8}
      fill={selected ? "white" : "#fecaca"}
      stroke={selected ? "#0ea5e9" : "#fb7185"}
      strokeWidth={selected ? 4 : 3}
    />
  );
}

export function ThinWallFloorPlanEndpointMarkers({ points, isSelectedPoint2DInches }: ThinWallFloorPlanEndpointMarkersProps) {
  if (points.length === 0) {
    return null;
  }

  return (
    <g pointerEvents="none">
      {points.map((snapPointInches) => (
        <ThinWallEndpointMarker
          key={`endpoint-${snapPointInches.chainId}-${snapPointInches.pointIndex}`}
          point={snapPointInches.point}
          selected={isSelectedPoint2DInches(snapPointInches.point)}
        />
      ))}
    </g>
  );
}
