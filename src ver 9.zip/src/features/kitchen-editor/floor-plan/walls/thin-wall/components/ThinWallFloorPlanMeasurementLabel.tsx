import {
  distanceBetweenPoints,
  getAngleDegrees,
  getReadableTextAngleDegrees,
  getSegmentMidpoint,
} from "@/shared/math/geometry";
import { formatLengthFromInches, type MeasurementUnit } from "@/shared/units/length";
import type { Point2DInches } from "@/shared/types/geometryTypes";

type ThinWallFloorPlanMeasurementLabelProps = Readonly<{
  start: Point2DInches;
  end: Point2DInches;
  unit: MeasurementUnit;
  offset?: number;
  side?: -1 | 1;
}>;

function getPerpendicularOffset(start: Point2DInches, end: Point2DInches, offset: number, side: -1 | 1): Point2DInches {
  const length = distanceBetweenPoints(start, end);

  if (length === 0) {
    return { xInches: 0, yInches: 0 };
  }

  return {
    xInches: (-(end.yInches - start.yInches) / length) * offset * side,
    yInches: ((end.xInches - start.xInches) / length) * offset * side,
  };
}

export function ThinWallFloorPlanMeasurementLabel({
  start,
  end,
  unit,
  offset = 14,
  side = -1,
}: ThinWallFloorPlanMeasurementLabelProps) {
  const midpoint = getSegmentMidpoint(start, end);
  const labelOffset = getPerpendicularOffset(start, end, offset, side);
  const labelPoint2DInches = {
    xInches: midpoint.xInches + labelOffset.xInches,
    yInches: midpoint.yInches + labelOffset.yInches,
  };
  const angle = getReadableTextAngleDegrees(getAngleDegrees(start, end));
  const label = formatLengthFromInches(distanceBetweenPoints(start, end), unit);

  return (
    <text
      x={labelPoint2DInches.xInches}
      y={labelPoint2DInches.yInches}
      textAnchor="middle"
      dominantBaseline="middle"
      transform={`rotate(${angle} ${labelPoint2DInches.xInches} ${labelPoint2DInches.yInches})`}
      className="fill-slate-950 text-[14px] font-bold"
      paintOrder="stroke"
      stroke="white"
      strokeWidth={4}
      strokeLinejoin="round"
    >
      {label}
    </text>
  );
}
