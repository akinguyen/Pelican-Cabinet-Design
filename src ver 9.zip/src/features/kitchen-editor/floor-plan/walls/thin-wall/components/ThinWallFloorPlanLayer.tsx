import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { MeasurementUnit } from "@/shared/units/length";
import type { PlacedThinWallChain } from "@/domains/walls/model/wallTypes";
import type { ThinWallSegmentSelection } from "@/features/kitchen-editor/state/designStoreTypes";
import { getThinWallSnapPoints } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanSegmentGeometry";
import type { ThinWallFloorPlanSegmentRenderState } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/model/thinWallTypes";
import { ThinWallFloorPlanEndpointMarkers } from "./ThinWallFloorPlanEndpointMarkers";
import { ThinWallFloorPlanJoinPointMarkers } from "./ThinWallFloorPlanJoinPointMarkers";
import { ThinWallFloorPlanSegmentRenderer } from "./ThinWallFloorPlanSegmentRenderer";

type ThinWallFloorPlanLayerProps = Readonly<{
  chains: readonly PlacedThinWallChain[];
  selectedSegment: ThinWallSegmentSelection | null;
  measurementUnit: MeasurementUnit;
  hiddenTerminalEndpoint?: Point2DInches | null;
}>;

type ThinWallFloorPlanSegmentRenderItem = Readonly<{
  renderKey: string;
  chain: PlacedThinWallChain;
  chainId: string;
  segmentIndex: number;
  floorPlan: Readonly<{
    startPointInches: Point2DInches;
    endPointInches: Point2DInches;
  }>;
  renderState: ThinWallFloorPlanSegmentRenderState;
}>;

function isSamePoint2DInches(first: Point2DInches, second: Point2DInches) {
  return first.xInches === second.xInches && first.yInches === second.yInches;
}

function doesSelectionMatchThinWallSegment(
  segmentRenderItem: ThinWallFloorPlanSegmentRenderItem,
  selectedSegment: ThinWallSegmentSelection | null,
) {
  return (
    selectedSegment?.chainId === segmentRenderItem.chainId &&
    selectedSegment.segmentIndex === segmentRenderItem.segmentIndex
  );
}

function getThinWallFloorPlanSegmentRenderItems({
  chains,
  selectedSegment,
}: Readonly<{
  chains: readonly PlacedThinWallChain[];
  selectedSegment: ThinWallSegmentSelection | null;
}>): readonly ThinWallFloorPlanSegmentRenderItem[] {
  return chains.flatMap((chain) =>
    chain.floorPlan.centerlinePointsInches.slice(0, -1).map(
      (startPointInches, segmentIndex): ThinWallFloorPlanSegmentRenderItem => {
        const segmentRenderItem = {
          renderKey: `${chain.id}-segment-${segmentIndex}`,
          chain,
          chainId: chain.id,
          segmentIndex,
          floorPlan: {
            startPointInches,
            endPointInches: chain.floorPlan.centerlinePointsInches[segmentIndex + 1],
          },
          renderState: "default" as ThinWallFloorPlanSegmentRenderState,
        };

        return {
          ...segmentRenderItem,
          renderState: doesSelectionMatchThinWallSegment(
            segmentRenderItem,
            selectedSegment,
          )
            ? "selected"
            : "default",
        };
      },
    ),
  );
}

function isSelectedSegmentPoint2DInches(
  point: Point2DInches,
  chains: readonly PlacedThinWallChain[],
  selectedSegment: ThinWallSegmentSelection | null,
) {
  if (!selectedSegment) {
    return false;
  }

  const selectedChain = chains.find((chain) => chain.id === selectedSegment.chainId);

  if (!selectedChain) {
    return false;
  }

  const startPoint2DInches = selectedChain.floorPlan.centerlinePointsInches[selectedSegment.segmentIndex];
  const endPoint2DInches = selectedChain.floorPlan.centerlinePointsInches[selectedSegment.segmentIndex + 1];

  return Boolean(
    (startPoint2DInches && isSamePoint2DInches(startPoint2DInches, point)) ||
      (endPoint2DInches && isSamePoint2DInches(endPoint2DInches, point)),
  );
}

export function ThinWallFloorPlanLayer({
  chains,
  hiddenTerminalEndpoint = null,
  selectedSegment,
  measurementUnit,
}: ThinWallFloorPlanLayerProps) {
  const snapPointsInches = getThinWallSnapPoints(chains);
  const joinPoints = snapPointsInches.filter((point) => point.kind === "joint");
  const endpointPoints = snapPointsInches.filter(
    (point) =>
      point.kind === "endpoint" &&
      !(hiddenTerminalEndpoint && isSamePoint2DInches(point.point, hiddenTerminalEndpoint)),
  );
  const isSelectedPoint2DInches = (point: Point2DInches) => isSelectedSegmentPoint2DInches(point, chains, selectedSegment);
  const segmentRenderItems = getThinWallFloorPlanSegmentRenderItems({
    chains,
    selectedSegment,
  });

  return (
    <g>
      {segmentRenderItems.map((segmentRenderItem) => (
        <ThinWallFloorPlanSegmentRenderer
          key={segmentRenderItem.renderKey}
          start={segmentRenderItem.floorPlan.startPointInches}
          end={segmentRenderItem.floorPlan.endPointInches}
          measurementUnit={measurementUnit}
          renderState={segmentRenderItem.renderState}
        />
      ))}

      <ThinWallFloorPlanJoinPointMarkers points={joinPoints} isSelectedPoint2DInches={isSelectedPoint2DInches} />
      <ThinWallFloorPlanEndpointMarkers points={endpointPoints} isSelectedPoint2DInches={isSelectedPoint2DInches} />
    </g>
  );
}
