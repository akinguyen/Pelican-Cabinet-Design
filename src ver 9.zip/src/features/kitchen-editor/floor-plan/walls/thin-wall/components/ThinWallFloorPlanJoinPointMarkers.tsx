import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { ThinWallSnapPoint } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanSegmentGeometry";

type ThinWallFloorPlanJoinPointMarkersProps = Readonly<{
  points: readonly ThinWallSnapPoint[];
  isSelectedPoint2DInches: (point: Point2DInches) => boolean;
}>;

function ThinWallJoinPointMarker({ point, selected }: Readonly<{ point: Point2DInches; selected: boolean }>) {
  if (selected) {
    return <circle cx={point.xInches} cy={point.yInches} r={8} fill="white" stroke="#0ea5e9" strokeWidth={4} />;
  }

  return <circle cx={point.xInches} cy={point.yInches} r={4} fill="#38bdf8" />;
}

export function ThinWallFloorPlanJoinPointMarkers({ points, isSelectedPoint2DInches }: ThinWallFloorPlanJoinPointMarkersProps) {
  if (points.length === 0) {
    return null;
  }

  return (
    <g pointerEvents="none">
      {points.map((snapPointInches) => (
        <ThinWallJoinPointMarker
          key={`joint-${snapPointInches.chainId}-${snapPointInches.pointIndex}`}
          point={snapPointInches.point}
          selected={isSelectedPoint2DInches(snapPointInches.point)}
        />
      ))}
    </g>
  );
}
