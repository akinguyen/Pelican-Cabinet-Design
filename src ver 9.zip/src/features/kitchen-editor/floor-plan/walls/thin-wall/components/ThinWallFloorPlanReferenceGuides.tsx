import type { Point2DInches, Size2DInches } from "@/shared/types/geometryTypes";
import type { ThinWallConstructedReferenceGuide } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanSnapping";
import {
  WallFloorPlanReferenceGuides,
  type WallFloorPlanReferenceGuideStyle,
} from "@/features/kitchen-editor/floor-plan/walls/components/WallFloorPlanReferenceGuides";

type ThinWallFloorPlanReferenceGuidesProps = Readonly<{
  constructedReferenceGuide: ThinWallConstructedReferenceGuide | null;
  originInches: Point2DInches | null;
  floorPlanSizeInches: Size2DInches;
}>;

const THIN_WALL_REFERENCE_GUIDE_STYLE: WallFloorPlanReferenceGuideStyle = {
  guideStroke: "#ff6b6b",
  guideStrokeWidthInches: 2,
  segmentGuideStrokeWidthInches: 2.5,
  originMarkerRadiusInches: 8,
  originMarkerFill: "white",
  originMarkerStroke: "#0ea5e9",
  originMarkerStrokeWidthInches: 3,
};

export function ThinWallFloorPlanReferenceGuides({
  constructedReferenceGuide,
  originInches,
  floorPlanSizeInches,
}: ThinWallFloorPlanReferenceGuidesProps) {
  return (
    <WallFloorPlanReferenceGuides
      floorPlanSizeInches={floorPlanSizeInches}
      horizontalGuideYInches={
        constructedReferenceGuide?.horizontalGuide.referencePointInches.yInches ??
        originInches?.yInches ??
        null
      }
      originInches={originInches}
      segmentGuide={constructedReferenceGuide?.segmentGuide ?? null}
      style={THIN_WALL_REFERENCE_GUIDE_STYLE}
      verticalGuideXInches={
        constructedReferenceGuide?.verticalGuide?.referencePointInches.xInches ?? null
      }
    />
  );
}
