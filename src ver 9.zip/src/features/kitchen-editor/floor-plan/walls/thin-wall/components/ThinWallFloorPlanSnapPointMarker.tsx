import type { Point2DInches } from "@/shared/types/geometryTypes";
import { getThinWallSnapMarkerPoint2DInches, type ThinWallSnapPoint } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanSegmentGeometry";

type ThinWallFloorPlanSnapPointMarkerProps = Readonly<{
  snapPointInches: ThinWallSnapPoint | null;
  markerPointInches?: Point2DInches | null;
}>;

export function ThinWallFloorPlanSnapPointMarker({
  snapPointInches,
  markerPointInches,
}: ThinWallFloorPlanSnapPointMarkerProps) {
  const point = markerPointInches ?? (snapPointInches ? getThinWallSnapMarkerPoint2DInches(snapPointInches) : null);

  if (!point) {
    return null;
  }

  return (
    <g pointerEvents="none">
      <circle cx={point.xInches} cy={point.yInches} r={14} fill="#38bdf8" stroke="white" strokeWidth={3} />
      <line
        x1={point.xInches - 7}
        y1={point.yInches}
        x2={point.xInches + 7}
        y2={point.yInches}
        stroke="white"
        strokeWidth={4}
        strokeLinecap="round"
      />
      <line
        x1={point.xInches}
        y1={point.yInches - 7}
        x2={point.xInches}
        y2={point.yInches + 7}
        stroke="white"
        strokeWidth={4}
        strokeLinecap="round"
      />
    </g>
  );
}
