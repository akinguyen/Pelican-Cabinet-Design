import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { MeasurementUnit } from "@/shared/units/length";
import type { ThinWallFloorPlanSegmentRenderState } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/model/thinWallTypes";
import { ThinWallFloorPlanMeasurementLabel } from "./ThinWallFloorPlanMeasurementLabel";

type ThinWallFloorPlanSegmentRendererProps = Readonly<{
  start: Point2DInches;
  end: Point2DInches;
  measurementUnit: MeasurementUnit;
  renderState: ThinWallFloorPlanSegmentRenderState;
}>;

export function ThinWallFloorPlanSegmentRenderer({
  start,
  end,
  measurementUnit,
  renderState,
}: ThinWallFloorPlanSegmentRendererProps) {
  const isSelected = renderState === "selected";

  return (
    <g pointerEvents="none">
      <line
        x1={start.xInches}
        y1={start.yInches}
        x2={end.xInches}
        y2={end.yInches}
        stroke={isSelected ? "#06b6d4" : "#64748b"}
        strokeWidth={isSelected ? 4 : 2}
        strokeLinecap="round"
      />
      <ThinWallFloorPlanMeasurementLabel start={start} end={end} unit={measurementUnit} />
    </g>
  );
}
