import { distanceBetweenPoints } from "@/shared/math/geometry";
import { getThinWallAngleGuide } from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanCandidateGeometry";
import {
  getWallFloorPlanCandidateMeasurementLabelSide,
  WallFloorPlanCandidateAngleGuides,
} from "@/features/kitchen-editor/floor-plan/walls/components/WallFloorPlanCandidateAngleGuides";
import type { MeasurementUnit } from "@/shared/units/length";
import type { CandidateThinWallSegment } from "@/domains/walls/model/wallTypes";
import { ThinWallFloorPlanMeasurementLabel } from "./ThinWallFloorPlanMeasurementLabel";

type ThinWallFloorPlanCandidateLayerProps = Readonly<{
  candidateThinWallSegment: CandidateThinWallSegment | null;
  measurementUnit: MeasurementUnit;
}>;

export function ThinWallFloorPlanCandidateLayer({
  candidateThinWallSegment,
  measurementUnit,
}: ThinWallFloorPlanCandidateLayerProps) {
  if (!candidateThinWallSegment) {
    return null;
  }

  const origin = candidateThinWallSegment.floorPlan.startPointInches;
  const candidatePointInches = candidateThinWallSegment.floorPlan.endPointInches;

  if (distanceBetweenPoints(origin, candidatePointInches) < 1) {
    return null;
  }

  const angleGuide = getThinWallAngleGuide(origin, candidatePointInches);
  const measurementSide = getWallFloorPlanCandidateMeasurementLabelSide({
    angleGuide,
    candidatePoint2DInches: candidatePointInches,
    origin,
  });

  return (
    <g pointerEvents="none">
      <WallFloorPlanCandidateAngleGuides
        angleGuide={angleGuide}
        origin={origin}
        candidatePoint2DInches={candidatePointInches}
      />
      <line
        x1={origin.xInches}
        y1={origin.yInches}
        x2={candidatePointInches.xInches}
        y2={candidatePointInches.yInches}
        stroke="#0ea5e9"
        strokeWidth={3}
      />
      <ThinWallFloorPlanMeasurementLabel
        start={origin}
        end={candidatePointInches}
        unit={measurementUnit}
        side={measurementSide}
        offset={16}
      />
      <circle
        cx={candidatePointInches.xInches}
        cy={candidatePointInches.yInches}
        r={8}
        fill="white"
        stroke="#0ea5e9"
        strokeWidth={3}
      />
    </g>
  );
}
