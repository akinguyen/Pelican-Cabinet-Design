import { distanceBetweenPoints } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThinWallChain } from "@/domains/walls/model/wallTypes";
import {
  THIN_WALL_LINE_INTERSECTION_EPSILON,
  areThinWallPointsEqual,
  getProjectedPoint2DInchesOnThinWallSegment,
  getThinWallSnapMarkerPoint2DInches,
  getThinWallSnapPoints,
  type ThinWallSegmentSnapPoint,
  type ThinWallSnapPoint,
} from "./thinWallFloorPlanSegmentGeometry";

export type ThinWallCatalogStartSnapTarget = Readonly<
  | {
      kind: "thin-wall-catalog-start-path-point";
      markerPointInches: Point2DInches;
      placementPointInches: Point2DInches;
      snapPointInches: ThinWallSnapPoint;
    }
  | {
      kind: "thin-wall-catalog-start-segment-point";
      markerPointInches: Point2DInches;
      placementPointInches: Point2DInches;
      segmentSnapPoint: ThinWallSegmentSnapPoint;
    }
>;

export type ThinWallReferenceAxis = "horizontal" | "vertical";

export type ThinWallAxisSnapGuide = Readonly<{
  axis: ThinWallReferenceAxis;
  referencePointInches: Point2DInches;
  isSnapping: boolean;
}>;

export type ThinWallConstructedReferenceGuide = Readonly<{
  horizontalGuide: ThinWallAxisSnapGuide;
  verticalGuide: ThinWallAxisSnapGuide | null;
  segmentGuide: ThinWallSegmentSnapPoint | null;
}>;

export type ThinWallSnapCrossPoint = Readonly<{
  point: Point2DInches;
  source:
    | "horizontal-vertical-snap-cross"
    | "vertical-segment-snap-cross"
    | "horizontal-segment-snap-cross";
}>;

type ThinWallAxisAlignmentCandidate = Readonly<{
  axis: ThinWallReferenceAxis;
  distance: number;
  referencePointInches: Point2DInches;
}>;

export function getNearestThinWallSnapPoint(
  point: Point2DInches,
  chains: readonly PlacedThinWallChain[],
  snapThreshold: number,
): ThinWallSnapPoint | null {
  let closestSnapPoint: ThinWallSnapPoint | null = null;
  let closestDistance = snapThreshold;

  getThinWallSnapPoints(chains).forEach((snapPointInches) => {
    const distance = Math.hypot(point.xInches - snapPointInches.point.xInches, point.yInches - snapPointInches.point.yInches);

    if (distance <= closestDistance) {
      closestDistance = distance;
      closestSnapPoint = snapPointInches;
    }
  });

  return closestSnapPoint;
}

export function getNearestThinWallSegmentSnapPoint(
  point: Point2DInches,
  chains: readonly PlacedThinWallChain[],
  snapThreshold: number,
  excludedPoint2DInches: Point2DInches | null,
): ThinWallSegmentSnapPoint | null {
  let closestSnapPoint: ThinWallSegmentSnapPoint | null = null;
  let closestDistance = snapThreshold;

  chains.forEach((chain) => {
    chain.floorPlan.centerlinePointsInches.slice(0, -1).forEach((segmentStart, segmentIndex) => {
      const segmentEnd = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
      const projectedPoint2DInches = getProjectedPoint2DInchesOnThinWallSegment(point, segmentStart, segmentEnd);
      const distance = distanceBetweenPoints(point, projectedPoint2DInches);

      if (distance > closestDistance) {
        return;
      }

      if (
        excludedPoint2DInches &&
        (areThinWallPointsEqual(projectedPoint2DInches, excludedPoint2DInches) ||
          areThinWallPointsEqual(segmentStart, excludedPoint2DInches) ||
          areThinWallPointsEqual(segmentEnd, excludedPoint2DInches))
      ) {
        return;
      }

      closestDistance = distance;
      closestSnapPoint = {
        kind: "thin-wall-segment-centerline",
        chainId: chain.id,
        segmentIndex,
        point: projectedPoint2DInches,
        segmentStart,
        segmentEnd,
      };
    });
  });

  return closestSnapPoint;
}

export function getNearestThinWallCatalogStartSnapTarget(
  point: Point2DInches,
  chains: readonly PlacedThinWallChain[],
  pathPoint2DInchesSnapThreshold: number,
  segmentSnapThreshold = pathPoint2DInchesSnapThreshold,
): ThinWallCatalogStartSnapTarget | null {
  const nearestSnapPoint = getNearestThinWallSnapPoint(point, chains, pathPoint2DInchesSnapThreshold);

  if (nearestSnapPoint) {
    return {
      kind: "thin-wall-catalog-start-path-point",
      markerPointInches: getThinWallSnapMarkerPoint2DInches(nearestSnapPoint),
      placementPointInches: nearestSnapPoint.point,
      snapPointInches: nearestSnapPoint,
    };
  }

  const nearestSegmentSnapPoint = getNearestThinWallSegmentSnapPoint(
    point,
    chains,
    segmentSnapThreshold,
    null,
  );

  if (!nearestSegmentSnapPoint) {
    return null;
  }

  return {
    kind: "thin-wall-catalog-start-segment-point",
    markerPointInches: nearestSegmentSnapPoint.point,
    placementPointInches: nearestSegmentSnapPoint.point,
    segmentSnapPoint: nearestSegmentSnapPoint,
  };
}

function getNearestThinWallAxisSnapGuides(
  point: Point2DInches,
  chains: readonly PlacedThinWallChain[],
  snapThreshold: number,
  origin: Point2DInches,
): ThinWallConstructedReferenceGuide {
  let closestHorizontalCandidate: ThinWallAxisAlignmentCandidate | null = null;
  let closestVerticalCandidate: ThinWallAxisAlignmentCandidate | null = null;
  const referencePointsInches = [
    origin,
    ...getThinWallSnapPoints(chains)
      .map((snapPointInches) => snapPointInches.point)
      .filter((referencePointInches) => !areThinWallPointsEqual(referencePointInches, origin)),
  ];

  for (const referencePointInches of referencePointsInches) {
    const horizontalDistance = Math.abs(point.yInches - referencePointInches.yInches);
    const verticalDistance = Math.abs(point.xInches - referencePointInches.xInches);

    if (
      horizontalDistance <= snapThreshold &&
      (!closestHorizontalCandidate || horizontalDistance < closestHorizontalCandidate.distance)
    ) {
      closestHorizontalCandidate = {
        axis: "horizontal",
        distance: horizontalDistance,
        referencePointInches,
      };
    }

    if (
      verticalDistance <= snapThreshold &&
      (!closestVerticalCandidate || verticalDistance < closestVerticalCandidate.distance)
    ) {
      closestVerticalCandidate = {
        axis: "vertical",
        distance: verticalDistance,
        referencePointInches,
      };
    }
  }

  return {
    horizontalGuide: {
      axis: "horizontal",
      referencePointInches: closestHorizontalCandidate?.referencePointInches ?? origin,
      isSnapping: Boolean(closestHorizontalCandidate),
    },
    verticalGuide: closestVerticalCandidate
      ? {
          axis: "vertical",
          referencePointInches: closestVerticalCandidate.referencePointInches,
          isSnapping: true,
        }
      : null,
    segmentGuide: null,
  };
}

export function getNearestThinWallConstructedReferenceGuide(
  point: Point2DInches,
  chains: readonly PlacedThinWallChain[],
  snapThreshold: number,
  origin: Point2DInches,
): ThinWallConstructedReferenceGuide {
  return getNearestThinWallAxisSnapGuides(point, chains, snapThreshold, origin);
}

function getIntersectionWithHorizontalLine(
  lineStart: Point2DInches,
  lineEnd: Point2DInches,
  yInches: number,
): Point2DInches | null {
  const dy = lineEnd.yInches - lineStart.yInches;

  if (Math.abs(dy) < THIN_WALL_LINE_INTERSECTION_EPSILON) {
    return null;
  }

  const factor = (yInches - lineStart.yInches) / dy;

  return {
    xInches: lineStart.xInches + (lineEnd.xInches - lineStart.xInches) * factor,
    yInches,
  };
}

function getIntersectionWithVerticalLine(
  lineStart: Point2DInches,
  lineEnd: Point2DInches,
  xInches: number,
): Point2DInches | null {
  const dx = lineEnd.xInches - lineStart.xInches;

  if (Math.abs(dx) < THIN_WALL_LINE_INTERSECTION_EPSILON) {
    return null;
  }

  const factor = (xInches - lineStart.xInches) / dx;

  return {
    xInches,
    yInches: lineStart.yInches + (lineEnd.yInches - lineStart.yInches) * factor,
  };
}

export function getNearestThinWallSnapCrossPoint(
  point: Point2DInches,
  referenceGuide: ThinWallConstructedReferenceGuide,
  snapThreshold: number,
): ThinWallSnapCrossPoint | null {
  const crossPoints: ThinWallSnapCrossPoint[] = [];
  const segmentGuide = referenceGuide.segmentGuide;

  if (referenceGuide.verticalGuide && referenceGuide.horizontalGuide.isSnapping) {
    crossPoints.push({
      point: {
        xInches: referenceGuide.verticalGuide.referencePointInches.xInches,
        yInches: referenceGuide.horizontalGuide.referencePointInches.yInches,
      },
      source: "horizontal-vertical-snap-cross",
    });
  }

  if (segmentGuide && referenceGuide.verticalGuide) {
    const crossPoint2DInches = getIntersectionWithVerticalLine(
      segmentGuide.segmentStart,
      segmentGuide.segmentEnd,
      referenceGuide.verticalGuide.referencePointInches.xInches,
    );

    if (crossPoint2DInches) {
      crossPoints.push({
        point: crossPoint2DInches,
        source: "vertical-segment-snap-cross",
      });
    }
  }

  if (segmentGuide && referenceGuide.horizontalGuide.isSnapping) {
    const crossPoint2DInches = getIntersectionWithHorizontalLine(
      segmentGuide.segmentStart,
      segmentGuide.segmentEnd,
      referenceGuide.horizontalGuide.referencePointInches.yInches,
    );

    if (crossPoint2DInches) {
      crossPoints.push({
        point: crossPoint2DInches,
        source: "horizontal-segment-snap-cross",
      });
    }
  }

  let closestCrossPoint2DInches: ThinWallSnapCrossPoint | null = null;
  let closestDistance = snapThreshold;

  crossPoints.forEach((crossPoint2DInches) => {
    const distance = distanceBetweenPoints(point, crossPoint2DInches.point);

    if (distance <= closestDistance) {
      closestDistance = distance;
      closestCrossPoint2DInches = crossPoint2DInches;
    }
  });

  return closestCrossPoint2DInches;
}

function snapPointInchesToThinWallSegmentLine(
  point: Point2DInches,
  segmentGuide: ThinWallSegmentSnapPoint,
): Point2DInches {
  return getProjectedPoint2DInchesOnThinWallSegment(point, segmentGuide.segmentStart, segmentGuide.segmentEnd);
}

export function snapPointInchesToThinWallConstructedReferenceGuide(
  point: Point2DInches,
  referenceGuide: ThinWallConstructedReferenceGuide,
): Point2DInches {
  if (referenceGuide.segmentGuide && referenceGuide.verticalGuide) {
    const crossPoint2DInches = getIntersectionWithVerticalLine(
      referenceGuide.segmentGuide.segmentStart,
      referenceGuide.segmentGuide.segmentEnd,
      referenceGuide.verticalGuide.referencePointInches.xInches,
    );

    if (crossPoint2DInches) {
      return crossPoint2DInches;
    }
  }

  if (referenceGuide.segmentGuide && referenceGuide.horizontalGuide.isSnapping) {
    const crossPoint2DInches = getIntersectionWithHorizontalLine(
      referenceGuide.segmentGuide.segmentStart,
      referenceGuide.segmentGuide.segmentEnd,
      referenceGuide.horizontalGuide.referencePointInches.yInches,
    );

    if (crossPoint2DInches) {
      return crossPoint2DInches;
    }
  }

  if (referenceGuide.segmentGuide) {
    return snapPointInchesToThinWallSegmentLine(point, referenceGuide.segmentGuide);
  }

  if (referenceGuide.verticalGuide && referenceGuide.horizontalGuide.isSnapping) {
    return {
      xInches: referenceGuide.verticalGuide.referencePointInches.xInches,
      yInches: referenceGuide.horizontalGuide.referencePointInches.yInches,
    };
  }

  if (referenceGuide.verticalGuide) {
    return {
      xInches: referenceGuide.verticalGuide.referencePointInches.xInches,
      yInches: point.yInches,
    };
  }

  if (referenceGuide.horizontalGuide.isSnapping) {
    return {
      xInches: point.xInches,
      yInches: referenceGuide.horizontalGuide.referencePointInches.yInches,
    };
  }

  return point;
}
