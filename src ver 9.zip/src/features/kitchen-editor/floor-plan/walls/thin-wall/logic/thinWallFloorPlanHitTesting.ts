import { getPointToSegmentDistance } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { ThinWallSegmentSelection } from "@/features/kitchen-editor/state/designStoreTypes";
import type { PlacedThinWallChain } from "@/domains/walls/model/wallTypes";

export function getThinWallSegmentAtPoint2DInches(
  point: Point2DInches,
  chains: readonly PlacedThinWallChain[],
  hitThreshold: number,
): ThinWallSegmentSelection | null {
  let closestSelection: ThinWallSegmentSelection | null = null;
  let closestDistance = hitThreshold;

  chains.forEach((chain) => {
    chain.floorPlan.centerlinePointsInches.slice(0, -1).forEach((start, segmentIndex) => {
      const end = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
      const distance = getPointToSegmentDistance(point, start, end);

      if (distance <= closestDistance) {
        closestDistance = distance;
        closestSelection = {
          type: "thin-wall-segment",
          chainId: chain.id,
          segmentIndex,
        };
      }
    });
  });

  return closestSelection;
}
