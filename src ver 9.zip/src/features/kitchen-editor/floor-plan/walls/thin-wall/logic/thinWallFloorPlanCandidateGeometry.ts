import {
  FULL_CIRCLE_DEGREES,
  RIGHT_ANGLE_DEGREES,
  STRAIGHT_ANGLE_DEGREES,
  distanceBetweenPoints,
  getAngleDegrees,
  normalizeDegrees,
} from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThinWallChain } from "@/domains/walls/model/wallTypes";
import {
  THIN_WALL_LINE_INTERSECTION_EPSILON,
  areThinWallPointsEqual,
  getThinWallUnitVector,
} from "./thinWallFloorPlanSegmentGeometry";

export type AxisSnapResult = Readonly<{
  point: Point2DInches;
  snappedAxis: "horizontal" | "vertical" | null;
}>;

export type ThinWallAngleGuide = Readonly<{
  smallerAngle: number;
  largerAngle: number;
  isHorizontal: boolean;
  isVertical: boolean;
  isBelowHorizontal: boolean;
}>;

const THIN_WALL_COLLINEAR_OVERLAP_DOT_THRESHOLD = Math.cos((3 * Math.PI) / 180);

function getDotProduct(first: Point2DInches, second: Point2DInches) {
  return first.xInches * second.xInches + first.yInches * second.yInches;
}

function getConnectedThinWallSegmentOtherPoint2DInches(
  point: Point2DInches,
  segmentStart: Point2DInches,
  segmentEnd: Point2DInches,
): Point2DInches | null {
  if (areThinWallPointsEqual(point, segmentStart)) {
    return segmentEnd;
  }

  if (areThinWallPointsEqual(point, segmentEnd)) {
    return segmentStart;
  }

  return null;
}

function isSameDirectionCollinearFromThinWallOrigin(
  origin: Point2DInches,
  candidatePoint2DInches: Point2DInches,
  connectedSegmentOtherPoint2DInches: Point2DInches,
) {
  const candidateLength = distanceBetweenPoints(origin, candidatePoint2DInches);
  const connectedSegmentLength = distanceBetweenPoints(origin, connectedSegmentOtherPoint2DInches);

  if (candidateLength <= THIN_WALL_LINE_INTERSECTION_EPSILON || connectedSegmentLength <= THIN_WALL_LINE_INTERSECTION_EPSILON) {
    return false;
  }

  const candidateDirection = getThinWallUnitVector(origin, candidatePoint2DInches);
  const connectedDirection = getThinWallUnitVector(origin, connectedSegmentOtherPoint2DInches);

  return getDotProduct(candidateDirection, connectedDirection) >= THIN_WALL_COLLINEAR_OVERLAP_DOT_THRESHOLD;
}

export function snapPointInchesToHorizontalOrVerticalAxis(
  point: Point2DInches,
  origin: Point2DInches,
  threshold: number,
): AxisSnapResult {
  const xDistance = Math.abs(point.xInches - origin.xInches);
  const yDistance = Math.abs(point.yInches - origin.yInches);

  if (xDistance > threshold && yDistance > threshold) {
    return { point, snappedAxis: null };
  }

  if (xDistance <= yDistance) {
    return {
      point: {
        xInches: origin.xInches,
        yInches: point.yInches,
      },
      snappedAxis: "vertical",
    };
  }

  return {
    point: {
      xInches: point.xInches,
      yInches: origin.yInches,
    },
    snappedAxis: "horizontal",
  };
}

export function getThinWallAngleGuide(start: Point2DInches, end: Point2DInches): ThinWallAngleGuide {
  const angle = normalizeDegrees(getAngleDegrees(start, end));
  const distanceFromHorizontal =
    angle > STRAIGHT_ANGLE_DEGREES ? FULL_CIRCLE_DEGREES - angle : angle;
  const smallerAngle = Math.min(
    distanceFromHorizontal,
    STRAIGHT_ANGLE_DEGREES - distanceFromHorizontal,
  );
  const roundedSmallerAngle = Math.round(smallerAngle);
  const isHorizontal =
    roundedSmallerAngle === 0 || roundedSmallerAngle === STRAIGHT_ANGLE_DEGREES;
  const isVertical = roundedSmallerAngle === RIGHT_ANGLE_DEGREES;

  if (isHorizontal) {
    return {
      smallerAngle: STRAIGHT_ANGLE_DEGREES,
      largerAngle: STRAIGHT_ANGLE_DEGREES,
      isHorizontal: true,
      isVertical: false,
      isBelowHorizontal: end.yInches > start.yInches,
    };
  }

  return {
    smallerAngle: roundedSmallerAngle,
    largerAngle: STRAIGHT_ANGLE_DEGREES - roundedSmallerAngle,
    isHorizontal: false,
    isVertical,
    isBelowHorizontal: end.yInches > start.yInches,
  };
}

export function isThinWallFloorPlanCandidateOverlappingConnectedCollinearSegment({
  chains,
  candidatePoint2DInches,
  origin,
}: Readonly<{
  chains: readonly PlacedThinWallChain[];
  candidatePoint2DInches: Point2DInches;
  origin: Point2DInches;
}>) {
  if (areThinWallPointsEqual(origin, candidatePoint2DInches)) {
    return false;
  }

  return chains.some((chain) =>
    chain.floorPlan.centerlinePointsInches.slice(0, -1).some((segmentStart, segmentIndex) => {
      const segmentEnd = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
      const connectedSegmentOtherPoint2DInches = getConnectedThinWallSegmentOtherPoint2DInches(
        origin,
        segmentStart,
        segmentEnd,
      );

      if (!connectedSegmentOtherPoint2DInches) {
        return false;
      }

      return isSameDirectionCollinearFromThinWallOrigin(
        origin,
        candidatePoint2DInches,
        connectedSegmentOtherPoint2DInches,
      );
    }),
  );
}
