import { useMemo, useState } from "react";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import { pixelsToInches } from "@/shared/units/length";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";
import {
  getThinWallSnapMarkerPoint2DInches,
  type ThinWallSegmentSnapPoint,
  type ThinWallSnapPoint,
} from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanSegmentGeometry";
import {
  isThinWallFloorPlanCandidateOverlappingConnectedCollinearSegment,
  snapPointInchesToHorizontalOrVerticalAxis,
} from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanCandidateGeometry";
import {
  getNearestThinWallCatalogStartSnapTarget,
  getNearestThinWallConstructedReferenceGuide,
  getNearestThinWallSegmentSnapPoint,
  getNearestThinWallSnapCrossPoint,
  getNearestThinWallSnapPoint,
  snapPointInchesToThinWallConstructedReferenceGuide,
  type ThinWallCatalogStartSnapTarget,
  type ThinWallConstructedReferenceGuide,
} from "@/features/kitchen-editor/floor-plan/walls/thin-wall/logic/thinWallFloorPlanSnapping";

const AXIS_SNAP_THRESHOLD_PIXELS = 8;
const CHAIN_PATH_POINT_SNAP_THRESHOLD_PIXELS = 6;
const CATALOG_START_PATH_POINT_SNAP_THRESHOLD_PIXELS = 14;
const CROSS_POINT_SNAP_THRESHOLD_PIXELS = 12;
const SEGMENT_SNAP_THRESHOLD_PIXELS = 12;
const CONSTRUCTED_REFERENCE_GUIDE_THRESHOLD_PIXELS = 10;

type UseThinWallDrawingParams = Readonly<{
  floorPlanPixelsPerInch: number;
}>;

type ThinWallDrawablePoint2DInches = Readonly<{
  visualPoint2DInches: Point2DInches;
  logicalPoint2DInches: Point2DInches;
  constructedReferenceGuide: ThinWallConstructedReferenceGuide | null;
  snapPointInches: ThinWallSnapPoint | null;
  segmentSnapPoint: ThinWallSegmentSnapPoint | null;
  catalogStartSnapTarget: ThinWallCatalogStartSnapTarget | null;
}>;

function getCatalogStartMarkerPoint2DInches(
  target: ThinWallCatalogStartSnapTarget | null,
): Point2DInches | null {
  return target?.markerPointInches ?? null;
}

function withSegmentSnapGuide(
  referenceGuide: ThinWallConstructedReferenceGuide,
  segmentSnapPoint: ThinWallSegmentSnapPoint,
): ThinWallConstructedReferenceGuide {
  return {
    ...referenceGuide,
    segmentGuide: segmentSnapPoint,
  };
}

export function useThinWallFloorPlanDrawing({ floorPlanPixelsPerInch }: UseThinWallDrawingParams) {
  const [hoveredSnapPoint, setHoveredSnapPoint] = useState<ThinWallSnapPoint | null>(null);
  const [catalogStartSnapTarget, setCatalogStartSnapTarget] =
    useState<ThinWallCatalogStartSnapTarget | null>(null);
  const [segmentSnapPoint, setSegmentSnapPoint] = useState<ThinWallSegmentSnapPoint | null>(null);
  const [constructedReferenceGuide, setConstructedReferenceGuide] =
    useState<ThinWallConstructedReferenceGuide | null>(null);

  const activeTool = useDesignStore((state) => state.activeTool);
  const placedThinWallChains = useDesignStore((state) => state.placedThinWallChains);
  const candidateThinWallSegment = useDesignStore((state) => state.candidateThinWallSegment);
  const startCandidateThinWallSegment = useDesignStore((state) => state.startCandidateThinWallSegment);
  const updateCandidateThinWallSegment = useDesignStore((state) => state.updateCandidateThinWallSegment);
  const commitCandidateThinWallSegment = useDesignStore((state) => state.commitCandidateThinWallSegment);

  const activeChain = useMemo(
    () =>
      candidateThinWallSegment?.chainId
        ? placedThinWallChains.find((chain) => chain.id === candidateThinWallSegment.chainId) ?? null
        : null,
    [candidateThinWallSegment?.chainId, placedThinWallChains],
  );

  const origin = candidateThinWallSegment?.floorPlan.startPointInches ?? null;
  const candidatePointInches = candidateThinWallSegment?.floorPlan.endPointInches ?? null;
  const isCatalogStart = !candidateThinWallSegment;
  const isDrawingThinWall = activeTool === "draw-thin-wall";

  const getCatalogStartDrawablePoint2DInches = (point: Point2DInches): ThinWallDrawablePoint2DInches => {
    const pathPoint2DInchesSnapThreshold = pixelsToInches(CATALOG_START_PATH_POINT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const segmentSnapThreshold = pixelsToInches(SEGMENT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestCatalogStartSnapTarget = getNearestThinWallCatalogStartSnapTarget(
      point,
      placedThinWallChains,
      pathPoint2DInchesSnapThreshold,
      segmentSnapThreshold,
    );

    if (nearestCatalogStartSnapTarget) {
      return {
        visualPoint2DInches: nearestCatalogStartSnapTarget.markerPointInches,
        logicalPoint2DInches: nearestCatalogStartSnapTarget.placementPointInches,
        constructedReferenceGuide: null,
        snapPointInches:
          nearestCatalogStartSnapTarget.kind === "thin-wall-catalog-start-path-point"
            ? nearestCatalogStartSnapTarget.snapPointInches
            : null,
        segmentSnapPoint:
          nearestCatalogStartSnapTarget.kind === "thin-wall-catalog-start-segment-point"
            ? nearestCatalogStartSnapTarget.segmentSnapPoint
            : null,
        catalogStartSnapTarget: nearestCatalogStartSnapTarget,
      };
    }

    return {
      visualPoint2DInches: point,
      logicalPoint2DInches: point,
      constructedReferenceGuide: null,
      snapPointInches: null,
      segmentSnapPoint: null,
      catalogStartSnapTarget: null,
    };
  };

  const getChainContinuationDrawablePoint2DInches = (point: Point2DInches): ThinWallDrawablePoint2DInches => {
    const pointSnapThreshold = pixelsToInches(CHAIN_PATH_POINT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestSnapPoint = getNearestThinWallSnapPoint(
      point,
      placedThinWallChains,
      pointSnapThreshold,
    );

    if (nearestSnapPoint) {
      return {
        visualPoint2DInches: getThinWallSnapMarkerPoint2DInches(nearestSnapPoint),
        logicalPoint2DInches: nearestSnapPoint.point,
        constructedReferenceGuide: null,
        snapPointInches: nearestSnapPoint,
        segmentSnapPoint: null,
        catalogStartSnapTarget: null,
      };
    }

    if (!origin) {
      return {
        visualPoint2DInches: point,
        logicalPoint2DInches: point,
        constructedReferenceGuide: null,
        snapPointInches: null,
        segmentSnapPoint: null,
        catalogStartSnapTarget: null,
      };
    }

    const referenceGuideSnapThreshold =
      pixelsToInches(CONSTRUCTED_REFERENCE_GUIDE_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestConstructedReferenceGuide = getNearestThinWallConstructedReferenceGuide(
      point,
      placedThinWallChains,
      referenceGuideSnapThreshold,
      origin,
    );

    const segmentSnapThreshold = pixelsToInches(SEGMENT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestSegmentSnapPoint = getNearestThinWallSegmentSnapPoint(
      point,
      placedThinWallChains,
      segmentSnapThreshold,
      origin,
    );

    if (nearestSegmentSnapPoint) {
      const segmentReferenceGuide = withSegmentSnapGuide(
        nearestConstructedReferenceGuide,
        nearestSegmentSnapPoint,
      );
      const crossPoint2DInchesSnapThreshold = pixelsToInches(CROSS_POINT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
      const nearestCrossPoint2DInches = getNearestThinWallSnapCrossPoint(
        point,
        segmentReferenceGuide,
        crossPoint2DInchesSnapThreshold,
      );
      const visualPoint2DInches =
        nearestCrossPoint2DInches?.point ??
        snapPointInchesToThinWallConstructedReferenceGuide(point, segmentReferenceGuide);

      return {
        visualPoint2DInches,
        logicalPoint2DInches: visualPoint2DInches,
        constructedReferenceGuide: segmentReferenceGuide,
        snapPointInches: null,
        segmentSnapPoint: nearestSegmentSnapPoint,
        catalogStartSnapTarget: null,
      };
    }

    const crossPoint2DInchesSnapThreshold = pixelsToInches(CROSS_POINT_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch);
    const nearestCrossPoint2DInches = getNearestThinWallSnapCrossPoint(
      point,
      nearestConstructedReferenceGuide,
      crossPoint2DInchesSnapThreshold,
    );

    if (nearestCrossPoint2DInches) {
      return {
        visualPoint2DInches: nearestCrossPoint2DInches.point,
        logicalPoint2DInches: nearestCrossPoint2DInches.point,
        constructedReferenceGuide: nearestConstructedReferenceGuide,
        snapPointInches: null,
        segmentSnapPoint: null,
        catalogStartSnapTarget: null,
      };
    }

    const snappedReferencePoint2DInches = snapPointInchesToThinWallConstructedReferenceGuide(
      point,
      nearestConstructedReferenceGuide,
    );

    if (
      snappedReferencePoint2DInches.xInches !== point.xInches ||
      snappedReferencePoint2DInches.yInches !== point.yInches ||
      nearestConstructedReferenceGuide.verticalGuide ||
      nearestConstructedReferenceGuide.horizontalGuide.isSnapping
    ) {
      return {
        visualPoint2DInches: snappedReferencePoint2DInches,
        logicalPoint2DInches: snappedReferencePoint2DInches,
        constructedReferenceGuide: nearestConstructedReferenceGuide,
        snapPointInches: null,
        segmentSnapPoint: null,
        catalogStartSnapTarget: null,
      };
    }

    const visualPoint2DInches = snapPointInchesToHorizontalOrVerticalAxis(
      point,
      origin,
      pixelsToInches(AXIS_SNAP_THRESHOLD_PIXELS, floorPlanPixelsPerInch),
    ).point;

    return {
      visualPoint2DInches,
      logicalPoint2DInches: visualPoint2DInches,
      constructedReferenceGuide: nearestConstructedReferenceGuide,
      snapPointInches: null,
      segmentSnapPoint: null,
      catalogStartSnapTarget: null,
    };
  };

  const getDrawablePoint2DInches = (point: Point2DInches): ThinWallDrawablePoint2DInches => {
    if (isCatalogStart) {
      return getCatalogStartDrawablePoint2DInches(point);
    }

    return getChainContinuationDrawablePoint2DInches(point);
  };

  const isOverlappingConnectedCollinearSegment = (point: Point2DInches) =>
    Boolean(
      origin &&
        !isCatalogStart &&
        isThinWallFloorPlanCandidateOverlappingConnectedCollinearSegment({
          chains: placedThinWallChains,
          candidatePoint2DInches: point,
          origin,
        }),
    );

  return {
    activeChain,
    catalogStartMarkerPoint2DInches: getCatalogStartMarkerPoint2DInches(catalogStartSnapTarget),
    constructedReferenceGuide,
    hoveredSnapPoint,
    origin,
    candidateThinWallSegment,
    candidatePoint: candidatePointInches,
    candidatePointInches,
    isCatalogStart,
    isDrawingThinWall,
    segmentSnapPoint,
    placePoint: (point: Point2DInches) => {
      const drawablePoint2DInches = getDrawablePoint2DInches(point);

      if (isOverlappingConnectedCollinearSegment(drawablePoint2DInches.logicalPoint2DInches)) {
        return;
      }

      if (!candidateThinWallSegment) {
        startCandidateThinWallSegment(drawablePoint2DInches.logicalPoint2DInches);
      } else {
        updateCandidateThinWallSegment(drawablePoint2DInches.logicalPoint2DInches);
        commitCandidateThinWallSegment();
      }
      setCatalogStartSnapTarget(null);
      setConstructedReferenceGuide(null);
      setHoveredSnapPoint(null);
      setSegmentSnapPoint(null);
    },
    updateCandidatePoint: (point: Point2DInches | null) => {
      if (!point) {
        setCatalogStartSnapTarget(null);
        setConstructedReferenceGuide(null);
        setHoveredSnapPoint(null);
        setSegmentSnapPoint(null);
        return;
      }

      const drawablePoint2DInches = getDrawablePoint2DInches(point);

      setCatalogStartSnapTarget(drawablePoint2DInches.catalogStartSnapTarget);
      setConstructedReferenceGuide(drawablePoint2DInches.constructedReferenceGuide);
      setHoveredSnapPoint(isCatalogStart ? drawablePoint2DInches.snapPointInches : null);
      setSegmentSnapPoint(drawablePoint2DInches.segmentSnapPoint);
      if (origin && !isOverlappingConnectedCollinearSegment(drawablePoint2DInches.logicalPoint2DInches)) {
        updateCandidateThinWallSegment(drawablePoint2DInches.visualPoint2DInches);
        return;
      }

      if (origin) {
        updateCandidateThinWallSegment(origin);
      }
    },
  };
}
