import { distanceBetweenPoints } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { PlacedThinWallChain } from "@/domains/walls/model/wallTypes";

export type ThinWallEndpoint = Readonly<{
  kind: "endpoint";
  chainId: string;
  pointIndex: number;
  point: Point2DInches;
}>;

export type ThinWallJointPoint2DInches = Readonly<{
  kind: "joint";
  chainId: string;
  pointIndex: number;
  point: Point2DInches;
}>;

export type ThinWallSnapPoint = ThinWallEndpoint | ThinWallJointPoint2DInches;

export type ThinWallSegmentSnapPoint = Readonly<{
  kind: "thin-wall-segment-centerline";
  chainId: string;
  segmentIndex: number;
  point: Point2DInches;
  segmentStart: Point2DInches;
  segmentEnd: Point2DInches;
}>;

type ThinWallPointConnection = Readonly<{
  chainId: string;
  pointIndex: number;
  point: Point2DInches;
  connectedSegmentCount: number;
}>;

export const THIN_WALL_LINE_INTERSECTION_EPSILON = 0.0001;
const POINT_KEY_PRECISION = 1000;

export function getThinWallPointKey(point: Point2DInches) {
  const x = Math.round(point.xInches * POINT_KEY_PRECISION) / POINT_KEY_PRECISION;
  const y = Math.round(point.yInches * POINT_KEY_PRECISION) / POINT_KEY_PRECISION;

  return `${x}:${y}`;
}

export function areThinWallPointsEqual(first: Point2DInches, second: Point2DInches) {
  return getThinWallPointKey(first) === getThinWallPointKey(second);
}

function getThinWallPointConnections(
  chains: readonly PlacedThinWallChain[],
): readonly ThinWallPointConnection[] {
  const connectionMap = new Map<string, ThinWallPointConnection>();

  chains.forEach((chain) => {
    chain.floorPlan.centerlinePointsInches.forEach((point, pointIndex) => {
      const pointKey = getThinWallPointKey(point);
      const currentConnection = connectionMap.get(pointKey);
      const connectedSegmentCount =
        (pointIndex > 0 ? 1 : 0) + (pointIndex < chain.floorPlan.centerlinePointsInches.length - 1 ? 1 : 0);

      if (!currentConnection) {
        connectionMap.set(pointKey, {
          chainId: chain.id,
          pointIndex,
          point,
          connectedSegmentCount,
        });
        return;
      }

      connectionMap.set(pointKey, {
        ...currentConnection,
        connectedSegmentCount: currentConnection.connectedSegmentCount + connectedSegmentCount,
      });
    });
  });

  return [...connectionMap.values()];
}

export function getProjectedPoint2DInchesOnThinWallSegment(
  point: Point2DInches,
  segmentStart: Point2DInches,
  segmentEnd: Point2DInches,
): Point2DInches {
  const segmentX = segmentEnd.xInches - segmentStart.xInches;
  const segmentY = segmentEnd.yInches - segmentStart.yInches;
  const segmentLengthSquared = segmentX * segmentX + segmentY * segmentY;

  if (segmentLengthSquared === 0) {
    return segmentStart;
  }

  const rawProjection =
    ((point.xInches - segmentStart.xInches) * segmentX + (point.yInches - segmentStart.yInches) * segmentY) /
    segmentLengthSquared;
  const clampedProjection = Math.min(Math.max(rawProjection, 0), 1);

  return {
    xInches: segmentStart.xInches + clampedProjection * segmentX,
    yInches: segmentStart.yInches + clampedProjection * segmentY,
  };
}

export function getThinWallSnapPoints(chains: readonly PlacedThinWallChain[]): readonly ThinWallSnapPoint[] {
  return getThinWallPointConnections(chains).map((connection): ThinWallSnapPoint => {
    const baseSnapPoint = {
      chainId: connection.chainId,
      pointIndex: connection.pointIndex,
      point: connection.point,
    };

    if (connection.connectedSegmentCount > 1) {
      return {
        ...baseSnapPoint,
        kind: "joint",
      };
    }

    return {
      ...baseSnapPoint,
      kind: "endpoint",
    };
  });
}

export function getThinWallSnapMarkerPoint2DInches(snapPointInches: ThinWallSnapPoint): Point2DInches {
  return snapPointInches.point;
}

export function getThinWallUnitVector(start: Point2DInches, end: Point2DInches) {
  const length = distanceBetweenPoints(start, end);

  if (length === 0) {
    return { xInches: 0, yInches: 0 };
  }

  return {
    xInches: (end.xInches - start.xInches) / length,
    yInches: (end.yInches - start.yInches) / length,
  };
}
