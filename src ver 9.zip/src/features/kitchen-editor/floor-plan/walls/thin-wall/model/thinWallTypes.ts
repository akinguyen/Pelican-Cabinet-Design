export type ThinWallFloorPlanSegmentRenderState = "default" | "selected";
