import type { PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";
import { BasicUnitFloorPlanRenderer } from "./BasicUnitFloorPlanRenderer";
import { getBasicUnitFloorPlanRenderItems } from "@/features/kitchen-editor/floor-plan/basic-units/logic/basicUnitFloorPlanRenderItems";

type BasicUnitFloorPlanLayerProps = Readonly<{
  placedBasicUnits: readonly PlacedBasicUnit[];
  selectedBasicUnitId: string | null;
}>;

export function BasicUnitFloorPlanLayer({
  placedBasicUnits,
  selectedBasicUnitId,
}: BasicUnitFloorPlanLayerProps) {
  const renderItems = getBasicUnitFloorPlanRenderItems({
    placedBasicUnits,
    selectedBasicUnitId,
  });

  return (
    <g>
      {renderItems.map((renderItem) => (
        <BasicUnitFloorPlanRenderer
          key={renderItem.key}
          basicUnit={renderItem.basicUnit}
          renderState={renderItem.renderState}
        />
      ))}
    </g>
  );
}
