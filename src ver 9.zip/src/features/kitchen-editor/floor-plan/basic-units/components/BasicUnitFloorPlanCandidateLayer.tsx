import type { BasicUnitFloorPlanCandidate } from "@/domains/basic-units/model/basicUnitTypes";
import type { Size2DInches } from "@/shared/types/geometryTypes";
import { BasicUnitFloorPlanRenderer } from "./BasicUnitFloorPlanRenderer";
import { validateBasicUnitFloorPlanPlacement } from "@/features/kitchen-editor/floor-plan/basic-units/logic/basicUnitFloorPlanValidation";

type BasicUnitFloorPlanCandidateLayerProps = Readonly<{
  basicUnitFloorPlanCandidate: BasicUnitFloorPlanCandidate | null;
  floorPlanSizeInches: Size2DInches;
}>;

export function BasicUnitFloorPlanCandidateLayer({
  basicUnitFloorPlanCandidate,
  floorPlanSizeInches,
}: BasicUnitFloorPlanCandidateLayerProps) {
  if (
    !basicUnitFloorPlanCandidate ||
    basicUnitFloorPlanCandidate.placementState !== "positioned"
  ) {
    return null;
  }

  const validationResult = validateBasicUnitFloorPlanPlacement(
    basicUnitFloorPlanCandidate.basicUnit,
    floorPlanSizeInches,
  );

  return (
    <BasicUnitFloorPlanRenderer
      basicUnit={basicUnitFloorPlanCandidate.basicUnit}
      renderState={validationResult.isValid ? "candidate-valid" : "candidate-invalid"}
    />
  );
}
