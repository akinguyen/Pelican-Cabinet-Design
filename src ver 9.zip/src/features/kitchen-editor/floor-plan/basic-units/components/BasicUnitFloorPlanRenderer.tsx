import type { PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";
import {
  getBasicUnitFloorPlanPoints,
  getBasicUnitFloorPlanPointsAttribute,
} from "@/features/kitchen-editor/floor-plan/basic-units/logic/basicUnitFloorPlanGeometry";
import { getBasicUnitBoxFrontFaceFloorPlanParts } from "@/features/kitchen-editor/floor-plan/basic-units/logic/basicUnitBoxFrontFaceFloorPlanGeometry";
import type { BasicUnitFloorPlanRenderState } from "@/features/kitchen-editor/floor-plan/basic-units/logic/basicUnitFloorPlanRenderItems";

const BASIC_UNIT_NESTED_FRONT_FACE_FILL = "#fef3c7";
const BASIC_UNIT_NESTED_FRONT_FACE_STROKE = "#020617";
const BASIC_UNIT_HANDLE_FILL = "#020617";

type BasicUnitFloorPlanRendererProps = Readonly<{
  basicUnit: PlacedBasicUnit;
  renderState: BasicUnitFloorPlanRenderState;
}>;

type BasicUnitFloorPlanStyle = Readonly<{
  fill: string;
  stroke: string;
  strokeWidth: number;
}>;

function getBasicUnitFloorPlanStyle(
  basicUnit: PlacedBasicUnit,
  renderState: BasicUnitFloorPlanRenderState,
): BasicUnitFloorPlanStyle {
  if (renderState === "candidate-invalid") {
    return {
      fill: "#fecaca",
      stroke: "#ef4444",
      strokeWidth: 2,
    };
  }

  if (renderState === "selected" || renderState === "candidate-valid") {
    return {
      fill: "#bae6fd",
      stroke: "#06b6d4",
      strokeWidth: 2,
    };
  }

  if (basicUnit.kind === "handle") {
    return {
      fill: BASIC_UNIT_HANDLE_FILL,
      stroke: BASIC_UNIT_HANDLE_FILL,
      strokeWidth: 1,
    };
  }

  return {
    fill: "#fef3c7",
    stroke: "#020617",
    strokeWidth: 1,
  };
}

function BasicUnitBoxFrontFaceParts({
  basicUnit,
}: Readonly<{
  basicUnit: Extract<PlacedBasicUnit, { kind: "box" }>;
}>) {
  const frontFaceParts = getBasicUnitBoxFrontFaceFloorPlanParts(basicUnit);

  return (
    <>
      {frontFaceParts.map((frontFacePart, frontFacePartIndex) => (
        <polygon
          key={`${frontFacePart.itemId}-${frontFacePart.kind}-${frontFacePartIndex}`}
          points={getBasicUnitFloorPlanPointsAttribute(
            frontFacePart.floorPlanPolygonInches,
          )}
          fill={
            frontFacePart.kind === "handle"
              ? BASIC_UNIT_HANDLE_FILL
              : BASIC_UNIT_NESTED_FRONT_FACE_FILL
          }
          stroke={BASIC_UNIT_NESTED_FRONT_FACE_STROKE}
          strokeLinejoin="round"
          strokeWidth={1}
          vectorEffect="non-scaling-stroke"
        />
      ))}
    </>
  );
}

export function BasicUnitFloorPlanRenderer({
  basicUnit,
  renderState,
}: BasicUnitFloorPlanRendererProps) {
  const pointsInches = getBasicUnitFloorPlanPoints(basicUnit);
  const style = getBasicUnitFloorPlanStyle(basicUnit, renderState);

  return (
    <g pointerEvents="none">
      <polygon
        points={getBasicUnitFloorPlanPointsAttribute(pointsInches)}
        fill={style.fill}
        stroke={style.stroke}
        strokeLinejoin="round"
        strokeWidth={style.strokeWidth}
        vectorEffect="non-scaling-stroke"
      />

      {basicUnit.kind === "box" ? (
        <BasicUnitBoxFrontFaceParts basicUnit={basicUnit} />
      ) : null}
    </g>
  );
}
