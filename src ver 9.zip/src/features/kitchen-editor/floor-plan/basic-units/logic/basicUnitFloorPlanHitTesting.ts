import type { PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import { getBasicUnitBoxFrontFaceFloorPlanParts } from "./basicUnitBoxFrontFaceFloorPlanGeometry";
import { getBasicUnitFloorPlanPoints } from "./basicUnitFloorPlanGeometry";

function isPointInsidePolygon(
  pointInches: Point2DInches,
  polygonInches: readonly Point2DInches[],
) {
  let isInside = false;

  for (
    let currentIndex = 0, previousIndex = polygonInches.length - 1;
    currentIndex < polygonInches.length;
    previousIndex = currentIndex, currentIndex += 1
  ) {
    const currentPointInches = polygonInches[currentIndex];
    const previousPointInches = polygonInches[previousIndex];
    const crossesY =
      currentPointInches.yInches > pointInches.yInches !==
      previousPointInches.yInches > pointInches.yInches;

    if (!crossesY) {
      continue;
    }

    const intersectionXInches =
      ((previousPointInches.xInches - currentPointInches.xInches) *
        (pointInches.yInches - currentPointInches.yInches)) /
        (previousPointInches.yInches - currentPointInches.yInches) +
      currentPointInches.xInches;

    if (pointInches.xInches < intersectionXInches) {
      isInside = !isInside;
    }
  }

  return isInside;
}

function getBasicUnitFloorPlanHitPolygons(
  basicUnit: PlacedBasicUnit,
): readonly (readonly Point2DInches[])[] {
  if (basicUnit.kind !== "box") {
    return [getBasicUnitFloorPlanPoints(basicUnit)];
  }

  return [
    getBasicUnitFloorPlanPoints(basicUnit),
    ...getBasicUnitBoxFrontFaceFloorPlanParts(basicUnit).map(
      (frontFacePart) => frontFacePart.floorPlanPolygonInches,
    ),
  ];
}

export function getBasicUnitAtPoint2DInches(
  pointInches: Point2DInches,
  placedBasicUnits: readonly PlacedBasicUnit[],
): string | null {
  const sortedBasicUnits = [...placedBasicUnits].sort((firstUnit, secondUnit) => {
    const zDifferenceInches =
      secondUnit.floorPlan.positionInches.zInches -
      firstUnit.floorPlan.positionInches.zInches;

    if (zDifferenceInches !== 0) {
      return zDifferenceInches;
    }

    return placedBasicUnits.indexOf(secondUnit) - placedBasicUnits.indexOf(firstUnit);
  });

  const hitBasicUnit = sortedBasicUnits.find((basicUnit) =>
    getBasicUnitFloorPlanHitPolygons(basicUnit).some((polygonInches) =>
      isPointInsidePolygon(pointInches, polygonInches),
    ),
  );

  return hitBasicUnit?.id ?? null;
}
