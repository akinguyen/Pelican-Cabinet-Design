const BASIC_UNIT_TRAPEZOID_FRONT_INSET_RATIO = 0.12;
const BASIC_UNIT_TRAPEZOID_MAX_FRONT_INSET_INCHES = 2;

export function getBasicUnitTrapezoidFrontInsetInches(
  widthInches: number,
): number {
  return Math.min(
    Math.max(widthInches, 0) * BASIC_UNIT_TRAPEZOID_FRONT_INSET_RATIO,
    BASIC_UNIT_TRAPEZOID_MAX_FRONT_INSET_INCHES,
  );
}
