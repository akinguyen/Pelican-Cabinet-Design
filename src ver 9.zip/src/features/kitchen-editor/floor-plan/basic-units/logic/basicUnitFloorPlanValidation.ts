import type { PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";
import type { Point2DInches, Size2DInches } from "@/shared/types/geometryTypes";
import {
  getBasicUnitFloorPlanBounds,
  getBasicUnitFloorPlanPoints,
} from "./basicUnitFloorPlanGeometry";
import { getBasicUnitBoxFrontFaceFloorPlanParts } from "./basicUnitBoxFrontFaceFloorPlanGeometry";

export type BasicUnitFloorPlanValidationResult = Readonly<{
  isValid: boolean;
  reason: BasicUnitFloorPlanInvalidReason | null;
}>;

export type BasicUnitFloorPlanInvalidReason = "outside-floor-plan";

function getBasicUnitFloorPlanValidationPoints(
  basicUnit: PlacedBasicUnit,
): readonly Point2DInches[] {
  if (basicUnit.kind !== "box") {
    return getBasicUnitFloorPlanPoints(basicUnit);
  }

  return [
    ...getBasicUnitFloorPlanPoints(basicUnit),
    ...getBasicUnitBoxFrontFaceFloorPlanParts(basicUnit).flatMap(
      (frontFacePart) => frontFacePart.floorPlanPolygonInches,
    ),
  ];
}

function isBasicUnitInsideFloorPlan(
  basicUnit: PlacedBasicUnit,
  floorPlanSizeInches: Size2DInches,
) {
  const pointsInches = getBasicUnitFloorPlanValidationPoints(basicUnit);

  if (pointsInches.length === 0) {
    const boundsInches = getBasicUnitFloorPlanBounds(basicUnit);

    return (
      boundsInches.minXInches >= 0 &&
      boundsInches.minYInches >= 0 &&
      boundsInches.maxXInches <= floorPlanSizeInches.widthInches &&
      boundsInches.maxYInches <= floorPlanSizeInches.heightInches
    );
  }

  return pointsInches.every(
    (pointInches) =>
      pointInches.xInches >= 0 &&
      pointInches.yInches >= 0 &&
      pointInches.xInches <= floorPlanSizeInches.widthInches &&
      pointInches.yInches <= floorPlanSizeInches.heightInches,
  );
}

export function validateBasicUnitFloorPlanPlacement(
  basicUnit: PlacedBasicUnit,
  floorPlanSizeInches: Size2DInches,
): BasicUnitFloorPlanValidationResult {
  if (!isBasicUnitInsideFloorPlan(basicUnit, floorPlanSizeInches)) {
    return {
      isValid: false,
      reason: "outside-floor-plan",
    };
  }

  return {
    isValid: true,
    reason: null,
  };
}
