import { getDefaultBasicUnitDimensions } from "@/domains/basic-units/model/basicUnitDefaults";
import { getBasicUnitBoxLayoutFrontFaceItems } from "@/domains/basic-units/model/basicUnitBoxLayoutGeometry";
import type { PlacedBoxUnit } from "@/domains/basic-units/model/basicUnitTypes";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type {
  BasicUnitFrontFaceFloorPlanFrontEdge,
  BasicUnitFrontFaceFloorPlanRect,
} from "./basicUnitFrontHandleGeometry";
import { getBasicUnitFrontHandleLocalRect } from "./basicUnitFrontHandleGeometry";
import { getBasicUnitFloorPlanTransformedPoint } from "./basicUnitFloorPlanGeometry";
import { getBasicUnitTrapezoidFrontInsetInches } from "./basicUnitFloorPlanTrapezoidGeometry";

export type BasicUnitBoxFrontFaceFloorPlanPart =
  | Readonly<{
      kind: "door" | "drawer";
      itemId: string;
      floorPlanPolygonInches: readonly Point2DInches[];
    }>
  | Readonly<{
      kind: "handle";
      itemId: string;
      floorPlanPolygonInches: readonly Point2DInches[];
    }>;

function getBoxLocalPointInches(
  boxUnit: PlacedBoxUnit,
  localPointInches: Point2DInches,
): Point2DInches {
  return {
    xInches: boxUnit.floorPlan.positionInches.xInches + localPointInches.xInches,
    yInches: boxUnit.floorPlan.positionInches.yInches + localPointInches.yInches,
  };
}

function getTransformedBoxLocalPointInches(
  boxUnit: PlacedBoxUnit,
  localPointInches: Point2DInches,
): Point2DInches {
  return getBasicUnitFloorPlanTransformedPoint(
    boxUnit,
    getBoxLocalPointInches(boxUnit, localPointInches),
  );
}

function getTransformedBoxLocalRectPolygonInches(
  boxUnit: PlacedBoxUnit,
  rect: BasicUnitFrontFaceFloorPlanRect,
): readonly Point2DInches[] {
  return [
    getTransformedBoxLocalPointInches(boxUnit, {
      xInches: rect.xInches,
      yInches: rect.yInches,
    }),
    getTransformedBoxLocalPointInches(boxUnit, {
      xInches: rect.xInches + rect.widthInches,
      yInches: rect.yInches,
    }),
    getTransformedBoxLocalPointInches(boxUnit, {
      xInches: rect.xInches + rect.widthInches,
      yInches: rect.yInches + rect.depthInches,
    }),
    getTransformedBoxLocalPointInches(boxUnit, {
      xInches: rect.xInches,
      yInches: rect.yInches + rect.depthInches,
    }),
  ];
}

function getBasicUnitFrontFaceFrontEdge(
  rect: BasicUnitFrontFaceFloorPlanRect,
): BasicUnitFrontFaceFloorPlanFrontEdge {
  const frontInsetInches = getBasicUnitTrapezoidFrontInsetInches(rect.widthInches);

  return {
    xInches: rect.xInches + frontInsetInches,
    widthInches: Math.max(rect.widthInches - frontInsetInches * 2, 0),
  };
}

function getTransformedBoxLocalDoorPolygonInches(
  boxUnit: PlacedBoxUnit,
  rect: BasicUnitFrontFaceFloorPlanRect,
): readonly Point2DInches[] {
  const frontInsetInches = getBasicUnitTrapezoidFrontInsetInches(rect.widthInches);

  return [
    getTransformedBoxLocalPointInches(boxUnit, {
      xInches: rect.xInches,
      yInches: rect.yInches,
    }),
    getTransformedBoxLocalPointInches(boxUnit, {
      xInches: rect.xInches + rect.widthInches,
      yInches: rect.yInches,
    }),
    getTransformedBoxLocalPointInches(boxUnit, {
      xInches: rect.xInches + rect.widthInches - frontInsetInches,
      yInches: rect.yInches + rect.depthInches,
    }),
    getTransformedBoxLocalPointInches(boxUnit, {
      xInches: rect.xInches + frontInsetInches,
      yInches: rect.yInches + rect.depthInches,
    }),
  ];
}

export function getBasicUnitBoxFrontFaceFloorPlanParts(
  boxUnit: PlacedBoxUnit,
): readonly BasicUnitBoxFrontFaceFloorPlanPart[] {
  const frontFaceItems = getBasicUnitBoxLayoutFrontFaceItems(
    boxUnit.layout,
    boxUnit.widthInches,
    boxUnit.heightInches,
  );

  const floorPlanFrontFaceItems = [...frontFaceItems].sort(
    (firstItem, secondItem) => {
      if (
        firstItem.frontFaceBottomInches !== secondItem.frontFaceBottomInches
      ) {
        return (
          firstItem.frontFaceBottomInches - secondItem.frontFaceBottomInches
        );
      }

      return firstItem.frontFaceLeftInches - secondItem.frontFaceLeftInches;
    },
  );

  return floorPlanFrontFaceItems.flatMap((frontFaceItem) => {
    if (frontFaceItem.frontFace.kind === "open") {
      return [];
    }

    const frontFaceKind = frontFaceItem.frontFace.kind;
    const frontFaceDimensions = getDefaultBasicUnitDimensions(frontFaceKind);
    const frontFaceRect: BasicUnitFrontFaceFloorPlanRect = {
      xInches: frontFaceItem.frontFaceLeftInches,
      yInches: boxUnit.depthInches,
      widthInches: frontFaceItem.frontFaceWidthInches,
      depthInches: frontFaceDimensions.depthInches,
    };
    const frontFacePart: BasicUnitBoxFrontFaceFloorPlanPart = {
      kind: frontFaceKind,
      itemId: frontFaceItem.itemId,
      floorPlanPolygonInches: getTransformedBoxLocalDoorPolygonInches(
        boxUnit,
        frontFaceRect,
      ),
    };
    const handleRect = getBasicUnitFrontHandleLocalRect(
      frontFaceItem.frontFace,
      frontFaceRect,
      getBasicUnitFrontFaceFrontEdge(frontFaceRect),
    );

    if (!handleRect) {
      return [frontFacePart];
    }

    const handlePart: BasicUnitBoxFrontFaceFloorPlanPart = {
      kind: "handle",
      itemId: frontFaceItem.itemId,
      floorPlanPolygonInches: getTransformedBoxLocalRectPolygonInches(
        boxUnit,
        handleRect,
      ),
    };

    return [frontFacePart, handlePart];
  });
}
