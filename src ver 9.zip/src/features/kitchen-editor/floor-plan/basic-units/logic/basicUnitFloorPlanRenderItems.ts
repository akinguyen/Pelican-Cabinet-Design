import type { PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";

export type BasicUnitFloorPlanRenderState =
  | "default"
  | "selected"
  | "candidate-valid"
  | "candidate-invalid";

export type BasicUnitFloorPlanRenderItem = Readonly<{
  key: string;
  basicUnit: PlacedBasicUnit;
  renderState: BasicUnitFloorPlanRenderState;
  sourceOrderIndex: number;
}>;

type GetBasicUnitFloorPlanRenderItemsParams = Readonly<{
  placedBasicUnits: readonly PlacedBasicUnit[];
  selectedBasicUnitId: string | null;
}>;

function getRenderStateOrder(renderState: BasicUnitFloorPlanRenderState) {
  if (renderState === "selected") {
    return 1;
  }

  if (renderState === "candidate-valid" || renderState === "candidate-invalid") {
    return 2;
  }

  return 0;
}

export function getBasicUnitFloorPlanRenderItems({
  placedBasicUnits,
  selectedBasicUnitId,
}: GetBasicUnitFloorPlanRenderItemsParams): readonly BasicUnitFloorPlanRenderItem[] {
  return placedBasicUnits
    .map((basicUnit, sourceOrderIndex): BasicUnitFloorPlanRenderItem => ({
      key: basicUnit.id,
      basicUnit,
      renderState:
        basicUnit.id === selectedBasicUnitId ? "selected" : "default",
      sourceOrderIndex,
    }))
    .sort((firstItem, secondItem) => {
      const zDifferenceInches =
        firstItem.basicUnit.floorPlan.positionInches.zInches -
        secondItem.basicUnit.floorPlan.positionInches.zInches;

      if (zDifferenceInches !== 0) {
        return zDifferenceInches;
      }

      const renderStateDifference =
        getRenderStateOrder(firstItem.renderState) -
        getRenderStateOrder(secondItem.renderState);

      if (renderStateDifference !== 0) {
        return renderStateDifference;
      }

      return firstItem.sourceOrderIndex - secondItem.sourceOrderIndex;
    });
}
