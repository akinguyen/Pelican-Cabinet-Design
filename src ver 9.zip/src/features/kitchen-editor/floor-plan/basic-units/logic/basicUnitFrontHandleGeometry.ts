import { getDefaultBasicUnitHandleDimensions } from "@/domains/basic-units/model/basicUnitDefaults";
import type {
  BasicUnitBoxLayoutItemFrontFace,
  BasicUnitHandleOrientation,
} from "@/domains/basic-units/model/basicUnitTypes";

type BasicUnitFrontFaceWithHandle = Exclude<
  BasicUnitBoxLayoutItemFrontFace,
  { kind: "open" }
>;

export type BasicUnitFrontFaceFloorPlanRect = Readonly<{
  xInches: number;
  yInches: number;
  widthInches: number;
  depthInches: number;
}>;

export type BasicUnitFrontFaceFloorPlanFrontEdge = Readonly<{
  xInches: number;
  widthInches: number;
}>;

const HANDLE_FRONT_EDGE_MARGIN_INCHES = 0.25;

function clampNumber(value: number, min: number, max: number) {
  return Math.max(min, Math.min(value, max));
}

function getHandlePositionRatio(position: string) {
  if (position.includes("left")) {
    return 0.18;
  }

  if (position.includes("right")) {
    return 0.82;
  }

  return 0.5;
}

function getHandleOrientation(
  frontFace: BasicUnitFrontFaceWithHandle,
): BasicUnitHandleOrientation | "knob" | null {
  if (!frontFace.handle) {
    return null;
  }

  if (frontFace.handle.type === "knob-pull") {
    return "knob";
  }

  if (frontFace.kind === "drawer") {
    return "horizontal";
  }

  if (frontFace.handle.type === "bar-pull") {
    return "vertical";
  }

  return frontFace.handle.position === "left-center" ||
    frontFace.handle.position === "right-center"
    ? "vertical"
    : "horizontal";
}

function getHandleFloorPlanSizeInches(
  frontFace: BasicUnitFrontFaceWithHandle,
) {
  const orientation = getHandleOrientation(frontFace);

  if (!orientation) {
    return null;
  }

  if (orientation === "knob") {
    const verticalHandleDimensions = getDefaultBasicUnitHandleDimensions("vertical");

    return {
      widthInches: verticalHandleDimensions.widthInches,
      depthInches: verticalHandleDimensions.depthInches,
    };
  }

  const handleDimensions = getDefaultBasicUnitHandleDimensions(orientation);

  return {
    widthInches: handleDimensions.widthInches,
    depthInches: handleDimensions.depthInches,
  };
}

function getUsableFrontEdgeInches(
  frontEdge: BasicUnitFrontFaceFloorPlanFrontEdge,
) {
  const frontEdgeWidthInches = Math.max(frontEdge.widthInches, 0);
  const edgeMarginInches = Math.min(
    HANDLE_FRONT_EDGE_MARGIN_INCHES,
    frontEdgeWidthInches / 4,
  );

  return {
    xInches: frontEdge.xInches + edgeMarginInches,
    widthInches: Math.max(frontEdgeWidthInches - edgeMarginInches * 2, 0),
  };
}

export function getBasicUnitFrontHandleLocalRect(
  frontFace: BasicUnitFrontFaceWithHandle,
  frontFaceRect: BasicUnitFrontFaceFloorPlanRect,
  frontEdge: BasicUnitFrontFaceFloorPlanFrontEdge,
): BasicUnitFrontFaceFloorPlanRect | null {
  if (!frontFace.handle) {
    return null;
  }

  const handleSizeInches = getHandleFloorPlanSizeInches(frontFace);

  if (!handleSizeInches) {
    return null;
  }

  const usableFrontEdgeInches = getUsableFrontEdgeInches(frontEdge);
  const widthInches = Math.min(
    handleSizeInches.widthInches,
    usableFrontEdgeInches.widthInches,
  );

  if (widthInches <= 0) {
    return null;
  }

  const depthInches = handleSizeInches.depthInches;
  const preferredCenterXInches =
    frontEdge.xInches +
    frontEdge.widthInches * getHandlePositionRatio(frontFace.handle.position);
  const minCenterXInches = usableFrontEdgeInches.xInches + widthInches / 2;
  const maxCenterXInches =
    usableFrontEdgeInches.xInches +
    usableFrontEdgeInches.widthInches -
    widthInches / 2;
  const centerXInches = clampNumber(
    preferredCenterXInches,
    minCenterXInches,
    Math.max(minCenterXInches, maxCenterXInches),
  );

  return {
    xInches: centerXInches - widthInches / 2,
    yInches: frontFaceRect.yInches + frontFaceRect.depthInches,
    widthInches,
    depthInches,
  };
}
