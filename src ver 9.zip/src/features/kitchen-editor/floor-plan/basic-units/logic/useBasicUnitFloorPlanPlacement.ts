import type { Point2DInches, Size2DInches } from "@/shared/types/geometryTypes";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";
import { getBasicUnitWithFloorPlanCenter } from "./basicUnitFloorPlanGeometry";
import { validateBasicUnitFloorPlanPlacement } from "./basicUnitFloorPlanValidation";

export type BasicUnitFloorPlanPlacementController = Readonly<{
  isPlacingBasicUnit: boolean;
  placePoint: (pointInches: Point2DInches) => void;
  updateCandidatePoint: (pointInches: Point2DInches | null) => void;
}>;

type UseBasicUnitFloorPlanPlacementParams = Readonly<{
  floorPlanSizeInches: Size2DInches;
}>;

export function useBasicUnitFloorPlanPlacement({
  floorPlanSizeInches,
}: UseBasicUnitFloorPlanPlacementParams): BasicUnitFloorPlanPlacementController {
  const activeTool = useDesignStore((state) => state.activeTool);
  const basicUnitFloorPlanCandidate = useDesignStore(
    (state) => state.basicUnitFloorPlanCandidate,
  );
  const updateBasicUnitFloorPlanCandidate = useDesignStore(
    (state) => state.updateBasicUnitFloorPlanCandidate,
  );
  const commitBasicUnitFloorPlanCandidate = useDesignStore(
    (state) => state.commitBasicUnitFloorPlanCandidate,
  );
  const isPlacingBasicUnit = activeTool === "place-basic-unit";

  const updateCandidatePoint = (pointInches: Point2DInches | null) => {
    if (!isPlacingBasicUnit || !basicUnitFloorPlanCandidate || !pointInches) {
      return;
    }

    updateBasicUnitFloorPlanCandidate(
      getBasicUnitWithFloorPlanCenter(
        basicUnitFloorPlanCandidate.basicUnit,
        pointInches,
      ),
    );
  };

  const placePoint = (pointInches: Point2DInches) => {
    if (!isPlacingBasicUnit || !basicUnitFloorPlanCandidate) {
      return;
    }

    const nextBasicUnit = getBasicUnitWithFloorPlanCenter(
      basicUnitFloorPlanCandidate.basicUnit,
      pointInches,
    );
    const validationResult = validateBasicUnitFloorPlanPlacement(
      nextBasicUnit,
      floorPlanSizeInches,
    );

    updateBasicUnitFloorPlanCandidate(nextBasicUnit);

    if (validationResult.isValid) {
      commitBasicUnitFloorPlanCandidate();
    }
  };

  return {
    isPlacingBasicUnit,
    placePoint,
    updateCandidatePoint,
  };
}
