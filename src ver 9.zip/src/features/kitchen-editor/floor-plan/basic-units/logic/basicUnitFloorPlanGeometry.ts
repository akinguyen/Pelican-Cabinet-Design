import type { PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import { getBasicUnitTrapezoidFrontInsetInches } from "./basicUnitFloorPlanTrapezoidGeometry";

export type BasicUnitFloorPlanBounds = Readonly<{
  minXInches: number;
  minYInches: number;
  maxXInches: number;
  maxYInches: number;
}>;

export function rotatePointAroundCenter(
  pointInches: Point2DInches,
  centerInches: Point2DInches,
  rotationDegrees: number,
): Point2DInches {
  if (rotationDegrees === 0) {
    return pointInches;
  }

  const rotationRadians = (rotationDegrees * Math.PI) / 180;
  const cosRotation = Math.cos(rotationRadians);
  const sinRotation = Math.sin(rotationRadians);
  const translatedXInches = pointInches.xInches - centerInches.xInches;
  const translatedYInches = pointInches.yInches - centerInches.yInches;

  return {
    xInches:
      centerInches.xInches +
      translatedXInches * cosRotation -
      translatedYInches * sinRotation,
    yInches:
      centerInches.yInches +
      translatedXInches * sinRotation +
      translatedYInches * cosRotation,
  };
}

export function getBasicUnitFloorPlanCenterInches(
  basicUnit: PlacedBasicUnit,
): Point2DInches {
  return {
    xInches:
      basicUnit.floorPlan.positionInches.xInches + basicUnit.widthInches / 2,
    yInches:
      basicUnit.floorPlan.positionInches.yInches + basicUnit.depthInches / 2,
  };
}

function getBasicUnitUnrotatedFloorPlanPoints(
  basicUnit: PlacedBasicUnit,
): readonly Point2DInches[] {
  const xInches = basicUnit.floorPlan.positionInches.xInches;
  const yInches = basicUnit.floorPlan.positionInches.yInches;
  const widthInches = basicUnit.widthInches;
  const depthInches = basicUnit.depthInches;

  if (basicUnit.kind === "door" || basicUnit.kind === "drawer") {
    const frontInsetInches = getBasicUnitTrapezoidFrontInsetInches(widthInches);

    return [
      {
        xInches,
        yInches,
      },
      {
        xInches: xInches + widthInches,
        yInches,
      },
      {
        xInches: xInches + widthInches - frontInsetInches,
        yInches: yInches + depthInches,
      },
      {
        xInches: xInches + frontInsetInches,
        yInches: yInches + depthInches,
      },
    ];
  }

  return [
    {
      xInches,
      yInches,
    },
    {
      xInches: xInches + widthInches,
      yInches,
    },
    {
      xInches: xInches + widthInches,
      yInches: yInches + depthInches,
    },
    {
      xInches,
      yInches: yInches + depthInches,
    },
  ];
}

export function getBasicUnitFloorPlanTransformedPoint(
  basicUnit: PlacedBasicUnit,
  pointInches: Point2DInches,
): Point2DInches {
  return rotatePointAroundCenter(
    pointInches,
    getBasicUnitFloorPlanCenterInches(basicUnit),
    basicUnit.floorPlan.rotationDegrees,
  );
}

export function getBasicUnitFloorPlanPoints(
  basicUnit: PlacedBasicUnit,
): readonly Point2DInches[] {
  return getBasicUnitUnrotatedFloorPlanPoints(basicUnit).map((pointInches) =>
    getBasicUnitFloorPlanTransformedPoint(basicUnit, pointInches),
  );
}

export function getBasicUnitFloorPlanBounds(
  basicUnit: PlacedBasicUnit,
): BasicUnitFloorPlanBounds {
  const pointsInches = getBasicUnitFloorPlanPoints(basicUnit);
  const xValuesInches = pointsInches.map((pointInches) => pointInches.xInches);
  const yValuesInches = pointsInches.map((pointInches) => pointInches.yInches);

  return {
    minXInches: Math.min(...xValuesInches),
    minYInches: Math.min(...yValuesInches),
    maxXInches: Math.max(...xValuesInches),
    maxYInches: Math.max(...yValuesInches),
  };
}

export function getBasicUnitWithFloorPlanCenter(
  basicUnit: PlacedBasicUnit,
  centerInches: Point2DInches,
): PlacedBasicUnit {
  return {
    ...basicUnit,
    floorPlan: {
      ...basicUnit.floorPlan,
      positionInches: {
        ...basicUnit.floorPlan.positionInches,
        xInches: centerInches.xInches - basicUnit.widthInches / 2,
        yInches: centerInches.yInches - basicUnit.depthInches / 2,
      },
    },
  };
}

export function getBasicUnitFloorPlanPointsAttribute(
  pointsInches: readonly Point2DInches[],
) {
  return pointsInches
    .map((pointInches) => `${pointInches.xInches},${pointInches.yInches}`)
    .join(" ");
}
