"use client";

import { useState } from "react";
import { ElevationPlanEditor } from "@/features/kitchen-editor/elevation-plan/components/ElevationPlanEditor";
import { FloorPlanEditor } from "@/features/kitchen-editor/floor-plan/components/FloorPlanEditor";
import { ItemPanel } from "@/features/kitchen-editor/item-panel/components/ItemPanel";
import { TopBar } from "@/features/kitchen-editor/layout/components/TopBar";
import type { EditorView } from "@/features/kitchen-editor/state/designStoreTypes";

export function KitchenDesigner() {
  const [activeView, setActiveView] = useState<EditorView>("floor");

  return (
    <main className="flex h-screen flex-col overflow-hidden bg-white text-slate-950">
      <TopBar activeView={activeView} onViewChange={setActiveView} />

      <div className="flex min-h-0 flex-1">
        {activeView === "floor" ? <FloorPlanEditor /> : <ElevationPlanEditor />}

        <ItemPanel />
      </div>
    </main>
  );
}
