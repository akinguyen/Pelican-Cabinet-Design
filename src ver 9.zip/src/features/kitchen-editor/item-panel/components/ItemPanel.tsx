"use client";

import { useState } from "react";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";
import { ItemDetailView } from "./ItemDetailView";
import { ItemSelector, type ItemCategory } from "./ItemSelector";

export function ItemPanel() {
  const [activeCategory, setActiveCategory] = useState<ItemCategory>("walls");
  const clearWallSegmentSelection = useDesignStore(
    (state) => state.clearWallSegmentSelection,
  );
  const clearBasicUnitSelection = useDesignStore(
    (state) => state.clearBasicUnitSelection,
  );

  const handleCategoryChange = (category: ItemCategory) => {
    clearWallSegmentSelection();
    clearBasicUnitSelection();
    setActiveCategory(category);
  };

  return (
    <aside
      className="flex h-full w-[360px] shrink-0 border-l border-slate-200 bg-white"
      aria-label="Kitchen item panel"
    >
      <ItemDetailView activeCategory={activeCategory} />

      <ItemSelector activeCategory={activeCategory} onCategoryChange={handleCategoryChange} />
    </aside>
  );
}
