"use client";

import { ChevronLeft, Grid2X2, Trash2 } from "lucide-react";
import type { BasicUnitPatch, PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";
import { BASIC_UNIT_CATALOG_ITEMS } from "@/domains/basic-units/model/basicUnitDefaults";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";
import type { Point3DInches } from "@/shared/types/geometryTypes";
import { BasicUnitBoxLayoutEditor } from "./BasicUnitBoxLayoutEditor";

type NumberFieldProps = Readonly<{
  label: string;
  value: number;
  onChange: (value: number) => void;
}>;

function NumberField({ label, value, onChange }: NumberFieldProps) {
  return (
    <label className="grid gap-1 text-xs font-semibold text-slate-600">
      <span>{label}</span>
      <input
        type="number"
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="h-9 rounded-md border border-slate-200 px-2 text-sm font-medium text-slate-950 outline-none focus:border-cyan-400"
      />
    </label>
  );
}

function getBasicUnitLabel(basicUnit: PlacedBasicUnit) {
  return (
    BASIC_UNIT_CATALOG_ITEMS.find((item) => item.kind === basicUnit.kind)?.label ??
    basicUnit.kind
  );
}

function getPositionPatch(
  basicUnit: PlacedBasicUnit,
  positionInches: Partial<Point3DInches>,
): BasicUnitPatch {
  return {
    floorPlan: {
      positionInches: {
        ...basicUnit.floorPlan.positionInches,
        ...positionInches,
      },
    },
  };
}

export function BasicUnitProperties() {
  const placedBasicUnits = useDesignStore((state) => state.placedBasicUnits);
  const selectedBasicUnitId = useDesignStore((state) => state.selectedBasicUnitId);
  const clearBasicUnitSelection = useDesignStore(
    (state) => state.clearBasicUnitSelection,
  );
  const updatePlacedBasicUnit = useDesignStore(
    (state) => state.updatePlacedBasicUnit,
  );
  const deleteSelectedBasicUnit = useDesignStore(
    (state) => state.deleteSelectedBasicUnit,
  );
  const basicUnit = placedBasicUnits.find((item) => item.id === selectedBasicUnitId);

  if (!basicUnit) {
    return null;
  }

  return (
    <div className="flex h-full flex-1 flex-col overflow-hidden bg-white">
      <button
        type="button"
        onClick={clearBasicUnitSelection}
        className="flex h-16 items-center gap-2 border-b border-slate-200 px-4 text-sm font-bold text-slate-950 transition hover:bg-slate-50"
      >
        <ChevronLeft className="h-5 w-5" strokeWidth={2.25} />
        Back
      </button>

      <div className="flex-1 overflow-y-auto px-4 py-5">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-md bg-slate-100 text-slate-900">
            <Grid2X2 className="h-6 w-6" strokeWidth={2.25} />
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
              Basic Units
            </p>
            <h2 className="text-base font-bold text-slate-950">
              {getBasicUnitLabel(basicUnit)}
            </h2>
          </div>
        </div>

        <div className="mt-8 space-y-6">
          <section className="space-y-3">
            <h3 className="text-sm font-bold text-slate-950">Dimensions</h3>
            <div className="grid grid-cols-3 gap-3">
              <NumberField
                label="Width"
                value={basicUnit.widthInches}
                onChange={(widthInches) =>
                  updatePlacedBasicUnit(basicUnit.id, { widthInches })
                }
              />
              <NumberField
                label="Height"
                value={basicUnit.heightInches}
                onChange={(heightInches) =>
                  updatePlacedBasicUnit(basicUnit.id, { heightInches })
                }
              />
              <NumberField
                label="Depth"
                value={basicUnit.depthInches}
                onChange={(depthInches) =>
                  updatePlacedBasicUnit(basicUnit.id, { depthInches })
                }
              />
            </div>
          </section>

          <section className="space-y-3">
            <h3 className="text-sm font-bold text-slate-950">Floor Plan Pose</h3>
            <div className="grid grid-cols-3 gap-3">
              <NumberField
                label="X"
                value={basicUnit.floorPlan.positionInches.xInches}
                onChange={(xInches) =>
                  updatePlacedBasicUnit(
                    basicUnit.id,
                    getPositionPatch(basicUnit, { xInches }),
                  )
                }
              />
              <NumberField
                label="Y"
                value={basicUnit.floorPlan.positionInches.yInches}
                onChange={(yInches) =>
                  updatePlacedBasicUnit(
                    basicUnit.id,
                    getPositionPatch(basicUnit, { yInches }),
                  )
                }
              />
              <NumberField
                label="Z"
                value={basicUnit.floorPlan.positionInches.zInches}
                onChange={(zInches) =>
                  updatePlacedBasicUnit(
                    basicUnit.id,
                    getPositionPatch(basicUnit, { zInches }),
                  )
                }
              />
            </div>

            <NumberField
              label="Rotation Degrees"
              value={basicUnit.floorPlan.rotationDegrees}
              onChange={(rotationDegrees) =>
                updatePlacedBasicUnit(basicUnit.id, {
                  floorPlan: { rotationDegrees },
                })
              }
            />
          </section>

          {basicUnit.kind === "box" ? (
            <section className="space-y-4">
              <h3 className="text-sm font-bold text-slate-950">Box Layout</h3>
              <NumberField
                label="Frame Thickness"
                value={basicUnit.frameThicknessInches}
                onChange={(frameThicknessInches) =>
                  updatePlacedBasicUnit(basicUnit.id, { frameThicknessInches })
                }
              />
              <BasicUnitBoxLayoutEditor
                layout={basicUnit.layout}
                availableWidthInches={basicUnit.widthInches}
                availableHeightInches={basicUnit.heightInches}
                onChange={(layout) =>
                  updatePlacedBasicUnit(basicUnit.id, { layout })
                }
              />
            </section>
          ) : null}

          <button
            type="button"
            onClick={deleteSelectedBasicUnit}
            className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-red-200 bg-white px-4 text-sm font-bold text-red-600 transition hover:bg-red-50"
          >
            <Trash2 className="h-4 w-4" strokeWidth={2.25} />
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}
