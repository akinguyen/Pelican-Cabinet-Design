"use client";

import type { ComponentType } from "react";
import {
  Box,
  DoorOpen,
  Grid2X2,
  Package,
  Wrench,
  type LucideProps,
} from "lucide-react";

export type ItemCategory =
  | "walls"
  | "basic-units"
  | "openings"
  | "products"
  | "accessories";

type SelectorItem = Readonly<{
  id: ItemCategory;
  label: string;
  Icon: ComponentType<LucideProps>;
}>;

type ItemSelectorProps = Readonly<{
  activeCategory: ItemCategory;
  onCategoryChange: (category: ItemCategory) => void;
}>;

const SELECTOR_ITEMS: readonly SelectorItem[] = [
  {
    id: "walls",
    label: "Walls",
    Icon: Grid2X2,
  },
  {
    id: "basic-units",
    label: "Units",
    Icon: Box,
  },
  {
    id: "openings",
    label: "Openings",
    Icon: DoorOpen,
  },
  {
    id: "products",
    label: "Products",
    Icon: Package,
  },
  {
    id: "accessories",
    label: "Accessories",
    Icon: Wrench,
  },
];

export function ItemSelector({
  activeCategory,
  onCategoryChange,
}: ItemSelectorProps) {
  return (
    <nav
      className="flex h-full w-20 shrink-0 flex-col items-center border-l border-slate-200 bg-white px-2 py-5"
      aria-label="Item selector"
    >
      <div className="flex w-full flex-col items-center gap-5">
        {SELECTOR_ITEMS.map(({ id, label, Icon }) => {
          const isActive = activeCategory === id;

          return (
            <button
              key={id}
              type="button"
              aria-current={isActive ? "page" : undefined}
              onClick={() => onCategoryChange(id)}
              className="group flex w-full flex-col items-center gap-1.5 text-center"
            >
              <span
                className={[
                  "flex h-10 w-10 items-center justify-center rounded-xl transition",
                  isActive
                    ? "bg-slate-900 text-white shadow-md"
                    : "bg-transparent text-slate-500 group-hover:bg-slate-100 group-hover:text-slate-900",
                ].join(" ")}
              >
                <Icon className="h-5 w-5" strokeWidth={2} />
              </span>

              <span
                className={[
                  "text-[10px] font-semibold leading-tight transition",
                  isActive
                    ? "text-slate-950"
                    : "text-slate-600 group-hover:text-slate-950",
                ].join(" ")}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
