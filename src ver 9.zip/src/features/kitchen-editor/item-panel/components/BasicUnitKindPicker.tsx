"use client";

import type { BasicUnitKind } from "@/domains/basic-units/model/basicUnitTypes";
import { BASIC_UNIT_CATALOG_ITEMS } from "@/domains/basic-units/model/basicUnitDefaults";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";

function BasicUnitPreview({ kind }: Readonly<{ kind: BasicUnitKind }>) {
  if (kind === "door" || kind === "drawer") {
    return (
      <div
        className="h-9 w-16 bg-amber-100"
        style={{
          clipPath: "polygon(14% 0, 86% 0, 100% 100%, 0 100%)",
          outline: "1px solid #020617",
        }}
      />
    );
  }

  if (kind === "handle") {
    return <div className="h-9 w-2 bg-slate-950" />;
  }

  if (kind === "filler") {
    return <div className="h-12 w-3 border border-slate-950 bg-amber-100" />;
  }

  if (kind === "toekick" || kind === "countertop" || kind === "shelf-panel") {
    return <div className="h-3 w-20 border border-slate-950 bg-amber-100" />;
  }

  return <div className="h-12 w-16 border border-slate-950 bg-amber-100" />;
}

export function BasicUnitKindPicker() {
  const activeTool = useDesignStore((state) => state.activeTool);
  const basicUnitFloorPlanCandidate = useDesignStore(
    (state) => state.basicUnitFloorPlanCandidate,
  );
  const startBasicUnitFloorPlanCandidate = useDesignStore(
    (state) => state.startBasicUnitFloorPlanCandidate,
  );

  return (
    <div className="flex h-full flex-1 flex-col overflow-hidden bg-white">
      <div className="border-b border-slate-100 px-4 py-4">
        <h2 className="text-lg font-bold text-slate-950">Basic Unit Catalog</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="grid grid-cols-2 gap-3">
          {BASIC_UNIT_CATALOG_ITEMS.map((item) => {
            const isActive =
              activeTool === "place-basic-unit" &&
              basicUnitFloorPlanCandidate?.basicUnit.kind === item.kind;

            return (
              <button
                key={item.kind}
                type="button"
                aria-pressed={isActive}
                onClick={() => startBasicUnitFloorPlanCandidate(item.kind)}
                className={[
                  "flex h-40 flex-col items-center justify-center gap-3 rounded-lg border bg-white px-3 text-center transition",
                  isActive ? "border-slate-950 shadow-sm" : "border-slate-200",
                  "hover:border-cyan-300 hover:bg-cyan-50/40 hover:shadow-sm",
                ].join(" ")}
              >
                <BasicUnitPreview kind={item.kind} />
                <span className="text-sm font-semibold text-slate-950">
                  {item.label}
                </span>
                <span className="text-[11px] leading-4 text-slate-500">
                  {item.description}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
