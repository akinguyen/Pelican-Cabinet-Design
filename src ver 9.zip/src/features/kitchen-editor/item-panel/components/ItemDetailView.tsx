"use client";

import {
  hasSelectedBasicUnit,
  hasSelectedThickWallSegment,
  hasSelectedThinWallSegment,
  useDesignStore,
} from "@/features/kitchen-editor/state/useDesignStore";
import { BasicUnitKindPicker } from "./BasicUnitKindPicker";
import { BasicUnitProperties } from "./BasicUnitProperties";
import { WallCatalog } from "./WallCatalog";
import type { ItemCategory } from "./ItemSelector";
import { ThickWallSegmentProperties } from "./ThickWallSegmentProperties";
import { ThinWallSegmentProperties } from "./ThinWallSegmentProperties";

type ItemDetailViewProps = Readonly<{
  activeCategory: ItemCategory;
}>;

type CatalogPlaceholderProps = Readonly<{
  title: string;
  eyebrow: string;
  description: string;
}>;

function CatalogPlaceholder({
  title,
  eyebrow,
  description,
}: CatalogPlaceholderProps) {
  return (
    <div className="flex h-full flex-col px-4 py-5">
      <div className="mb-5">
        <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
          {eyebrow}
        </p>
        <h2 className="text-lg font-bold text-slate-950">{title}</h2>
      </div>

      <div className="flex flex-1 items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50 px-6 text-center text-sm font-medium text-slate-500">
        {description}
      </div>
    </div>
  );
}

export function ItemDetailView({ activeCategory }: ItemDetailViewProps) {
  const isBasicUnitSelected = useDesignStore(hasSelectedBasicUnit);
  const isThinWallSegmentSelected = useDesignStore(hasSelectedThinWallSegment);
  const isThickWallSegmentSelected = useDesignStore(
    hasSelectedThickWallSegment,
  );

  if (isThickWallSegmentSelected) {
    return <ThickWallSegmentProperties />;
  }

  if (isThinWallSegmentSelected) {
    return <ThinWallSegmentProperties />;
  }

  if (isBasicUnitSelected) {
    return <BasicUnitProperties />;
  }

  if (activeCategory === "walls") {
    return <WallCatalog />;
  }

  if (activeCategory === "basic-units") {
    return <BasicUnitKindPicker />;
  }

  if (activeCategory === "openings") {
    return (
      <CatalogPlaceholder
        eyebrow="Openings"
        title="Opening Catalog"
        description="Opening catalog items will be added later."
      />
    );
  }

  if (activeCategory === "products") {
    return (
      <CatalogPlaceholder
        eyebrow="Products"
        title="Product Catalog"
        description="Product catalog items will be added later."
      />
    );
  }

  return (
    <CatalogPlaceholder
      eyebrow="Accessories"
      title="Accessory Catalog"
      description="Accessory catalog items will be added later."
    />
  );
}
