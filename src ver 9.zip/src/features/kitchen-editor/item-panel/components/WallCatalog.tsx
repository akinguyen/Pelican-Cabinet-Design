"use client";

import { WALL_CATALOG_ITEMS, type WallCatalogItem, type WallKind } from "@/domains/walls/model/wallTypes";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";

function WallPreview({ wallKind }: Readonly<{ wallKind: WallKind }>) {
  if (wallKind === "thick-wall") {
    return <div className="h-2 w-20 border border-slate-400 bg-slate-300" />;
  }

  return <div className="h-px w-20 bg-slate-700" />;
}

function WallCatalogCard({
  active,
  item,
  onClick,
}: Readonly<{
  active: boolean;
  item: WallCatalogItem;
  onClick: () => void;
}>) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={[
        "flex h-36 w-full flex-col items-center justify-center gap-4 rounded-lg border bg-white px-4 text-center transition",
        active ? "border-slate-950 shadow-sm" : "border-slate-200",
        "hover:border-cyan-300 hover:bg-cyan-50/40 hover:shadow-sm",
      ].join(" ")}
    >
      <WallPreview wallKind={item.id} />
      <span className="text-sm font-medium text-slate-950">{item.label}</span>
    </button>
  );
}

export function WallCatalog() {
  const activeTool = useDesignStore((state) => state.activeTool);
  const startThinWallTool = useDesignStore((state) => state.startThinWallTool);
  const startThickWallTool = useDesignStore((state) => state.startThickWallTool);

  const handleWallItemClick = (item: WallCatalogItem) => {
    if (item.id === "thin-wall") {
      startThinWallTool();
      return;
    }

    startThickWallTool();
  };

  return (
    <div className="flex h-full flex-1 flex-col overflow-hidden bg-white">
      <div className="border-b border-slate-100 px-4 py-4">
        <h2 className="text-lg font-bold text-slate-950">Wall Catalog</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="space-y-4">
          {WALL_CATALOG_ITEMS.map((item) => (
            <WallCatalogCard
              key={item.id}
              active={
                (item.id === "thin-wall" && activeTool === "draw-thin-wall") ||
                (item.id === "thick-wall" && activeTool === "draw-thick-wall")
              }
              item={item}
              onClick={() => handleWallItemClick(item)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
