"use client";

import { ChevronLeft, Grid2X2, Trash2 } from "lucide-react";
import { useDesignStore } from "@/features/kitchen-editor/state/useDesignStore";

export function ThinWallSegmentProperties() {
  const clearWallSegmentSelection = useDesignStore((state) => state.clearWallSegmentSelection);
  const deleteSelectedThinWallSegment = useDesignStore(
    (state) => state.deleteSelectedThinWallSegment,
  );

  return (
    <div className="flex h-full flex-1 flex-col bg-white">
      <button
        type="button"
        onClick={clearWallSegmentSelection}
        className="flex h-16 items-center gap-2 border-b border-slate-200 px-4 text-sm font-bold text-slate-950 transition hover:bg-slate-50"
      >
        <ChevronLeft className="h-5 w-5" strokeWidth={2.25} />
        Back
      </button>

      <div className="px-4 py-5">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-md bg-slate-100 text-slate-900">
            <Grid2X2 className="h-6 w-6" strokeWidth={2.25} />
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-wide text-slate-400">Walls</p>
            <h2 className="text-base font-bold text-slate-950">Thin Wall Segment</h2>
          </div>
        </div>

        <button
          type="button"
          onClick={deleteSelectedThinWallSegment}
          className="mt-8 inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-red-200 bg-white px-4 text-sm font-bold text-red-600 transition hover:bg-red-50"
        >
          <Trash2 className="h-4 w-4" strokeWidth={2.25} />
          Delete
        </button>
      </div>
    </div>
  );
}
