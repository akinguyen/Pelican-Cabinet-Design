"use client";

import type {
  BasicUnitBoxLayout,
  BasicUnitBoxLayoutDirection,
  BasicUnitBoxLayoutItem,
  BasicUnitBoxLayoutItemFrontFace,
  BasicUnitBoxLayoutItemFrontHandle,
  BasicUnitBoxLayoutItemType,
  BasicUnitDoorBarPullPosition,
  BasicUnitDoorEdgePullPosition,
  BasicUnitDoorFrontHandle,
  BasicUnitDoorKnobPullPosition,
  BasicUnitDrawerBarPullPosition,
  BasicUnitDrawerEdgePullPosition,
  BasicUnitDrawerFrontHandle,
  BasicUnitDrawerKnobPullPosition,
} from "@/domains/basic-units/model/basicUnitTypes";
import {
  addBasicUnitBoxLayoutItem,
  removeBasicUnitBoxLayoutItem,
  setBasicUnitBoxLayoutItemType,
  updateBasicUnitBoxLayoutContainerChildLayout,
  updateBasicUnitBoxLayoutDirection,
  updateBasicUnitBoxLayoutItem,
} from "@/domains/basic-units/model/basicUnitBoxLayoutEditing";
import {
  getBasicUnitBoxLayoutItemRegion,
  getBasicUnitBoxLayoutItemSizingBounds,
} from "@/domains/basic-units/model/basicUnitBoxLayoutSizing";

type SelectOption<Value extends string> = Readonly<{
  value: Value;
  label: string;
}>;

type BasicUnitBoxLayoutEditorProps = Readonly<{
  layout: BasicUnitBoxLayout;
  availableWidthInches: number;
  availableHeightInches: number;
  onChange: (layout: BasicUnitBoxLayout) => void;
  nestingLevel?: number;
}>;

type BasicUnitFrontHandleType = BasicUnitBoxLayoutItemFrontHandle["type"];

const DOOR_BAR_PULL_POSITION_OPTIONS: readonly SelectOption<BasicUnitDoorBarPullPosition>[] = [
  { value: "left-center", label: "Left Center" },
  { value: "right-center", label: "Right Center" },
  { value: "top-left", label: "Top Left" },
  { value: "top-right", label: "Top Right" },
  { value: "bottom-left", label: "Bottom Left" },
  { value: "bottom-right", label: "Bottom Right" },
];

const DRAWER_BAR_PULL_POSITION_OPTIONS: readonly SelectOption<BasicUnitDrawerBarPullPosition>[] = [
  { value: "center", label: "Center" },
  { value: "top-center", label: "Top Center" },
  { value: "bottom-center", label: "Bottom Center" },
];

const DOOR_EDGE_PULL_POSITION_OPTIONS: readonly SelectOption<BasicUnitDoorEdgePullPosition>[] = [
  { value: "left-center", label: "Left Center" },
  { value: "right-center", label: "Right Center" },
  { value: "top-left", label: "Top Left" },
  { value: "top-center", label: "Top Center" },
  { value: "top-right", label: "Top Right" },
  { value: "bottom-left", label: "Bottom Left" },
  { value: "bottom-center", label: "Bottom Center" },
  { value: "bottom-right", label: "Bottom Right" },
];

const DRAWER_EDGE_PULL_POSITION_OPTIONS: readonly SelectOption<BasicUnitDrawerEdgePullPosition>[] = [
  { value: "top-left", label: "Top Left" },
  { value: "top-center", label: "Top Center" },
  { value: "top-right", label: "Top Right" },
  { value: "bottom-left", label: "Bottom Left" },
  { value: "bottom-center", label: "Bottom Center" },
  { value: "bottom-right", label: "Bottom Right" },
];

const DOOR_KNOB_PULL_POSITION_OPTIONS: readonly SelectOption<BasicUnitDoorKnobPullPosition>[] = [
  { value: "left-center", label: "Left Center" },
  { value: "right-center", label: "Right Center" },
  { value: "top-left", label: "Top Left" },
  { value: "top-right", label: "Top Right" },
  { value: "bottom-left", label: "Bottom Left" },
  { value: "bottom-right", label: "Bottom Right" },
];

const DRAWER_KNOB_PULL_POSITION_OPTIONS: readonly SelectOption<BasicUnitDrawerKnobPullPosition>[] = [
  { value: "center", label: "Center" },
  { value: "top-center", label: "Top Center" },
  { value: "bottom-center", label: "Bottom Center" },
  { value: "left-center", label: "Left Center" },
  { value: "right-center", label: "Right Center" },
];

function createBasicUnitBoxLayoutId() {
  return `basic-unit-layout-item-${crypto.randomUUID()}`;
}

function createDefaultFrontFace(
  kind: BasicUnitBoxLayoutItemFrontFace["kind"],
): BasicUnitBoxLayoutItemFrontFace {
  if (kind === "open") {
    return { kind };
  }

  return {
    kind,
    handle: null,
  };
}

function createDefaultDoorFrontHandle(
  type: BasicUnitFrontHandleType,
): BasicUnitDoorFrontHandle {
  switch (type) {
    case "bar-pull":
      return {
        type,
        position: "right-center",
      };
    case "edge-pull":
      return {
        type,
        position: "right-center",
      };
    case "knob-pull":
      return {
        type,
        position: "right-center",
      };
  }
}

function createDefaultDrawerFrontHandle(
  type: BasicUnitFrontHandleType,
): BasicUnitDrawerFrontHandle {
  switch (type) {
    case "bar-pull":
      return {
        type,
        position: "center",
      };
    case "edge-pull":
      return {
        type,
        position: "top-center",
      };
    case "knob-pull":
      return {
        type,
        position: "center",
      };
  }
}

function createDefaultFrontHandle(
  frontFaceKind: "door" | "drawer",
  type: BasicUnitFrontHandleType,
): BasicUnitBoxLayoutItemFrontHandle {
  return frontFaceKind === "door"
    ? createDefaultDoorFrontHandle(type)
    : createDefaultDrawerFrontHandle(type);
}

function getHandleTypeValue(frontFace: BasicUnitBoxLayoutItemFrontFace) {
  if (frontFace.kind === "open" || !frontFace.handle) {
    return "none";
  }

  return frontFace.handle.type;
}

function getHandlePositionOptions(
  frontFace: Exclude<BasicUnitBoxLayoutItemFrontFace, { kind: "open" }>,
): readonly SelectOption<string>[] {
  if (!frontFace.handle) {
    return [];
  }

  if (frontFace.kind === "door") {
    switch (frontFace.handle.type) {
      case "bar-pull":
        return DOOR_BAR_PULL_POSITION_OPTIONS;
      case "edge-pull":
        return DOOR_EDGE_PULL_POSITION_OPTIONS;
      case "knob-pull":
        return DOOR_KNOB_PULL_POSITION_OPTIONS;
    }
  }

  switch (frontFace.handle.type) {
    case "bar-pull":
      return DRAWER_BAR_PULL_POSITION_OPTIONS;
    case "edge-pull":
      return DRAWER_EDGE_PULL_POSITION_OPTIONS;
    case "knob-pull":
      return DRAWER_KNOB_PULL_POSITION_OPTIONS;
  }
}

function getFrontFaceWithHandle(
  frontFace: BasicUnitBoxLayoutItemFrontFace,
  handleType: BasicUnitFrontHandleType | "none",
): BasicUnitBoxLayoutItemFrontFace {
  if (frontFace.kind === "open") {
    return frontFace;
  }

  if (frontFace.kind === "door") {
    return {
      kind: frontFace.kind,
      handle:
        handleType === "none"
          ? null
          : createDefaultDoorFrontHandle(handleType),
    };
  }

  return {
    kind: frontFace.kind,
    handle:
      handleType === "none"
        ? null
        : createDefaultDrawerFrontHandle(handleType),
  };
}

function getFrontFaceWithHandlePosition(
  frontFace: BasicUnitBoxLayoutItemFrontFace,
  position: string,
): BasicUnitBoxLayoutItemFrontFace {
  if (frontFace.kind === "open" || !frontFace.handle) {
    return frontFace;
  }

  if (frontFace.kind === "door") {
    switch (frontFace.handle.type) {
      case "bar-pull":
        return {
          kind: frontFace.kind,
          handle: {
            ...frontFace.handle,
            position: position as BasicUnitDoorBarPullPosition,
          },
        };
      case "edge-pull":
        return {
          kind: frontFace.kind,
          handle: {
            ...frontFace.handle,
            position: position as BasicUnitDoorEdgePullPosition,
          },
        };
      case "knob-pull":
        return {
          kind: frontFace.kind,
          handle: {
            ...frontFace.handle,
            position: position as BasicUnitDoorKnobPullPosition,
          },
        };
    }
  }

  switch (frontFace.handle.type) {
    case "bar-pull":
      return {
        kind: frontFace.kind,
        handle: {
          ...frontFace.handle,
          position: position as BasicUnitDrawerBarPullPosition,
        },
      };
    case "edge-pull":
      return {
        kind: frontFace.kind,
        handle: {
          ...frontFace.handle,
          position: position as BasicUnitDrawerEdgePullPosition,
        },
      };
    case "knob-pull":
      return {
        kind: frontFace.kind,
        handle: {
          ...frontFace.handle,
          position: position as BasicUnitDrawerKnobPullPosition,
        },
      };
  }
}

function formatInches(valueInches: number) {
  return `${Number.isInteger(valueInches) ? valueInches : valueInches.toFixed(2)}\"`;
}

function NumberField({
  helperText,
  label,
  max,
  min,
  value,
  onChange,
}: Readonly<{
  helperText?: string;
  label: string;
  max?: number;
  min?: number;
  value: number;
  onChange: (value: number) => void;
}>) {
  return (
    <label className="grid gap-1 text-xs font-semibold text-slate-600">
      <span>{label}</span>
      <input
        type="number"
        min={min}
        max={max}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="h-9 rounded-md border border-slate-200 px-2 text-sm font-medium text-slate-950 outline-none focus:border-cyan-400"
      />
      {helperText ? (
        <span className="text-[11px] font-semibold text-slate-400">
          {helperText}
        </span>
      ) : null}
    </label>
  );
}

function SelectField<Value extends string>({
  label,
  value,
  options,
  onChange,
}: Readonly<{
  label: string;
  value: Value;
  options: readonly SelectOption<Value>[];
  onChange: (value: Value) => void;
}>) {
  return (
    <label className="grid gap-1 text-xs font-semibold text-slate-600">
      <span>{label}</span>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value as Value)}
        className="h-9 rounded-md border border-slate-200 bg-white px-2 text-sm font-medium text-slate-950 outline-none focus:border-cyan-400"
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function BasicUnitBoxLeafItemControls({
  item,
  updateItem,
}: Readonly<{
  item: Extract<BasicUnitBoxLayoutItem, { itemType: "leaf" }>;
  updateItem: (patch: Parameters<typeof updateBasicUnitBoxLayoutItem>[2]) => void;
}>) {
  const setFrontFaceKind = (kind: BasicUnitBoxLayoutItemFrontFace["kind"]) => {
    updateItem({ frontFace: createDefaultFrontFace(kind) });
  };

  const setHandleType = (handleType: BasicUnitFrontHandleType | "none") => {
    updateItem({
      frontFace: getFrontFaceWithHandle(item.frontFace, handleType),
    });
  };

  const setHandlePosition = (position: string) => {
    updateItem({
      frontFace: getFrontFaceWithHandlePosition(item.frontFace, position),
    });
  };

  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <SelectField
          label="Front Face"
          value={item.frontFace.kind}
          options={[
            { value: "open", label: "Open" },
            { value: "door", label: "Door" },
            { value: "drawer", label: "Drawer" },
          ]}
          onChange={setFrontFaceKind}
        />
        {item.frontFace.kind === "open" ? null : (
          <SelectField
            label="Handle"
            value={getHandleTypeValue(item.frontFace)}
            options={[
              { value: "none", label: "None" },
              { value: "bar-pull", label: "Bar Pull" },
              { value: "edge-pull", label: "Edge Pull" },
              { value: "knob-pull", label: "Knob Pull" },
            ]}
            onChange={setHandleType}
          />
        )}
      </div>

      {item.frontFace.kind !== "open" && item.frontFace.handle ? (
        <SelectField
          label="Handle Position"
          value={item.frontFace.handle.position}
          options={getHandlePositionOptions(item.frontFace)}
          onChange={setHandlePosition}
        />
      ) : null}
    </>
  );
}

function BasicUnitBoxContainerItemControls({
  availableHeightInches,
  availableWidthInches,
  item,
  layout,
  nestingLevel,
  onChange,
}: Readonly<{
  availableHeightInches: number;
  availableWidthInches: number;
  item: Extract<BasicUnitBoxLayoutItem, { itemType: "container" }>;
  layout: BasicUnitBoxLayout;
  nestingLevel: number;
  onChange: (layout: BasicUnitBoxLayout) => void;
}>) {
  const itemRegion = getBasicUnitBoxLayoutItemRegion(
    layout,
    item.id,
    availableWidthInches,
    availableHeightInches,
  );
  const childAvailableWidthInches = itemRegion?.frontFaceWidthInches ?? 0;
  const childAvailableHeightInches = itemRegion?.frontFaceHeightInches ?? 0;

  return (
    <div className="space-y-3 rounded-md border border-dashed border-slate-200 p-3">
      <span className="text-xs font-bold uppercase tracking-wide text-slate-500">
        Child Layout
      </span>
      <BasicUnitBoxLayoutEditor
        layout={item.childLayout}
        availableWidthInches={childAvailableWidthInches}
        availableHeightInches={childAvailableHeightInches}
        nestingLevel={nestingLevel + 1}
        onChange={(childLayout) =>
          onChange(
            updateBasicUnitBoxLayoutContainerChildLayout(
              layout,
              item.id,
              childLayout,
              availableWidthInches,
              availableHeightInches,
            ),
          )
        }
      />
    </div>
  );
}

function BasicUnitBoxLayoutItemEditor({
  availableHeightInches,
  availableWidthInches,
  canRemove,
  item,
  layout,
  nestingLevel,
  onChange,
}: Readonly<{
  availableHeightInches: number;
  availableWidthInches: number;
  canRemove: boolean;
  item: BasicUnitBoxLayoutItem;
  layout: BasicUnitBoxLayout;
  nestingLevel: number;
  onChange: (layout: BasicUnitBoxLayout) => void;
}>) {
  const sizingBounds = getBasicUnitBoxLayoutItemSizingBounds(
    layout,
    item.id,
    availableWidthInches,
    availableHeightInches,
  );
  const updateItem = (patch: Parameters<typeof updateBasicUnitBoxLayoutItem>[2]) => {
    onChange(
      updateBasicUnitBoxLayoutItem(
        layout,
        item.id,
        patch,
        availableWidthInches,
        availableHeightInches,
      ),
    );
  };

  const setItemType = (itemType: BasicUnitBoxLayoutItemType) => {
    onChange(
      setBasicUnitBoxLayoutItemType(
        layout,
        item.id,
        itemType,
        createBasicUnitBoxLayoutId(),
        availableWidthInches,
        availableHeightInches,
      ),
    );
  };

  return (
    <div className="space-y-3 rounded-lg border border-slate-200 bg-white p-3">
      <div className="flex items-center justify-between gap-3">
        <h4 className="text-xs font-bold uppercase tracking-wide text-slate-500">
          Layout Item
        </h4>
        <button
          type="button"
          disabled={!canRemove}
          onClick={() =>
            onChange(
              removeBasicUnitBoxLayoutItem(
                layout,
                item.id,
                availableWidthInches,
                availableHeightInches,
              ),
            )
          }
          className="text-xs font-bold text-red-500 transition hover:text-red-600 disabled:cursor-not-allowed disabled:text-slate-300"
        >
          Remove
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <SelectField
          label="Item Type"
          value={item.itemType}
          options={[
            { value: "leaf", label: "Leaf" },
            { value: "container", label: "Container" },
          ]}
          onChange={setItemType}
        />
        <SelectField
          label="Sizing"
          value={item.sizing}
          options={[
            { value: "fill", label: "Fill" },
            { value: "fixed", label: "Fixed" },
          ]}
          onChange={(sizing) => updateItem({ sizing })}
        />
      </div>

      {item.sizing === "fill" ? (
        <NumberField
          label="Fill Weight"
          min={0}
          value={item.fillWeight}
          onChange={(fillWeight) => updateItem({ fillWeight })}
        />
      ) : (
        <NumberField
          label="Size Inches"
          min={sizingBounds?.minSizeInches ?? 0}
          max={sizingBounds?.maxSizeInches}
          helperText={
            sizingBounds
              ? `Allowed: ${formatInches(sizingBounds.minSizeInches)}-${formatInches(sizingBounds.maxSizeInches)}`
              : undefined
          }
          value={item.sizeInches}
          onChange={(sizeInches) => updateItem({ sizeInches })}
        />
      )}

      {item.itemType === "leaf" ? (
        <BasicUnitBoxLeafItemControls item={item} updateItem={updateItem} />
      ) : (
        <BasicUnitBoxContainerItemControls
          item={item}
          layout={layout}
          availableWidthInches={availableWidthInches}
          availableHeightInches={availableHeightInches}
          nestingLevel={nestingLevel}
          onChange={onChange}
        />
      )}
    </div>
  );
}

export function BasicUnitBoxLayoutEditor({
  availableHeightInches,
  availableWidthInches,
  layout,
  onChange,
  nestingLevel = 0,
}: BasicUnitBoxLayoutEditorProps) {
  const canRemoveItem = layout.items.length > 1;

  return (
    <div className={nestingLevel === 0 ? "space-y-4" : "space-y-3"}>
      <div className="grid grid-cols-2 gap-3">
        <SelectField
          label="Direction"
          value={layout.direction}
          options={[
            { value: "vertical", label: "Vertical" },
            { value: "horizontal", label: "Horizontal" },
          ]}
          onChange={(direction: BasicUnitBoxLayoutDirection) =>
            onChange(
              updateBasicUnitBoxLayoutDirection(
                layout,
                direction,
                availableWidthInches,
                availableHeightInches,
              ),
            )
          }
        />
        <div className="flex items-end">
          <button
            type="button"
            onClick={() =>
              onChange(
                addBasicUnitBoxLayoutItem(
                  layout,
                  createBasicUnitBoxLayoutId(),
                  availableWidthInches,
                  availableHeightInches,
                ),
              )
            }
            className="h-9 w-full rounded-md border border-cyan-200 bg-cyan-50 text-xs font-bold text-cyan-700 transition hover:bg-cyan-100"
          >
            Add Item
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {layout.items.map((item) => (
          <BasicUnitBoxLayoutItemEditor
            key={item.id}
            availableWidthInches={availableWidthInches}
            availableHeightInches={availableHeightInches}
            canRemove={canRemoveItem}
            item={item}
            layout={layout}
            nestingLevel={nestingLevel}
            onChange={onChange}
          />
        ))}
      </div>
    </div>
  );
}
