import { create } from "zustand";
import type { MeasurementUnit } from "@/shared/units/length";
import { BASE_FLOOR_PLAN_PIXELS_PER_INCH, inchesToPixels, pixelsToInches } from "@/shared/units/length";
import type { Point2DPixels, Size2DInches, Size2DPixels } from "@/shared/types/geometryTypes";
import type { ThickWallElevationPlanSide } from "@/domains/walls/model/wallTypes";
import type { ElevationPlanEditorMode } from "@/features/kitchen-editor/elevation-plan/components/ElevationPlanControls";

const ORIGINAL_FLOOR_PLAN_WIDTH_PIXELS = 1600;
const ORIGINAL_FLOOR_PLAN_HEIGHT_PIXELS = 1000;

export const FLOOR_PLAN_SIZE_INCHES: Size2DInches = {
  widthInches: ORIGINAL_FLOOR_PLAN_WIDTH_PIXELS / BASE_FLOOR_PLAN_PIXELS_PER_INCH,
  heightInches: ORIGINAL_FLOOR_PLAN_HEIGHT_PIXELS / BASE_FLOOR_PLAN_PIXELS_PER_INCH,
};

const MIN_FLOOR_PLAN_PIXELS_PER_INCH = BASE_FLOOR_PLAN_PIXELS_PER_INCH * 0.22;
const MAX_FLOOR_PLAN_PIXELS_PER_INCH = BASE_FLOOR_PLAN_PIXELS_PER_INCH * 3;
const ZOOM_STEP = 1.2;

type UiStore = {
  panOffsetPixels: Point2DPixels;
  floorPlanPixelsPerInch: number;
  floorPlanViewportSizePixels: Size2DPixels;
  floorPlanSizeInches: Size2DInches;
  minFloorPlanPixelsPerInch: number;
  maxFloorPlanPixelsPerInch: number;
  measurementUnit: MeasurementUnit;
  elevationMode: ElevationPlanEditorMode;
  selectedElevationWallIndex: number;
  selectedThickWallElevationPlanSide: ThickWallElevationPlanSide;

  setFloorPlanViewportSizePixels: (sizePixels: Size2DPixels) => void;
  panFloorPlanBy: (deltaPixels: Point2DPixels) => void;
  zoomFloorPlanByAtPoint: (viewportPointPixels: Point2DPixels, zoomFactor: number) => void;
  zoomFloorPlanIn: () => void;
  zoomFloorPlanOut: () => void;
  centerFloorPlanView: () => void;
  toggleMeasurementUnit: () => void;
  setElevationMode: (mode: ElevationPlanEditorMode) => void;
  setSelectedElevationWallIndex: (index: number) => void;
  setSelectedThickWallElevationPlanSide: (side: ThickWallElevationPlanSide) => void;
};

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

function sanitizeSizePixels(sizePixels: Size2DPixels): Size2DPixels {
  return {
    widthPixels: Math.max(0, sizePixels.widthPixels),
    heightPixels: Math.max(0, sizePixels.heightPixels),
  };
}

function getFloorPlanViewportCenterPixels(state: UiStore): Point2DPixels {
  return {
    xPixels: state.floorPlanViewportSizePixels.widthPixels / 2,
    yPixels: state.floorPlanViewportSizePixels.heightPixels / 2,
  };
}

function getFloorPlanWidthPixels(state: UiStore, floorPlanPixelsPerInch = state.floorPlanPixelsPerInch) {
  return inchesToPixels(state.floorPlanSizeInches.widthInches, floorPlanPixelsPerInch);
}

function getFloorPlanHeightPixels(state: UiStore, floorPlanPixelsPerInch = state.floorPlanPixelsPerInch) {
  return inchesToPixels(state.floorPlanSizeInches.heightInches, floorPlanPixelsPerInch);
}

function getCenteredPanOffsetPixels(
  state: UiStore,
  floorPlanPixelsPerInch = state.floorPlanPixelsPerInch,
): Point2DPixels {
  return {
    xPixels: (state.floorPlanViewportSizePixels.widthPixels - getFloorPlanWidthPixels(state, floorPlanPixelsPerInch)) / 2,
    yPixels: (state.floorPlanViewportSizePixels.heightPixels - getFloorPlanHeightPixels(state, floorPlanPixelsPerInch)) / 2,
  };
}

function getZoomedFloorPlanState(
  state: UiStore,
  viewportPointPixels: Point2DPixels,
  nextFloorPlanPixelsPerInch: number,
): Pick<UiStore, "panOffsetPixels" | "floorPlanPixelsPerInch"> {
  const clampedFloorPlanPixelsPerInch = clamp(
    nextFloorPlanPixelsPerInch,
    state.minFloorPlanPixelsPerInch,
    state.maxFloorPlanPixelsPerInch,
  );
  const floorPlanPointInches = {
    xInches: pixelsToInches(
      viewportPointPixels.xPixels - state.panOffsetPixels.xPixels,
      state.floorPlanPixelsPerInch,
    ),
    yInches: pixelsToInches(
      viewportPointPixels.yPixels - state.panOffsetPixels.yPixels,
      state.floorPlanPixelsPerInch,
    ),
  };

  return {
    floorPlanPixelsPerInch: clampedFloorPlanPixelsPerInch,
    panOffsetPixels: {
      xPixels: viewportPointPixels.xPixels - inchesToPixels(floorPlanPointInches.xInches, clampedFloorPlanPixelsPerInch),
      yPixels: viewportPointPixels.yPixels - inchesToPixels(floorPlanPointInches.yInches, clampedFloorPlanPixelsPerInch),
    },
  };
}

export const useUiStore = create<UiStore>((set) => ({
  panOffsetPixels: { xPixels: 0, yPixels: 0 },
  floorPlanPixelsPerInch: BASE_FLOOR_PLAN_PIXELS_PER_INCH,
  floorPlanViewportSizePixels: { widthPixels: 0, heightPixels: 0 },
  floorPlanSizeInches: FLOOR_PLAN_SIZE_INCHES,
  minFloorPlanPixelsPerInch: MIN_FLOOR_PLAN_PIXELS_PER_INCH,
  maxFloorPlanPixelsPerInch: MAX_FLOOR_PLAN_PIXELS_PER_INCH,
  measurementUnit: "feet",
  elevationMode: "wall-elevation",
  selectedElevationWallIndex: 0,
  selectedThickWallElevationPlanSide: "interior",

  setFloorPlanViewportSizePixels: (sizePixels) => {
    const nextSizePixels = sanitizeSizePixels(sizePixels);

    set((state) => {
      if (
        state.floorPlanViewportSizePixels.widthPixels === nextSizePixels.widthPixels &&
        state.floorPlanViewportSizePixels.heightPixels === nextSizePixels.heightPixels
      ) {
        return {};
      }

      return {
        floorPlanViewportSizePixels: nextSizePixels,
      };
    });
  },

  panFloorPlanBy: (deltaPixels) => {
    if (deltaPixels.xPixels === 0 && deltaPixels.yPixels === 0) {
      return;
    }

    set((state) => ({
      panOffsetPixels: {
        xPixels: state.panOffsetPixels.xPixels + deltaPixels.xPixels,
        yPixels: state.panOffsetPixels.yPixels + deltaPixels.yPixels,
      },
    }));
  },

  zoomFloorPlanByAtPoint: (viewportPointPixels, zoomFactor) => {
    if (!Number.isFinite(zoomFactor) || zoomFactor <= 0) {
      return;
    }

    set((state) =>
      getZoomedFloorPlanState(
        state,
        viewportPointPixels,
        state.floorPlanPixelsPerInch * zoomFactor,
      ),
    );
  },

  zoomFloorPlanIn: () => {
    set((state) =>
      getZoomedFloorPlanState(
        state,
        getFloorPlanViewportCenterPixels(state),
        state.floorPlanPixelsPerInch * ZOOM_STEP,
      ),
    );
  },

  zoomFloorPlanOut: () => {
    set((state) =>
      getZoomedFloorPlanState(
        state,
        getFloorPlanViewportCenterPixels(state),
        state.floorPlanPixelsPerInch / ZOOM_STEP,
      ),
    );
  },

  centerFloorPlanView: () => {
    set((state) => ({
      panOffsetPixels: getCenteredPanOffsetPixels(state),
    }));
  },

  toggleMeasurementUnit: () => {
    set((state) => ({
      measurementUnit: state.measurementUnit === "feet" ? "inches" : "feet",
    }));
  },

  setElevationMode: (mode) => {
    set({ elevationMode: mode });
  },

  setSelectedElevationWallIndex: (index) => {
    set({ selectedElevationWallIndex: Math.max(0, index) });
  },

  setSelectedThickWallElevationPlanSide: (side) => {
    set({ selectedThickWallElevationPlanSide: side });
  },
}));
