import type { Point2DInches } from "@/shared/types/geometryTypes";
import type {
  BasicUnitFloorPlanCandidate,
  BasicUnitKind,
  BasicUnitPatch,
  PlacedBasicUnit,
} from "@/domains/basic-units/model/basicUnitTypes";
import type {
  CandidateThickWallSegment,
  CandidateThinWallSegment,
  PlacedThickWallChain,
  ThickWallPlacementSide,
  PlacedThinWallChain,
} from "@/domains/walls/model/wallTypes";

export type EditorView = "floor" | "elevation";

export type EditorTool =
  | "select"
  | "draw-thin-wall"
  | "draw-thick-wall"
  | "place-basic-unit";

export type ThinWallSegmentSelection = Readonly<{
  type: "thin-wall-segment";
  chainId: string;
  segmentIndex: number;
}>;

export type ThickWallSegmentSelection = Readonly<{
  type: "thick-wall-segment";
  chainId: string;
  segmentIndex: number;
}>;

export type DesignStore = {
  activeTool: EditorTool;
  placedThinWallChains: readonly PlacedThinWallChain[];
  placedThickWallChains: readonly PlacedThickWallChain[];
  candidateThinWallSegment: CandidateThinWallSegment | null;
  candidateThickWallSegment: CandidateThickWallSegment | null;
  selectedThinWallSegment: ThinWallSegmentSelection | null;
  selectedThickWallSegment: ThickWallSegmentSelection | null;
  placedBasicUnits: readonly PlacedBasicUnit[];
  basicUnitFloorPlanCandidate: BasicUnitFloorPlanCandidate | null;
  selectedBasicUnitId: string | null;

  setActiveTool: (tool: EditorTool) => void;
  startThinWallTool: () => void;
  startThickWallTool: () => void;
  startBasicUnitFloorPlanCandidate: (kind: BasicUnitKind) => void;
  updateBasicUnitFloorPlanCandidate: (basicUnit: PlacedBasicUnit) => void;
  commitBasicUnitFloorPlanCandidate: () => void;
  cancelBasicUnitFloorPlanCandidate: () => void;
  startCandidateThinWallSegment: (startPointInches: Point2DInches) => void;
  updateCandidateThinWallSegment: (endPointInches: Point2DInches) => void;
  commitCandidateThinWallSegment: () => void;
  cancelCandidateThinWallSegment: () => void;
  startCandidateThickWallSegment: (startPointInches: Point2DInches) => void;
  updateCandidateThickWallSegment: (endPointInches: Point2DInches) => void;
  commitCandidateThickWallSegment: () => void;
  cancelCandidateThickWallSegment: () => void;
  selectThinWallSegment: (selection: ThinWallSegmentSelection | null) => void;
  selectThickWallSegment: (selection: ThickWallSegmentSelection | null) => void;
  clearWallSegmentSelection: () => void;
  selectBasicUnit: (basicUnitId: string | null) => void;
  clearBasicUnitSelection: () => void;
  updatePlacedBasicUnit: (basicUnitId: string, patch: BasicUnitPatch) => void;
  deleteSelectedBasicUnit: () => void;
  updateThickWallSegmentPlacementSide: (
    chainId: string,
    segmentIndex: number,
    placementSide: ThickWallPlacementSide,
  ) => void;
  updateSelectedThickWallPlacementSide: (
    placementSide: ThickWallPlacementSide,
  ) => void;
  deleteSelectedThinWallSegment: () => void;
  deleteSelectedThickWallSegment: () => void;
};
