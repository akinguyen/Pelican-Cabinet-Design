import { create } from "zustand";
import { createDefaultPlacedBasicUnit } from "@/domains/basic-units/model/basicUnitDefaults";
import { normalizeBasicUnitBoxLayoutSizing } from "@/domains/basic-units/model/basicUnitBoxLayoutSizing";
import { distanceBetweenPoints, projectPointOntoSegment } from "@/shared/math/geometry";
import type { Point2DInches } from "@/shared/types/geometryTypes";
import type { BasicUnitPatch, PlacedBasicUnit } from "@/domains/basic-units/model/basicUnitTypes";
import type {
  CandidateThickWallSegment,
  CandidateThinWallSegment,
  PlacedThickWallChain,
  ThickWallPlacementSide,
  PlacedThinWallChain,
} from "@/domains/walls/model/wallTypes";
import type {
  DesignStore,
  ThickWallSegmentSelection,
  ThinWallSegmentSelection,
} from "./designStoreTypes";

export const DEFAULT_WALL_HEIGHT_INCHES = 96;
export const DEFAULT_THICK_WALL_THICKNESS_INCHES = 8.5;
export const DEFAULT_THICK_WALL_PLACEMENT_SIDE: ThickWallPlacementSide =
  "interior";

function createId(prefix: string) {
  return `${prefix}-${crypto.randomUUID()}`;
}

function applyBasicUnitPatch(
  basicUnit: PlacedBasicUnit,
  patch: BasicUnitPatch,
): PlacedBasicUnit {
  const nextBasicUnit: PlacedBasicUnit = {
    ...basicUnit,
    widthInches: patch.widthInches ?? basicUnit.widthInches,
    heightInches: patch.heightInches ?? basicUnit.heightInches,
    depthInches: patch.depthInches ?? basicUnit.depthInches,
    floorPlan: patch.floorPlan
      ? {
          ...basicUnit.floorPlan,
          positionInches:
            patch.floorPlan.positionInches ?? basicUnit.floorPlan.positionInches,
          rotationDegrees:
            patch.floorPlan.rotationDegrees ?? basicUnit.floorPlan.rotationDegrees,
        }
      : basicUnit.floorPlan,
  };

  if (nextBasicUnit.kind !== "box") {
    return nextBasicUnit;
  }

  const nextLayout = patch.layout ?? nextBasicUnit.layout;

  return {
    ...nextBasicUnit,
    frameThicknessInches:
      patch.frameThicknessInches ?? nextBasicUnit.frameThicknessInches,
    layout: normalizeBasicUnitBoxLayoutSizing(
      nextLayout,
      nextBasicUnit.widthInches,
      nextBasicUnit.heightInches,
    ),
  };
}

function hasBasicUnit(
  basicUnits: readonly PlacedBasicUnit[],
  basicUnitId: string | null,
) {
  return Boolean(
    basicUnitId && basicUnits.some((basicUnit) => basicUnit.id === basicUnitId),
  );
}

function hasThinWallSegment(
  chains: readonly PlacedThinWallChain[],
  selection: ThinWallSegmentSelection,
) {
  const chain = chains.find((item) => item.id === selection.chainId);

  return Boolean(
    chain &&
    selection.segmentIndex >= 0 &&
    selection.segmentIndex < chain.floorPlan.centerlinePointsInches.length - 1,
  );
}

function hasThickWallSegment(
  chains: readonly PlacedThickWallChain[],
  selection: ThickWallSegmentSelection,
) {
  const chain = chains.find((item) => item.id === selection.chainId);

  return Boolean(
    chain &&
    selection.segmentIndex >= 0 &&
    selection.segmentIndex < chain.floorPlan.centerlinePointsInches.length - 1,
  );
}

export function hasSelectedThinWallSegment(
  state: Pick<DesignStore, "selectedThinWallSegment" | "placedThinWallChains">,
) {
  return Boolean(
    state.selectedThinWallSegment &&
    hasThinWallSegment(state.placedThinWallChains, state.selectedThinWallSegment),
  );
}

export function hasSelectedThickWallSegment(
  state: Pick<DesignStore, "selectedThickWallSegment" | "placedThickWallChains">,
) {
  return Boolean(
    state.selectedThickWallSegment &&
    hasThickWallSegment(state.placedThickWallChains, state.selectedThickWallSegment),
  );
}

export function hasSelectedBasicUnit(
  state: Pick<DesignStore, "selectedBasicUnitId" | "placedBasicUnits">,
) {
  return hasBasicUnit(state.placedBasicUnits, state.selectedBasicUnitId);
}

function getThickWallSegmentPlacementSide(
  chain: PlacedThickWallChain,
  segmentIndex: number,
): ThickWallPlacementSide {
  return (
    chain.segmentPlacementSides[segmentIndex] ??
    DEFAULT_THICK_WALL_PLACEMENT_SIDE
  );
}

function copyThickWallPlacementSides(
  chain: PlacedThickWallChain,
  startSegmentIndex: number,
  endSegmentIndexExclusive: number,
) {
  const placementSides: Record<number, ThickWallPlacementSide> = {};

  for (
    let index = startSegmentIndex;
    index < endSegmentIndexExclusive;
    index += 1
  ) {
    placementSides[index - startSegmentIndex] =
      getThickWallSegmentPlacementSide(chain, index);
  }

  return placementSides;
}

function buildPlacedThinWallChainFromPoints(
  id: string,
  centerlinePointsInches: readonly Point2DInches[],
  heightInches = DEFAULT_WALL_HEIGHT_INCHES,
): PlacedThinWallChain | null {
  if (centerlinePointsInches.length < 2) {
    return null;
  }

  return {
    id,
    kind: "thin-wall",
    floorPlan: {
      centerlinePointsInches,
    },
    heightInches,
  };
}

function buildPlacedThickWallChainFromPoints(
  sourceChain: PlacedThickWallChain,
  id: string,
  centerlinePointsInches: readonly Point2DInches[],
  segmentPlacementSides: Readonly<Record<number, ThickWallPlacementSide>>,
): PlacedThickWallChain | null {
  if (centerlinePointsInches.length < 2) {
    return null;
  }

  return {
    id,
    kind: "thick-wall",
    floorPlan: {
      centerlinePointsInches,
    },
    thicknessInches: sourceChain.thicknessInches,
    heightInches: sourceChain.heightInches,
    segmentPlacementSides,
  };
}

function deleteThinWallSegment(
  chain: PlacedThinWallChain,
  segmentIndex: number,
): readonly PlacedThinWallChain[] {
  const leftPoints = chain.floorPlan.centerlinePointsInches.slice(0, segmentIndex + 1);
  const rightPoints = chain.floorPlan.centerlinePointsInches.slice(segmentIndex + 1);
  const leftChain = buildPlacedThinWallChainFromPoints(chain.id, leftPoints);
  const rightChain = buildPlacedThinWallChainFromPoints(
    createId("thin-wall"),
    rightPoints,
  );

  return [leftChain, rightChain].filter((item): item is PlacedThinWallChain =>
    Boolean(item),
  );
}

function deleteThickWallSegment(
  chain: PlacedThickWallChain,
  segmentIndex: number,
): readonly PlacedThickWallChain[] {
  const leftPoints = chain.floorPlan.centerlinePointsInches.slice(0, segmentIndex + 1);
  const rightPoints = chain.floorPlan.centerlinePointsInches.slice(segmentIndex + 1);
  const leftPlacementSides = copyThickWallPlacementSides(
    chain,
    0,
    segmentIndex,
  );
  const rightPlacementSides = copyThickWallPlacementSides(
    chain,
    segmentIndex + 1,
    chain.floorPlan.centerlinePointsInches.length - 1,
  );
  const leftChain = buildPlacedThickWallChainFromPoints(
    chain,
    chain.id,
    leftPoints,
    leftPlacementSides,
  );
  const rightChain = buildPlacedThickWallChainFromPoints(
    chain,
    createId("thick-wall"),
    rightPoints,
    rightPlacementSides,
  );

  return [leftChain, rightChain].filter((item): item is PlacedThickWallChain =>
    Boolean(item),
  );
}

const POINT_MATCH_THRESHOLD_INCHES = 0.001;

function isSamePoint(firstPointInches: Point2DInches | undefined, secondPointInches: Point2DInches) {
  return Boolean(
    firstPointInches && distanceBetweenPoints(firstPointInches, secondPointInches) <= POINT_MATCH_THRESHOLD_INCHES,
  );
}

function shouldInsertThickWallJunctionPoint(
  pointInches: Point2DInches,
  segmentStartPointInches: Point2DInches,
  segmentEndPointInches: Point2DInches,
) {
  const projectedPointInches = projectPointOntoSegment(
    pointInches,
    segmentStartPointInches,
    segmentEndPointInches,
  ).pointInches;

  return (
    distanceBetweenPoints(pointInches, projectedPointInches) <= POINT_MATCH_THRESHOLD_INCHES &&
    distanceBetweenPoints(pointInches, segmentStartPointInches) > POINT_MATCH_THRESHOLD_INCHES &&
    distanceBetweenPoints(pointInches, segmentEndPointInches) > POINT_MATCH_THRESHOLD_INCHES
  );
}

function insertThickWallJunctionPoint(
  chain: PlacedThickWallChain,
  pointInches: Point2DInches,
): PlacedThickWallChain {
  const nextPoints: Point2DInches[] = [];
  const nextPlacementSides: Record<number, ThickWallPlacementSide> = {};
  let nextSegmentIndex = 0;
  let inserted = false;

  chain.floorPlan.centerlinePointsInches.slice(0, -1).forEach((start, segmentIndex) => {
    const end = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];
    const placementSide = getThickWallSegmentPlacementSide(chain, segmentIndex);

    nextPoints.push(start);

    if (!inserted && shouldInsertThickWallJunctionPoint(pointInches, start, end)) {
      nextPoints.push(pointInches);
      nextPlacementSides[nextSegmentIndex] = placementSide;
      nextSegmentIndex += 1;
      nextPlacementSides[nextSegmentIndex] = placementSide;
      nextSegmentIndex += 1;
      inserted = true;
      return;
    }

    nextPlacementSides[nextSegmentIndex] = placementSide;
    nextSegmentIndex += 1;
  });

  nextPoints.push(chain.floorPlan.centerlinePointsInches[chain.floorPlan.centerlinePointsInches.length - 1]);

  if (!inserted) {
    return chain;
  }

  return {
    ...chain,
    floorPlan: {
      ...chain.floorPlan,
      centerlinePointsInches: nextPoints,
    },
    segmentPlacementSides: nextPlacementSides,
  };
}

function insertThickWallJunctionPointInChains(
  chains: readonly PlacedThickWallChain[],
  pointInches: Point2DInches,
) {
  return chains.map((chain) => insertThickWallJunctionPoint(chain, pointInches));
}

function shouldInsertThinWallJunctionPoint(
  pointInches: Point2DInches,
  segmentStartPointInches: Point2DInches,
  segmentEndPointInches: Point2DInches,
) {
  const projectedPointInches = projectPointOntoSegment(
    pointInches,
    segmentStartPointInches,
    segmentEndPointInches,
  ).pointInches;

  return (
    distanceBetweenPoints(pointInches, projectedPointInches) <= POINT_MATCH_THRESHOLD_INCHES &&
    distanceBetweenPoints(pointInches, segmentStartPointInches) > POINT_MATCH_THRESHOLD_INCHES &&
    distanceBetweenPoints(pointInches, segmentEndPointInches) > POINT_MATCH_THRESHOLD_INCHES
  );
}

function insertThinWallJunctionPoint(
  chain: PlacedThinWallChain,
  pointInches: Point2DInches,
): PlacedThinWallChain {
  const nextPoints: Point2DInches[] = [];
  let inserted = false;

  chain.floorPlan.centerlinePointsInches.slice(0, -1).forEach((start, segmentIndex) => {
    const end = chain.floorPlan.centerlinePointsInches[segmentIndex + 1];

    nextPoints.push(start);

    if (!inserted && shouldInsertThinWallJunctionPoint(pointInches, start, end)) {
      nextPoints.push(pointInches);
      inserted = true;
    }
  });

  nextPoints.push(chain.floorPlan.centerlinePointsInches[chain.floorPlan.centerlinePointsInches.length - 1]);

  if (!inserted) {
    return chain;
  }

  return {
    ...chain,
    floorPlan: {
      ...chain.floorPlan,
      centerlinePointsInches: nextPoints,
    },
  };
}

function insertThinWallJunctionPointInChains(
  chains: readonly PlacedThinWallChain[],
  pointInches: Point2DInches,
) {
  return chains.map((chain) => insertThinWallJunctionPoint(chain, pointInches));
}

function updateThickWallPlacementSide(
  chain: PlacedThickWallChain,
  segmentIndex: number,
  placementSide: ThickWallPlacementSide,
): PlacedThickWallChain {
  const nextPlacementSides = {
    ...chain.segmentPlacementSides,
    [segmentIndex]: placementSide,
  };

  return {
    ...chain,
    segmentPlacementSides: nextPlacementSides,
  };
}


function createCandidateThinWallSegment({
  chainId,
  endPointInches,
  mode,
  startPointInches,
}: Readonly<{
  chainId: string | null;
  endPointInches: Point2DInches;
  mode: CandidateThinWallSegment["mode"];
  startPointInches: Point2DInches;
}>): CandidateThinWallSegment {
  return {
    id: createId("thin-wall-candidate"),
    kind: "thin-wall",
    mode,
    chainId,
    floorPlan: {
      startPointInches,
      endPointInches,
    },
    heightInches: DEFAULT_WALL_HEIGHT_INCHES,
  };
}

function createCandidateThickWallSegment({
  chainId,
  endPointInches,
  heightInches = DEFAULT_WALL_HEIGHT_INCHES,
  mode,
  placementSide = DEFAULT_THICK_WALL_PLACEMENT_SIDE,
  startPointInches,
  thicknessInches = DEFAULT_THICK_WALL_THICKNESS_INCHES,
}: Readonly<{
  chainId: string | null;
  endPointInches: Point2DInches;
  heightInches?: number;
  mode: CandidateThickWallSegment["mode"];
  placementSide?: ThickWallPlacementSide;
  startPointInches: Point2DInches;
  thicknessInches?: number;
}>): CandidateThickWallSegment {
  return {
    id: createId("thick-wall-candidate"),
    kind: "thick-wall",
    mode,
    chainId,
    floorPlan: {
      startPointInches,
      endPointInches,
    },
    thicknessInches,
    heightInches,
    placementSide,
  };
}

function getThinWallChainWithAppendedCandidate(
  chain: PlacedThinWallChain,
  candidate: CandidateThinWallSegment,
): PlacedThinWallChain {
  return {
    ...chain,
    floorPlan: {
      ...chain.floorPlan,
      centerlinePointsInches: [
        ...chain.floorPlan.centerlinePointsInches,
        candidate.floorPlan.endPointInches,
      ],
    },
  };
}

function getThickWallChainWithAppendedCandidate(
  chain: PlacedThickWallChain,
  candidate: CandidateThickWallSegment,
): PlacedThickWallChain {
  const nextSegmentIndex = chain.floorPlan.centerlinePointsInches.length - 1;

  return {
    ...chain,
    floorPlan: {
      ...chain.floorPlan,
      centerlinePointsInches: [
        ...chain.floorPlan.centerlinePointsInches,
        candidate.floorPlan.endPointInches,
      ],
    },
    segmentPlacementSides: {
      ...chain.segmentPlacementSides,
      [nextSegmentIndex]: candidate.placementSide,
    },
  };
}

export const useDesignStore = create<DesignStore>((set) => ({
  activeTool: "select",
  placedThinWallChains: [],
  placedThickWallChains: [],
  candidateThinWallSegment: null,
  candidateThickWallSegment: null,
  selectedThinWallSegment: null,
  selectedThickWallSegment: null,
  placedBasicUnits: [],
  basicUnitFloorPlanCandidate: null,
  selectedBasicUnitId: null,

  setActiveTool: (tool) => {
    set((state) => ({
      activeTool: tool,
      selectedThinWallSegment:
        tool === "select" ? state.selectedThinWallSegment : null,
      selectedThickWallSegment:
        tool === "select" ? state.selectedThickWallSegment : null,
      candidateThinWallSegment:
        tool === "draw-thin-wall" ? state.candidateThinWallSegment : null,
      candidateThickWallSegment:
        tool === "draw-thick-wall" ? state.candidateThickWallSegment : null,
      basicUnitFloorPlanCandidate:
        tool === "place-basic-unit" ? state.basicUnitFloorPlanCandidate : null,
      selectedBasicUnitId: tool === "select" ? state.selectedBasicUnitId : null,
    }));
  },

  startThinWallTool: () => {
    set({
      activeTool: "draw-thin-wall",
      selectedThinWallSegment: null,
      selectedThickWallSegment: null,
      candidateThinWallSegment: null,
      candidateThickWallSegment: null,
      basicUnitFloorPlanCandidate: null,
      selectedBasicUnitId: null,
    });
  },

  startThickWallTool: () => {
    set({
      activeTool: "draw-thick-wall",
      selectedThinWallSegment: null,
      selectedThickWallSegment: null,
      candidateThinWallSegment: null,
      candidateThickWallSegment: null,
      basicUnitFloorPlanCandidate: null,
      selectedBasicUnitId: null,
    });
  },

  startBasicUnitFloorPlanCandidate: (kind) => {
    set({
      activeTool: "place-basic-unit",
      selectedThinWallSegment: null,
      selectedThickWallSegment: null,
      selectedBasicUnitId: null,
      candidateThinWallSegment: null,
      candidateThickWallSegment: null,
      basicUnitFloorPlanCandidate: {
        mode: "create",
        placementState: "waiting-for-pointer",
        basicUnit: createDefaultPlacedBasicUnit(kind, {
          basicUnitId: createId("basic-unit"),
          boxLayoutItemId: createId("basic-unit-layout-item"),
        }),
      },
    });
  },

  updateBasicUnitFloorPlanCandidate: (basicUnit) => {
    set((state) => {
      if (
        state.activeTool !== "place-basic-unit" ||
        !state.basicUnitFloorPlanCandidate
      ) {
        return {};
      }

      return {
        basicUnitFloorPlanCandidate: {
          ...state.basicUnitFloorPlanCandidate,
          placementState: "positioned",
          basicUnit,
        },
      };
    });
  },

  commitBasicUnitFloorPlanCandidate: () => {
    set((state) => {
      if (
        state.activeTool !== "place-basic-unit" ||
        !state.basicUnitFloorPlanCandidate ||
        state.basicUnitFloorPlanCandidate.placementState !== "positioned"
      ) {
        return {};
      }

      const basicUnit = state.basicUnitFloorPlanCandidate.basicUnit;

      return {
        activeTool: "select",
        placedBasicUnits: [...state.placedBasicUnits, basicUnit],
        basicUnitFloorPlanCandidate: null,
        selectedBasicUnitId: basicUnit.id,
      };
    });
  },

  cancelBasicUnitFloorPlanCandidate: () => {
    set({
      activeTool: "select",
      basicUnitFloorPlanCandidate: null,
    });
  },

  startCandidateThinWallSegment: (startPointInches) => {
    set((state) => {
      if (state.activeTool !== "draw-thin-wall" || state.candidateThinWallSegment) {
        return {};
      }

      return {
        candidateThinWallSegment: createCandidateThinWallSegment({
          chainId: null,
          endPointInches: startPointInches,
          mode: "create-chain",
          startPointInches,
        }),
      };
    });
  },

  updateCandidateThinWallSegment: (endPointInches) => {
    set((state) => {
      if (state.activeTool !== "draw-thin-wall" || !state.candidateThinWallSegment) {
        return {};
      }

      return {
        candidateThinWallSegment: {
          ...state.candidateThinWallSegment,
          floorPlan: {
            ...state.candidateThinWallSegment.floorPlan,
            endPointInches,
          },
        },
      };
    });
  },

  commitCandidateThinWallSegment: () => {
    set((state) => {
      const candidate = state.candidateThinWallSegment;

      if (state.activeTool !== "draw-thin-wall" || !candidate) {
        return {};
      }

      const { startPointInches, endPointInches } = candidate.floorPlan;

      if (isSamePoint(startPointInches, endPointInches)) {
        return {};
      }

      if (candidate.mode === "create-chain") {
        const newChainId = createId("thin-wall");
        const chainsWithInsertedStart = insertThinWallJunctionPointInChains(
          state.placedThinWallChains,
          startPointInches,
        );
        const chainsWithInsertedEnd = insertThinWallJunctionPointInChains(
          chainsWithInsertedStart,
          endPointInches,
        );
        const newChain: PlacedThinWallChain = {
          id: newChainId,
          kind: "thin-wall",
          floorPlan: {
            centerlinePointsInches: [startPointInches, endPointInches],
          },
          heightInches: candidate.heightInches,
        };

        return {
          placedThinWallChains: [...chainsWithInsertedEnd, newChain],
          candidateThinWallSegment: createCandidateThinWallSegment({
            chainId: newChainId,
            endPointInches,
            mode: "extend-chain",
            startPointInches: endPointInches,
          }),
        };
      }

      if (!candidate.chainId) {
        return { candidateThinWallSegment: null };
      }

      const activeChain = state.placedThinWallChains.find(
        (chain) => chain.id === candidate.chainId,
      );

      if (!activeChain) {
        return { candidateThinWallSegment: null };
      }

      const chainsWithInsertedEnd = insertThinWallJunctionPointInChains(
        state.placedThinWallChains,
        endPointInches,
      );

      return {
        placedThinWallChains: chainsWithInsertedEnd.map((chain) =>
          chain.id === activeChain.id
            ? getThinWallChainWithAppendedCandidate(chain, candidate)
            : chain,
        ),
        candidateThinWallSegment: createCandidateThinWallSegment({
          chainId: activeChain.id,
          endPointInches,
          mode: "extend-chain",
          startPointInches: endPointInches,
        }),
      };
    });
  },

  cancelCandidateThinWallSegment: () => {
    set({
      activeTool: "select",
      candidateThinWallSegment: null,
    });
  },

  startCandidateThickWallSegment: (startPointInches) => {
    set((state) => {
      if (state.activeTool !== "draw-thick-wall" || state.candidateThickWallSegment) {
        return {};
      }

      return {
        candidateThickWallSegment: createCandidateThickWallSegment({
          chainId: null,
          endPointInches: startPointInches,
          mode: "create-chain",
          startPointInches,
        }),
      };
    });
  },

  updateCandidateThickWallSegment: (endPointInches) => {
    set((state) => {
      if (state.activeTool !== "draw-thick-wall" || !state.candidateThickWallSegment) {
        return {};
      }

      return {
        candidateThickWallSegment: {
          ...state.candidateThickWallSegment,
          floorPlan: {
            ...state.candidateThickWallSegment.floorPlan,
            endPointInches,
          },
        },
      };
    });
  },

  commitCandidateThickWallSegment: () => {
    set((state) => {
      const candidate = state.candidateThickWallSegment;

      if (state.activeTool !== "draw-thick-wall" || !candidate) {
        return {};
      }

      const { startPointInches, endPointInches } = candidate.floorPlan;

      if (isSamePoint(startPointInches, endPointInches)) {
        return {};
      }

      if (candidate.mode === "create-chain") {
        const newChainId = createId("thick-wall");
        const chainsWithInsertedStart = insertThickWallJunctionPointInChains(
          state.placedThickWallChains,
          startPointInches,
        );
        const chainsWithInsertedEnd = insertThickWallJunctionPointInChains(
          chainsWithInsertedStart,
          endPointInches,
        );
        const newChain: PlacedThickWallChain = {
          id: newChainId,
          kind: "thick-wall",
          floorPlan: {
            centerlinePointsInches: [startPointInches, endPointInches],
          },
          thicknessInches: candidate.thicknessInches,
          heightInches: candidate.heightInches,
          segmentPlacementSides: {
            0: candidate.placementSide,
          },
        };

        return {
          placedThickWallChains: [...chainsWithInsertedEnd, newChain],
          candidateThickWallSegment: createCandidateThickWallSegment({
            chainId: newChainId,
            endPointInches,
            heightInches: candidate.heightInches,
            mode: "extend-chain",
            placementSide: candidate.placementSide,
            startPointInches: endPointInches,
            thicknessInches: candidate.thicknessInches,
          }),
        };
      }

      if (!candidate.chainId) {
        return { candidateThickWallSegment: null };
      }

      const activeChain = state.placedThickWallChains.find(
        (chain) => chain.id === candidate.chainId,
      );

      if (!activeChain) {
        return { candidateThickWallSegment: null };
      }

      const chainsWithInsertedEnd = insertThickWallJunctionPointInChains(
        state.placedThickWallChains,
        endPointInches,
      );

      return {
        placedThickWallChains: chainsWithInsertedEnd.map((chain) =>
          chain.id === activeChain.id
            ? getThickWallChainWithAppendedCandidate(chain, candidate)
            : chain,
        ),
        candidateThickWallSegment: createCandidateThickWallSegment({
          chainId: activeChain.id,
          endPointInches,
          heightInches: activeChain.heightInches,
          mode: "extend-chain",
          placementSide: candidate.placementSide,
          startPointInches: endPointInches,
          thicknessInches: activeChain.thicknessInches,
        }),
      };
    });
  },

  cancelCandidateThickWallSegment: () => {
    set({
      activeTool: "select",
      candidateThickWallSegment: null,
    });
  },

  selectThinWallSegment: (selection) => {
    set((state) => {
      if (!selection || !hasThinWallSegment(state.placedThinWallChains, selection)) {
        return {
          selectedThinWallSegment: null,
        };
      }

      return {
        activeTool: "select",
        candidateThinWallSegment: null,
        candidateThickWallSegment: null,
        selectedThinWallSegment: selection,
        selectedThickWallSegment: null,
        selectedBasicUnitId: null,
      };
    });
  },

  selectThickWallSegment: (selection) => {
    set((state) => {
      if (
        !selection ||
        !hasThickWallSegment(state.placedThickWallChains, selection)
      ) {
        return {
          selectedThickWallSegment: null,
        };
      }

      return {
        activeTool: "select",
        candidateThinWallSegment: null,
        candidateThickWallSegment: null,
        selectedThinWallSegment: null,
        selectedThickWallSegment: selection,
        selectedBasicUnitId: null,
      };
    });
  },

  clearWallSegmentSelection: () => {
    set({
      selectedThinWallSegment: null,
      selectedThickWallSegment: null,
    });
  },

  selectBasicUnit: (basicUnitId) => {
    set((state) => {
      if (!hasBasicUnit(state.placedBasicUnits, basicUnitId)) {
        return {
          selectedBasicUnitId: null,
        };
      }

      return {
        activeTool: "select",
        candidateThinWallSegment: null,
        candidateThickWallSegment: null,
        basicUnitFloorPlanCandidate: null,
        selectedThinWallSegment: null,
        selectedThickWallSegment: null,
        selectedBasicUnitId: basicUnitId,
      };
    });
  },

  clearBasicUnitSelection: () => {
    set({
      selectedBasicUnitId: null,
    });
  },

  updatePlacedBasicUnit: (basicUnitId, patch) => {
    set((state) => ({
      placedBasicUnits: state.placedBasicUnits.map((basicUnit) =>
        basicUnit.id === basicUnitId
          ? applyBasicUnitPatch(basicUnit, patch)
          : basicUnit,
      ),
    }));
  },

  deleteSelectedBasicUnit: () => {
    set((state) => {
      if (!hasBasicUnit(state.placedBasicUnits, state.selectedBasicUnitId)) {
        return {};
      }

      return {
        placedBasicUnits: state.placedBasicUnits.filter(
          (basicUnit) => basicUnit.id !== state.selectedBasicUnitId,
        ),
        selectedBasicUnitId: null,
      };
    });
  },

  updateThickWallSegmentPlacementSide: (
    chainId,
    segmentIndex,
    placementSide,
  ) => {
    set((state) => ({
      placedThickWallChains: state.placedThickWallChains.map((chain) =>
        chain.id === chainId
          ? updateThickWallPlacementSide(chain, segmentIndex, placementSide)
          : chain,
      ),
    }));
  },

  updateSelectedThickWallPlacementSide: (placementSide) => {
    set((state) => {
      if (
        !hasSelectedThickWallSegment(state) ||
        !state.selectedThickWallSegment
      ) {
        return {};
      }

      const selectedSegment = state.selectedThickWallSegment;

      return {
        placedThickWallChains: state.placedThickWallChains.map((chain) =>
          chain.id === selectedSegment.chainId
            ? updateThickWallPlacementSide(
                chain,
                selectedSegment.segmentIndex,
                placementSide,
              )
            : chain,
        ),
      };
    });
  },

  deleteSelectedThinWallSegment: () => {
    set((state) => {
      if (
        !hasSelectedThinWallSegment(state) ||
        !state.selectedThinWallSegment
      ) {
        return {};
      }

      const selectedSegment = state.selectedThinWallSegment;
      const nextChains = state.placedThinWallChains.flatMap((chain) => {
        if (chain.id !== selectedSegment.chainId) {
          return [chain];
        }

        return deleteThinWallSegment(chain, selectedSegment.segmentIndex);
      });

      return {
        placedThinWallChains: nextChains,
        selectedThinWallSegment: null,
        candidateThinWallSegment:
          state.candidateThinWallSegment?.chainId === selectedSegment.chainId
            ? null
            : state.candidateThinWallSegment,
      };
    });
  },

  deleteSelectedThickWallSegment: () => {
    set((state) => {
      if (
        !hasSelectedThickWallSegment(state) ||
        !state.selectedThickWallSegment
      ) {
        return {};
      }

      const selectedSegment = state.selectedThickWallSegment;
      const nextChains = state.placedThickWallChains.flatMap((chain) => {
        if (chain.id !== selectedSegment.chainId) {
          return [chain];
        }

        return deleteThickWallSegment(chain, selectedSegment.segmentIndex);
      });

      return {
        placedThickWallChains: nextChains,
        selectedThickWallSegment: null,
        candidateThickWallSegment:
          state.candidateThickWallSegment?.chainId === selectedSegment.chainId
            ? null
            : state.candidateThickWallSegment,
      };
    });
  },

}));
