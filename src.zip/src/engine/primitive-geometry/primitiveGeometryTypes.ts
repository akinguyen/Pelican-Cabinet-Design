export type PrimitiveBoxGeometry = Readonly<{
  kind: "box";
}>;

export type PrimitiveCylinderGeometry = Readonly<{
  kind: "cylinder";
}>;

export type PrimitiveGeometry = PrimitiveBoxGeometry | PrimitiveCylinderGeometry;
