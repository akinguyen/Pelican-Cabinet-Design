import type { Point3DInches } from "@/core/geometry/pointTypes";
import type { PlacedAssembly } from "@/engine/assemblies/placedAssemblyTypes";

export type AssemblyPlacementEdge = Readonly<{
  index: number;
  startPointInches: Point3DInches;
  endPointInches: Point3DInches;
  midpointInches: Point3DInches;
  lengthInches: number;
}>;

export type AssemblyPlacementFootprint = Readonly<{
  centerPointInches: Point3DInches;
  cornerPointsInches: readonly Point3DInches[];
  edges: readonly AssemblyPlacementEdge[];
}>;

export type AssemblyPlacementMovementSource = "perspective" | "floor-plan" | "elevation";

export type AssemblyPlacementElevationViewZoneFrame = Readonly<{
  originInches: Point3DInches;
  leftInches: number;
  rightInches: number;
  nearDepthInches: number;
  farDepthInches: number;
  bottomInches: number;
  topInches: number;
}>;

export type AssemblyPlacementElevationFrame = Readonly<{
  faceDirectionInches: Point3DInches;
  outwardDirectionInches: Point3DInches;
  planeOriginInches: Point3DInches;
  viewZoneInches?: AssemblyPlacementElevationViewZoneFrame;
}>;

export type AssemblyPlacementSnapContext = Readonly<{
  movementSource: AssemblyPlacementMovementSource;
  elevationMoveFrame?: AssemblyPlacementElevationFrame;
}>;


export type AssemblyObjectAlignmentGuide = Readonly<{
  id: string;
  guidePlane: "plan" | "elevation";
  startPointInches: Point3DInches;
  endPointInches: Point3DInches;
}>;

export type AssemblyPlacementInvalidReason = "overlaps-wall";

export type AssemblyWallMeasurementGuide = Readonly<{
  id: string;
  startPointInches: Point3DInches;
  endPointInches: Point3DInches;
  lengthInches: number;
  labelPointInches: Point3DInches;
  labelRotationDegrees: number;
}>;


export type AssemblyPlacementFeedback = Readonly<{
  placedAssembly: PlacedAssembly;
  footprint: AssemblyPlacementFootprint;
  isValid: boolean;
  invalidReason: AssemblyPlacementInvalidReason | null;
  wallMeasurementGuides: readonly AssemblyWallMeasurementGuide[];
  objectAlignmentGuides: readonly AssemblyObjectAlignmentGuide[];
}>;

export type AssemblyPlacementResult = Readonly<{
  placedAssembly: PlacedAssembly;
  feedback: AssemblyPlacementFeedback;
}>;
