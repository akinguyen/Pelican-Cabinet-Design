"use client";

import { Edges } from "@react-three/drei";
import type { ThreeEvent } from "@react-three/fiber";
import { degreesToRadians } from "@/core/geometry/rotationTypes";
import type { BuiltPrimitiveGeometry } from "@/engine/assemblies/assemblyTreeBuilder";
import { useDesignSceneStore } from "@/engine/scene/designSceneStore";
import { createAssemblyDragPointerWorldPoint } from "../../interaction/assemblies/assemblyDragPointer";

type AssemblyPrimitiveMeshProps = Readonly<{
  primitiveGeometry: BuiltPrimitiveGeometry;
  renderState: "default" | "candidate";
}>;

export function AssemblyPrimitiveMesh({ primitiveGeometry, renderState }: AssemblyPrimitiveMeshProps) {
  const workspaceMode = useDesignSceneStore((state) => state.workspaceMode);
  const activeSceneViewMode = useDesignSceneStore((state) => state.activeSceneViewMode);
  const activeSceneOperation = useDesignSceneStore((state) => state.designScene.activeSceneOperation);
  const activeToolbarTool = useDesignSceneStore((state) => state.activeToolbarTool);
  const placedAssemblies = useDesignSceneStore((state) => state.designScene.placedAssemblies);
  const selectPlacedAssembly = useDesignSceneStore((state) => state.selectPlacedAssembly);
  const startAssemblyDrag = useDesignSceneStore((state) => state.startAssemblyDrag);

  const opacity = renderState === "candidate" ? 0.55 : primitiveGeometry.material.opacity ?? 1;

  function handlePointerDown(event: ThreeEvent<PointerEvent>) {
    if (
      renderState !== "default" ||
      activeSceneOperation !== null ||
      activeToolbarTool === "draw-wall-footprint" ||
      event.button !== 0 ||
      event.ctrlKey
    ) {
      return;
    }

    const placedAssembly = placedAssemblies.find(
      (assembly) => assembly.id === primitiveGeometry.rootAssemblyId,
    );

    if (placedAssembly === undefined) {
      return;
    }

    event.stopPropagation();
    selectPlacedAssembly(primitiveGeometry.rootAssemblyId);

    if (workspaceMode !== "editor") {
      return;
    }

    const pointerWorldInches = createAssemblyDragPointerWorldPoint(
      activeSceneViewMode,
      event.ray,
      placedAssembly.worldPositionInches.yInches,
    );

    if (pointerWorldInches === null) {
      return;
    }

    startAssemblyDrag({
      assemblyId: primitiveGeometry.rootAssemblyId,
      pointerWorldInches,
      sceneViewMode: activeSceneViewMode,
    });
  }

  return (
    <mesh
      position={[
        primitiveGeometry.worldPositionInches.xInches,
        primitiveGeometry.worldPositionInches.yInches,
        primitiveGeometry.worldPositionInches.zInches,
      ]}
      rotation={[
        degreesToRadians(primitiveGeometry.worldRotationDegrees.xDegrees),
        degreesToRadians(primitiveGeometry.worldRotationDegrees.yDegrees),
        degreesToRadians(primitiveGeometry.worldRotationDegrees.zDegrees),
      ]}
      onPointerDown={handlePointerDown}
    >
      <PrimitiveGeometry primitiveGeometry={primitiveGeometry} />
      <meshStandardMaterial
        color={primitiveGeometry.material.colorHex}
        transparent={opacity < 1}
        opacity={opacity}
      />
      <Edges color="#111827" threshold={15} lineWidth={2} />
    </mesh>
  );
}

type PrimitiveGeometryProps = Readonly<{
  primitiveGeometry: BuiltPrimitiveGeometry;
}>;

function PrimitiveGeometry({ primitiveGeometry }: PrimitiveGeometryProps) {
  if (primitiveGeometry.geometry.kind === "cylinder") {
    return (
      <cylinderGeometry
        args={[
          primitiveGeometry.sizeInches.widthInches / 2,
          primitiveGeometry.sizeInches.widthInches / 2,
          primitiveGeometry.sizeInches.depthInches,
          32,
        ]}
      />
    );
  }

  return (
    <boxGeometry
      args={[
        primitiveGeometry.sizeInches.widthInches,
        primitiveGeometry.sizeInches.depthInches,
        primitiveGeometry.sizeInches.heightInches,
      ]}
    />
  );
}
